#ifndef ISUSYOBJECTTOOL_H
#define ISUSYOBJECTTOOL_H 1

// Include files
#include "GaudiKernel/IAlgTool.h"
#include "SUSYPhysUtils/SusyTypes.h"
class IParticleContainer;
class IHistogramSvc;
// Declaration of the interface ID ( interface id, major version, minor version)
static const InterfaceID IID_ISusyObjectTool("ISusyObjectTool", 1 , 0);

 /** @class ISusyObjectTool ISusyObjectTool.h
  *  This is the interface for the tools to access the particle collections
  *
  *  for Susy events 
  *
  *  @author Davide Costanzo 
 */
class ISusyObjectTool : virtual public IAlgTool {
  public:

   /// Retrieve interface ID
   static const InterfaceID& interfaceID() { return IID_ISusyObjectTool; }

   /// 
     virtual StatusCode takeAction()=0;
     virtual void  Set( const SusyBag localbag)=0;
     virtual StatusCode  Get(const susy::SusyTypes localbag, const IParticleContainer* &)=0;

};

#endif // ISUSYOBJECTTOOL_H
