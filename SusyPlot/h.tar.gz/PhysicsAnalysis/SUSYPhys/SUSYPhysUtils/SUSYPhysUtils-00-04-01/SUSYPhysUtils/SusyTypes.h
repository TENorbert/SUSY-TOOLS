#ifndef SUSYTYPES_H
#define SUSYTYPES_H 1
#include <map>
#include <string>
namespace susy {enum SusyTypes {notKnown,electron,muon,jet,bjet,photon,tau,global,
 electronmc,muonmc,jetmc,photonmc,taumc,globalmc,truthpart};}; 
typedef  std::map<susy::SusyTypes,std::string> SusyBag;

namespace susy {

inline SusyBag createNewBag(const SusyBag &oldBag, std::string tag="Red") {
  SusyBag newBag;
  for(SusyBag::const_iterator it = oldBag.begin(); it != oldBag.end(); ++it) {
    newBag[it->first]=it->second+tag;
  }
  return newBag;
};


}; // namespace

#endif // SUSYTYPES_H
