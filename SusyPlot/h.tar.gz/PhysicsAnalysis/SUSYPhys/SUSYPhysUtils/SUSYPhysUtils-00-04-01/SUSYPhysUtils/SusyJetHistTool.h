#ifndef SUSYJETHISTTOOL_H
#define SUSYJETHISTTOOL_H
/***********************************************************************
Filename : SusyJetHistTool.h
Author   : Frank Paige
Created  : September 2004

Tool to make histograms of jet kinematics.
***********************************************************************/

#include "SUSYPhysUtils/SusyObjectTool.h"
#include <string>

class IHistogram1D;

class SusyJetHistTool : public SusyObjectTool 
{
public:

  SusyJetHistTool(const std::string& type,
                 const std::string& name,
                 const IInterface* parent);

  virtual ~SusyJetHistTool();

  virtual StatusCode initialize();
  virtual StatusCode takeAction();

private:

  IHistogram1D* m_h_jetn;
  IHistogram1D* m_h_jetet;
  IHistogram1D* m_h_jetet1;
  IHistogram1D* m_h_jetet2;
  IHistogram1D* m_h_jetet3;
  IHistogram1D* m_h_jetet4;
  IHistogram1D* m_h_jetm12;
  IHistogram1D* m_h_jeteta10;
  IHistogram1D* m_h_jeteta20;
  IHistogram1D* m_h_jeteta50;
  IHistogram1D* m_h_jeteta100;
  IHistogram1D* m_h_jetetemfrac20;
  IHistogram1D* m_h_jetethadfrac20;

  IHistogram1D* m_h_jetTruen;
  IHistogram1D* m_h_jetTrueet1;
  IHistogram1D* m_h_jetTrueet2;
  IHistogram1D* m_h_jetTrueet3;
  IHistogram1D* m_h_jetTrueet4;


  std::string m_prefix;

  double m_etJetStandardCut;
  double m_maxDeltaR;

};

#endif
