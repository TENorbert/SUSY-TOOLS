#ifndef SUSYMUONTRUTHHISTTOOL_H
#define SUSYMUONTRUTHHISTTOOL_H
/***********************************************************************
Filename : SusyMuonTruthHistTool.h
Author   : Frank Paige
Created  : September 2004

Tool to make histograms of muon kinematics.
***********************************************************************/

#include "SUSYPhysUtils/SusyObjectTool.h"
#include <string>

class IHistogram1D;

class SusyMuonTruthHistTool : public SusyObjectTool
{
public:

  SusyMuonTruthHistTool(const std::string& type,
                        const std::string& name,
                        const IInterface* parent);

  virtual ~SusyMuonTruthHistTool();

  virtual StatusCode initialize();
  virtual StatusCode takeAction();

private:

  IHistogram1D* m_h_mcmuonn;
  IHistogram1D* m_h_mcmuonet;
  IHistogram1D* m_h_mcmuoneta;
  IHistogram1D* m_h_mcmuonrmatch;
  IHistogram1D* m_h_mcmuonetres;
  IHistogram1D* m_h_mcmuonmllos;
  IHistogram1D* m_h_mcemumllos;

  std::string m_prefix;
  double m_etMuonStandardCut;
  double m_maxDeltaRMatchCut;

};

#endif
