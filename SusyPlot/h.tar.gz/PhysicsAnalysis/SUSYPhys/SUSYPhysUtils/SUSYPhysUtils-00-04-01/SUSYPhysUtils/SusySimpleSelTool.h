#ifndef SUSYSIMPLESELTOOL_H
#define SUSYSIMPLESELTOOL_H 1

#include "SUSYPhysUtils/SusyObjectTool.h"

class SusySimpleSelTool : virtual public SusyObjectTool {
 public:
  SusySimpleSelTool(const std::string& type,
		 const std::string& name,
		 const IInterface* parent);

  virtual ~SusySimpleSelTool();
  
  //
  virtual StatusCode initialize();
  // 
  virtual StatusCode takeAction();

 private:
  // Here all the muon specific variables that are needed.
  double m_ETcut;
  double m_Jet4Etcut;
  double m_Jet2Etcut;
};

#endif // SUSYSIMPLEHISTTOOL_H
