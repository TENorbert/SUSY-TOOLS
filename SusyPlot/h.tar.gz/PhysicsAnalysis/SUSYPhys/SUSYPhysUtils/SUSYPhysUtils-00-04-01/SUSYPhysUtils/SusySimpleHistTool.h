#ifndef SUSYSIMPLEHISTTOOL_H
#define SUSYSIMPLEHISTTOOL_H 1
#include "SUSYPhysUtils/SusyObjectTool.h"
class IHistogram1D;
class SusySimpleHistTool : public SusyObjectTool {
 public:
  SusySimpleHistTool(const std::string& type,
		 const std::string& name,
		 const IInterface* parent);

  virtual ~SusySimpleHistTool();
  
  //
  virtual StatusCode initialize();
  // 
  virtual StatusCode takeAction();

  // Here all the muon specific variables that are needed.
   IHistogram1D* m_h_jetn;
   IHistogram1D* m_h_jetpt1;
   IHistogram1D* m_h_jetetaall;
 
};

#endif // SUSYSIMPLEHISTTOOL_H
