#ifndef SUSYOBJECTTOOL_H
#define SUSYOBJECTTOOL_H 1

#include "GaudiKernel/AlgTool.h"
#include "SUSYPhysUtils/ISusyObjectTool.h"
#include "SUSYPhysUtils/SusyGlobalObject.h"
#include "StoreGate/StoreGateSvc.h"
#include <map>
#include "AnalysisTools/IAnalysisTools.h"
#include "EventKernel/IParticleContainer.h"
#include "ParticleEvent/TruthParticleContainer.h"
#include "JetTagEvent/JetTag.h"
#include "JetTagEvent/JetTagContainer.h"
//
#include "GaudiKernel/IHistogramSvc.h"
#include "GaudiKernel/INTupleSvc.h"
#include "CLHEP/Units/SystemOfUnits.h"
class SusyObjectTool : public AlgTool,  virtual public ISusyObjectTool {
 public:
  SusyObjectTool(const std::string& type,
		 const std::string& name,
		 const IInterface* parent);

  virtual ~SusyObjectTool();

  // override intialize() method
  virtual StatusCode initialize();
  virtual StatusCode finalize();
  virtual void  Set( const SusyBag localbag);
  virtual void  SetOrg( const SusyBag orgbag);
  virtual StatusCode Get(const susy::SusyTypes myType, const IParticleContainer* &susyCont);
  virtual StatusCode GetGlobal(const susy::SusyTypes myType, const SusyGlobalObject* &susyGlobal);
  // the keys input keys need to be handled here.
  // 
  virtual StatusCode takeAction()=0;


 protected:
   // common variables to all the tools:
   // ---------------------------------

   // Input/Output  Collections //this is a set of strings that identify 
   // the objects in Storegate, there will be one key per type
   // Allow both input and output 
  SusyBag m_inputCollection;
  SusyBag m_inputOrg;
  //
  StoreGateSvc*   m_pSG;
  IHistogramSvc*  m_HistSvc;
  INTupleSvc*     m_ntupleSvc;
  IAnalysisTools* m_pAnalysisTools;
  std::string     m_foldername;
  std::string     m_prefix;

};


#endif // SUSYOBJECTTOOL_H
