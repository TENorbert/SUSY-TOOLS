#ifndef SUSYGLOBALOBJECT_H
#define SUSYGLOBALOBJECT_H

#include "CLIDSvc/CLASS_DEF.h"

class SusyGlobalObject

{

 public:

  double etmiss() const {return m_misset;}
  void setEtmiss(double MissET) {m_misset = MissET;}

  double etsum() const {return m_sumet;}
  void setEtsum(double SumET) {m_sumet = SumET;}

  double pxmiss() const {return m_ptx;}
  void setPxmiss(double pTx) {m_ptx = pTx;}

  double pymiss() const {return m_pty;}
  void setPymiss(double pTy) {m_pty = pTy;}

  // Event Shape

  double circularity() const {return m_circularity;}
  void setCircularity(double circ)    {m_circularity = circ;}

  double thrust()      const {return m_thrust;}
  void setThrust(double thrust)         {m_thrust = thrust;}

  double oblateness()  const {return m_oblateness;}
  void setOblateness(double oblateness) {m_oblateness = oblateness;}

  // Event Shape

  SusyGlobalObject(const SusyGlobalObject& in){ 
    m_misset=in.m_misset;
    m_sumet=in.m_sumet; 
    m_ptx=in.m_ptx;
    m_pty=in.m_pty;
    m_circularity=in.m_circularity;
    m_thrust=in.m_thrust;
    m_oblateness=in.m_oblateness;
  } 
 
  SusyGlobalObject(){ 
    m_misset=0.;
    m_sumet=0.; 
    m_ptx=0.;
    m_pty=0.;
    m_circularity=0.;
    m_thrust=0.;
    m_oblateness=0.;
  }  


 private:

  double m_misset, m_sumet, m_ptx, m_pty;

  // Event Shape
  double m_circularity;
  double m_thrust;
  double m_oblateness;

};

CLASS_DEF(SusyGlobalObject, 93102032, 1)

#endif
