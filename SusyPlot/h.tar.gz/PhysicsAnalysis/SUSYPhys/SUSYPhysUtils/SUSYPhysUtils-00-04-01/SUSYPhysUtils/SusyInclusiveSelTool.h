#ifndef SUSYINCLUSIVESELTOOL_H
#define SUSYINCLUSIVESELTOOL_H 1

#include "SUSYPhysUtils/SusyObjectTool.h"

class SusyInclusiveSelTool : virtual public SusyObjectTool {
 public:
  SusyInclusiveSelTool(const std::string& type,
		 const std::string& name,
		 const IInterface* parent);

  virtual ~SusyInclusiveSelTool();
  
  //
  virtual StatusCode initialize();
  // 
  virtual StatusCode takeAction();

 private:
  // Here all the muon specific variables that are needed.
  double m_nelectron, m_nmuon;
};

#endif // SUSYSIMPLEHISTTOOL_H
