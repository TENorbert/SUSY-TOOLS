#ifndef SUSYREDUNDTOOL_H
#define SUSYREDUNDTOOL_H 1
#include "SUSYPhysUtils/SusyObjectTool.h"
#include <string>
class SusyRedundTool : public SusyObjectTool {
 public:
  SusyRedundTool(const std::string& type,
		 const std::string& name,
		 const IInterface* parent);

  virtual ~SusyRedundTool();
  
  //
  virtual StatusCode initialize();
  // 
  virtual StatusCode takeAction();
  bool Matches(IParticle* part,
     const IParticleContainer* cont, double r);

 private:
  StatusCode CopyMcCollection(const susy::SusyTypes myType);

 private:

  SusyBag m_output;
  StoreGateSvc* m_pSG;

};

#endif // SUSYREDUNDTOOL_H
