/***********************************************************************
Filename: SusyTauHistTool.h
Author:   Frank Paige


***********************************************************************/

#ifndef SUSYTAUHISTTOOL_H
#define SUSYTAUHISTTOOL_H 1

#include "SUSYPhysUtils/SusyObjectTool.h"
#include <string>

class IHistogram1D;

class SusyTauHistTool : public SusyObjectTool 
{
 public:
  SusyTauHistTool(const std::string& type,
                  const std::string& name,
                  const IInterface* parent);

  virtual ~SusyTauHistTool();
  
  virtual StatusCode initialize();
  virtual StatusCode takeAction();

 private:

  // Histograms
  IHistogram1D* m_h_taun;
  IHistogram1D* m_h_taupt1;
  IHistogram1D* m_h_tauptall;
  IHistogram1D* m_h_tauetaall;

  IHistogram1D* m_h_tauMllos;
  IHistogram1D* m_h_tauMllss;
 
  // JobOptions
  std::string m_prefix;

};

#endif // SUSYTAUHISTTOOL_H
