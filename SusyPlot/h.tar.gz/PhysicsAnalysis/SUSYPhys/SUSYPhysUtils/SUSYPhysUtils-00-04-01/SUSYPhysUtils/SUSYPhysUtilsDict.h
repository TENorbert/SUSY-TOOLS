#ifndef SUSYPHYSUTILSDICT_H
#define SUSYPHYSUTILSDICT_H

#include "SUSYPhysUtils/SusyGlobalObject.h"

#include "StoreGate/StoreGateSvc.h"

namespace SUSYPhysUtils
{
  struct tmp
  {
    PyGate<SusyGlobalObject> m_susyGlobalObject;
  };
}

#endif 
