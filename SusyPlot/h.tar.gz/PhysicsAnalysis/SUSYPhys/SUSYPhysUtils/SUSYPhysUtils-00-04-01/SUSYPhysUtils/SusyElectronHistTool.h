#ifndef SUSYELECTRONHISTTOOL_H
#define SUSYELECTRONHISTTOOL_H 1
#include "SUSYPhysUtils/SusyObjectTool.h"
class IHistogram1D;
class SusyElectronHistTool : public SusyObjectTool {
 public:
  SusyElectronHistTool(const std::string& type,
		 const std::string& name,
		 const IInterface* parent);

  virtual ~SusyElectronHistTool();
  
  //
  virtual StatusCode initialize();
  // 
  virtual StatusCode takeAction();

  // Here all the electron specific variables that are needed.
   IHistogram1D* m_h_electronn;
   IHistogram1D* m_h_electronpt1;
   IHistogram1D* m_h_electronetaall;
 IHistogram1D* m_h_electronpairss;
 IHistogram1D* m_h_electronpairos;


 
};

#endif // SUSYELECTRONHISTTOOL_H
