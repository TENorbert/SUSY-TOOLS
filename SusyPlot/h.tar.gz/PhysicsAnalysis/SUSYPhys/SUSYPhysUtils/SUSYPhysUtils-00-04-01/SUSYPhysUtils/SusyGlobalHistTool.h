#ifndef SUSYGLOBALHISTTOOL_H
#define SUSYGLOBALHISTTOOL_H
/***********************************************************************
Filename : SusyGlobalHistTool.h
Author   : Frank Paige
Created  : September 2004

Tool to make histograms of etmiss.
***********************************************************************/

#include "SUSYPhysUtils/SusyObjectTool.h"
#include <string>

class IHistogram1D;

class SusyGlobalHistTool : public SusyObjectTool 
{
public:

  SusyGlobalHistTool(const std::string& type,
                 const std::string& name,
                 const IInterface* parent);

  virtual ~SusyGlobalHistTool();

  virtual StatusCode initialize();
  virtual StatusCode takeAction();

private:
  
  IHistogram1D* m_h_exmiss;
  IHistogram1D* m_h_eymiss;
  IHistogram1D* m_h_etmiss;
  IHistogram1D* m_h_etsum;
  
  IHistogram1D* m_h_exmissMC;
  IHistogram1D* m_h_eymissMC;
  IHistogram1D* m_h_etmissMC;
  IHistogram1D* m_h_etsumMC;
  
  IHistogram1D* m_h_dexmiss;
  IHistogram1D* m_h_deymiss;
  IHistogram1D* m_h_detmiss;
  IHistogram1D* m_h_detsum;
  
  IHistogram2D* m_h_detmiss2D;  

  std::string m_prefix;

};

#endif
