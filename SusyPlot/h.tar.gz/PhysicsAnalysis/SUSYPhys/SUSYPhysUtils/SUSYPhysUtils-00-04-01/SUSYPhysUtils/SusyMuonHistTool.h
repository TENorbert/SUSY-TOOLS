#ifndef SUSYMUONHISTTOOL_H
#define SUSYMUONHISTTOOL_H 1
#include "SUSYPhysUtils/SusyObjectTool.h"
class IHistogram1D;
class SusyMuonHistTool : public SusyObjectTool {
 public:
  SusyMuonHistTool(const std::string& type,
		 const std::string& name,
		 const IInterface* parent);

  virtual ~SusyMuonHistTool();
  
  //
  virtual StatusCode initialize();
  // 
  virtual StatusCode takeAction();

  // Here all the muon specific variables that are needed.
   IHistogram1D* m_h_muonn;
   IHistogram1D* m_h_muonpt1;
   IHistogram1D* m_h_muonetaall;
 IHistogram1D* m_h_muonpairss;
 IHistogram1D* m_h_muonpairos;


 
};

#endif // SUSYMUONHISTTOOL_H
