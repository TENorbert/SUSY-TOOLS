#ifndef mT2Fcn_H
#define mT2Fcn_H

#include "Minuit/FCNBase.h"

#include <vector>

class mT2Fcn : public FCNBase {

 public:

  mT2Fcn(const double& exmiss, 
	 const double& eymiss, 
	 const double& mchi,
	 const double& pT1x,
	 const double& pT1y,
	 const double& pT2x,
	 const double& pT2y) : 
    theExmiss(exmiss),
    theEymiss(eymiss),
    theMchi(mchi),
    thePT1x(pT1x),
    thePT1y(pT1y),
    thePT2x(pT2x),
    thePT2y(pT2y),
    theErrorDef(1.) {}

  ~mT2Fcn() {}

  virtual double up() const {return theErrorDef;}
  virtual double operator()(const std::vector<double>&) const;

  const double exMiss() const {return theExmiss;}
  const double eyMiss() const {return theEymiss;}
  const double mChi() const {return theMchi;}
  const double pT1x() const {return thePT1x;}
  const double pT1y() const {return thePT1y;}
  const double pT2x() const {return thePT2x;}
  const double pT2y() const {return thePT2y;}

  void setErrorDef(double def) {theErrorDef = def;}

 private:

  double theExmiss;
  double theEymiss;
  double theMchi;
  double thePT1x;
  double thePT1y;
  double thePT2x;
  double thePT2y;
  double theErrorDef;
};

#endif //mT2Fcn_H
  
