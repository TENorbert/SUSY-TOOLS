#ifndef MYJETTRUTHHISTTOOL_H
#define MYJETTRUTHHISTTOOL_H
/***********************************************************************
Filename : MyJetTruthHistTool.h
Author   : Frank Paige
Created  : September 2004

Tool to make histograms of jet kinematics.
***********************************************************************/

#include "SUSYPhysUtils/SusyObjectTool.h"
#include <string>

class IHistogram1D;

class MyJetTruthHistTool : public SusyObjectTool
{
public:

  MyJetTruthHistTool(const std::string& type,
                       const std::string& name,
                       const IInterface* parent);

  virtual ~MyJetTruthHistTool();

  virtual StatusCode initialize();
  virtual StatusCode takeAction();

private:

  IHistogram1D* m_h_mcjet_n;
  IHistogram1D* m_h_mcjet_et;
  IHistogram1D* m_h_mcjet_eta10;
  IHistogram1D* m_h_mcjet_eta20;
  IHistogram1D* m_h_mcjet_eta50;
  IHistogram1D* m_h_mcjet_eta100;

  IHistogram1D* m_h_mcjet_rmatch;
  IHistogram1D* m_h_mcjet_etres[16];
  IProfile1D* m_h_mcjet_etprof[16];
  IHistogram1D* m_h_mcjet_etabad[16];

  std::string m_prefix;

  double m_etJetStandardCut;
  double m_maxDeltaRMatchCut;

};

#endif
