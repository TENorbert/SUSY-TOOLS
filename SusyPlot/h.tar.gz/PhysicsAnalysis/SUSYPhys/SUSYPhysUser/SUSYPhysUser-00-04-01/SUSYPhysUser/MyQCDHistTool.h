#ifndef MYQCDHISTTOOL_H
#define MYQCDHISTTOOL_H
/***********************************************************************
Filename : MyQCDHistTool.h
Author   : Frank Paige
Created  : September 2004

Tool to make histograms of jet kinematics.
***********************************************************************/

#include "SUSYPhysUtils/SusyObjectTool.h"
#include <string>

class IHistogram1D;

class MyQCDHistTool : public SusyObjectTool
{
public:

  MyQCDHistTool(const std::string& type,
                       const std::string& name,
                       const IInterface* parent);

  virtual ~MyQCDHistTool();

  virtual StatusCode initialize();
  virtual StatusCode takeAction();

private:

  IHistogram1D* m_h_qcd_pt0;
  IHistogram1D* m_h_qcd_meff;
  IHistogram1D* m_h_qcd_ptnu;
  IHistogram1D* m_h_qcd_ptmu;
  IHistogram1D* m_h_qcd_fracj2;
  IHistogram1D* m_h_qcd_ncharge;
  IHistogram1D* m_h_qcd_fnarrow05;
  IHistogram1D* m_h_qcd_fnarrow10;
  IHistogram1D* m_h_qcd_ptcrack;

  IHistogram1D* m_h_qcd_pt0pass;
  IHistogram1D* m_h_qcd_meffpass;
  IHistogram1D* m_h_qcd_ipass;

  std::string m_prefix;
  std::string m_spclMcName;
  std::string m_muonName;

};

#endif
