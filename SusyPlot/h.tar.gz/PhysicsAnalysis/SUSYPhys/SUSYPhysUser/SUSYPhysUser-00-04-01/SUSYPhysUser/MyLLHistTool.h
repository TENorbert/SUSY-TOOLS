/***********************************************************************
Make all dilepton and related histograms. For now, all events are used:
there are no SUSY selection cuts.
***********************************************************************/

#ifndef SUSYLLHISTTOOL_H
#define SUSYLLHISTTOOL_H 1

#include "SUSYPhysUtils/SusyObjectTool.h"
#include "CLHEP/Vector/LorentzVector.h"
#include <string>

class IHistogram1D;

class MyLLHistTool : public SusyObjectTool {
 public:
  MyLLHistTool(const std::string& type,
		 const std::string& name,
		 const IInterface* parent);

  virtual ~MyLLHistTool();
  
  virtual StatusCode initialize();
  virtual StatusCode takeAction();

 private:

  void llqComb(const HepLorentzVector& ell0, const HepLorentzVector& ell1,
               const IParticleContainer* jets,
               double& mllq, double& mlq1, double& mlq2, double& tllq);

  IHistogram1D* m_h_ee_Mllos;
  IHistogram1D* m_h_ee_Mllss;
  IHistogram1D* m_h_mumu_Mllos;
  IHistogram1D* m_h_mumu_Mllss;
  IHistogram1D* m_h_emu_Mllos;
  IHistogram1D* m_h_emu_Mllss;

  IHistogram1D* m_h_ee_pt;
  IHistogram1D* m_h_emu_pt;
  IHistogram1D* m_h_mumu_pt;
  IHistogram1D* m_h_ee_pt21;
  IHistogram1D* m_h_emu_pt21;
  IHistogram1D* m_h_mumu_pt21;

  IHistogram1D* m_h_ee_Mllq;
  IHistogram1D* m_h_mumu_Mllq;
  IHistogram1D* m_h_emu_Mllq;

  IHistogram1D* m_h_ee_Mlqmx;
  IHistogram1D* m_h_mumu_Mlqmx;
  IHistogram1D* m_h_emu_Mlqmx;

  IHistogram1D* m_h_ee_Mlqmn;
  IHistogram1D* m_h_mumu_Mlqmn;
  IHistogram1D* m_h_emu_Mlqmn;

  IHistogram1D* m_h_ee_Tllq;
  IHistogram1D* m_h_mumu_Tllq;
  IHistogram1D* m_h_emu_Tllq;

  IHistogram1D* m_h_ee_MlqmxR;
  IHistogram1D* m_h_ee_MlqmxL;
  IHistogram1D* m_h_mumu_MlqmxR;
  IHistogram1D* m_h_mumu_MlqmxL;
  IHistogram1D* m_h_emu_MlqmxR;
  IHistogram1D* m_h_emu_MlqmxL;
  IHistogram1D* m_h_ee_MlqmnR;
  IHistogram1D* m_h_ee_MlqmnL;
  IHistogram1D* m_h_mumu_MlqmnR;
  IHistogram1D* m_h_mumu_MlqmnL;
  IHistogram1D* m_h_emu_MlqmnR;
  IHistogram1D* m_h_emu_MlqmnL;

  std::string m_prefix;
  std::string m_softEName;
  std::string m_softMuName;
  double m_pthardcut;

};

#endif // SUSYLLHISTTOOL_H
