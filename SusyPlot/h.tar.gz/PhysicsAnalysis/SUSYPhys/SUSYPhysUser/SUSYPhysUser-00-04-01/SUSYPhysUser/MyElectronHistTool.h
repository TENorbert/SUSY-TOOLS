#ifndef MYELECTRONHISTTOOL_H
#define MYELECTRONHISTTOOL_H

#include "SUSYPhysUtils/SusyObjectTool.h"

class IHistogram1D;

class MyElectronHistTool : public SusyObjectTool {
 public:
  MyElectronHistTool(const std::string& type,
		 const std::string& name,
		 const IInterface* parent);

  virtual ~MyElectronHistTool();
  
  virtual StatusCode initialize();
  virtual StatusCode takeAction();

 private:
  // Here all the electron specific variables that are needed.
   IHistogram1D* m_h_e_n;
   IHistogram1D* m_h_e_pt1;
   IHistogram1D* m_h_e_pt;
   IHistogram1D* m_h_e_ptplus;
   IHistogram1D* m_h_e_ptminus;
   IHistogram1D* m_h_e_eta;
   IHistogram1D* m_h_e_eta20;
   IHistogram1D* m_h_e_eta50;
   IHistogram1D* m_h_softept;
   IHistogram1D* m_h_softeeta;
 
};

#endif // SUSYELECTRONHISTTOOL_H
