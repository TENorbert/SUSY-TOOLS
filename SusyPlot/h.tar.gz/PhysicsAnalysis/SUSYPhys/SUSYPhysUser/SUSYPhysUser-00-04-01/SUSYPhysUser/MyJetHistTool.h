#ifndef MYJETHISTTOOL_H
#define MYJETHISTTOOL_H
/***********************************************************************
Filename : MyJetHistTool.h
Author   : Frank Paige
Created  : September 2004

Tool to make histograms of jet kinematics.
***********************************************************************/

#include "SUSYPhysUtils/SusyObjectTool.h"
#include <string>

class IHistogram1D;

class MyJetHistTool : public SusyObjectTool 
{
public:

  MyJetHistTool(const std::string& type,
                 const std::string& name,
                 const IInterface* parent);

  virtual ~MyJetHistTool();

  virtual StatusCode initialize();
  virtual StatusCode takeAction();

private:

  IHistogram1D* m_h_jetn;
  IHistogram1D* m_h_jetet;
  IHistogram1D* m_h_jetet1;
  IHistogram1D* m_h_jetet2;
  IHistogram1D* m_h_jetm12;
  IHistogram1D* m_h_jeteta10;
  IHistogram1D* m_h_jeteta20;
  IHistogram1D* m_h_jeteta50;
  IHistogram1D* m_h_jeteta100;
  IHistogram1D* m_h_jetetemfrac20;
  IHistogram1D* m_h_jetethadfrac20;

  std::string m_prefix;

  double m_etJetStandardCut;
  double m_maxDeltaR;

};

#endif
