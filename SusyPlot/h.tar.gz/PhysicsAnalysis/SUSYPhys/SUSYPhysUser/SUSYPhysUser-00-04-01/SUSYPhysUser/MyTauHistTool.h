/***********************************************************************
Filename: MyTauHistTool.h
Author:   Frank Paige


***********************************************************************/

#ifndef SUSYTAUHISTTOOL_H
#define SUSYTAUHISTTOOL_H 1

#include "SUSYPhysUtils/SusyObjectTool.h"
#include <string>

class IHistogram1D;

class MyTauHistTool : public SusyObjectTool 
{
 public:
  MyTauHistTool(const std::string& type,
                  const std::string& name,
                  const IInterface* parent);

  virtual ~MyTauHistTool();
  
  virtual StatusCode initialize();
  virtual StatusCode takeAction();

 private:

  // Histograms
  IHistogram1D* m_h_tau_n;
  IHistogram1D* m_h_tau_pt1;
  IHistogram1D* m_h_tau_pt;
  IHistogram1D* m_h_tau_ptplus;
  IHistogram1D* m_h_tau_ptminus;
  IHistogram1D* m_h_tau_etaall;

  IHistogram1D* m_h_tau_Mllos;
  IHistogram1D* m_h_tau_Mllss;
  IHistogram1D* m_h_tau_Mltrkos;
  IHistogram1D* m_h_tau_Mltrkss;
 
  IHistogram1D* m_h_tau_like;
  IHistogram1D* m_h_tau_ntrack;
  IHistogram1D* m_h_tau_rem;
  IHistogram1D* m_h_tau_isofrac;
  IHistogram1D* m_h_tau_stripwidth;
  IHistogram1D* m_h_tau_ntrack1;
  IHistogram1D* m_h_tau_rjet;
  IHistogram1D* m_h_tau_etfracjet;

  IHistogram1D* m_h_tau_nisotrk;
  IHistogram1D* m_h_tau_ptisotrk;

  // JobOptions
  std::string m_prefix;
  std::string m_trackKey;
  std::string m_SusyTrackKey;
  double m_ettauStandardCut;
  double m_ettauHardCut;
  double m_etTrkCut;

};

#endif // SUSYTAUHISTTOOL_H
