#ifndef MYTAUTRUTHHISTTOOL_H
#define MYTAUTRUTHHISTTOOL_H
/***********************************************************************
Filename : MyTauTruthHistTool.h
Author   : Frank Paige
Created  : September 2004

Tool to make histograms of Tau kinematics.
***********************************************************************/

#include "SUSYPhysUtils/SusyObjectTool.h"
#include <string>

class IHistogram1D;

class MyTauTruthHistTool : public SusyObjectTool
{
public:

  MyTauTruthHistTool(const std::string& type,
                       const std::string& name,
                       const IInterface* parent);

  virtual ~MyTauTruthHistTool();

  virtual StatusCode initialize();
  virtual StatusCode takeAction();

private:

  IHistogram1D* m_h_mctau_n;
  IHistogram1D* m_h_mctau_et;
  IHistogram1D* m_h_mctau_etvis;
  IHistogram1D* m_h_mctau_etvisplus;
  IHistogram1D* m_h_mctau_etvisminus;
  IHistogram1D* m_h_mctau_mvis;
  IHistogram1D* m_h_mctau_visfrac;
  IHistogram1D* m_h_mctau_eta;
  IHistogram1D* m_h_mctau_rmatch;
  IHistogram1D* m_h_mctau_rmatch50;
  IHistogram1D* m_h_mctau_rmatch100;
  IHistogram1D* m_h_mctau_etres;
  IHistogram1D* m_h_mctau_etresTrue;
  IHistogram1D* m_h_mctau_pcheck;
  IHistogram1D* m_h_mctau_rjet;
  IHistogram1D* m_h_mctau_badlike;
  IHistogram1D* m_h_mctau_badn;
  IHistogram1D* m_h_mctau_badrat;

  std::string m_prefix;

  double m_ettauStandardCut;
  double m_maxDeltaRMatchCut;
  std::string m_jetInputKey;
  std::string m_spclInputKey;

};

#endif
