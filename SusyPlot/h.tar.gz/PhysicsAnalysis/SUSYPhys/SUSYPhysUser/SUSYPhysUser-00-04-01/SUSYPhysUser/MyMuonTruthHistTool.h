#ifndef MYMUONTRUTHHISTTOOL_H
#define MYMUONTRUTHHISTTOOL_H
/***********************************************************************
Filename : MyMuonTruthHistTool.h
Author   : Frank Paige
Created  : September 2004

Tool to make histograms of muon kinematics.
***********************************************************************/

#include "SUSYPhysUtils/SusyObjectTool.h"
#include <string>

class IHistogram1D;

class MyMuonTruthHistTool : public SusyObjectTool
{
public:

  MyMuonTruthHistTool(const std::string& type,
                        const std::string& name,
                        const IInterface* parent);

  virtual ~MyMuonTruthHistTool();

  virtual StatusCode initialize();
  virtual StatusCode takeAction();

private:

  IHistogram1D* m_h_mcmu_n;
  IHistogram1D* m_h_mcmu_pt;
  IHistogram1D* m_h_mcmu_ptplus;
  IHistogram1D* m_h_mcmu_ptminus;
  IHistogram1D* m_h_mcmu_eta;
  IHistogram1D* m_h_mcmu_rmatch;
  IHistogram1D* m_h_mcmu_rmatch20;
  IHistogram1D* m_h_mcmu_rmatch50;
  IHistogram1D* m_h_mcmu_etres;
  IHistogram1D* m_h_mcmu_mllos;
  IHistogram1D* m_h_mcmu_mllosz;
  IHistogram1D* m_h_mcemu_Mllos;
  IHistogram1D* m_h_mcmu_chi2;

  IHistogram1D* m_h_mcmu_ptbad;
  IHistogram1D* m_h_mcmu_etabad;
  IHistogram1D* m_h_mcmu_phibad;
  IHistogram1D* m_h_mcmu_isolbad;
  IHistogram1D* m_h_mcmu_chi2bad;
  IHistogram1D* m_h_mcmu_idbad;
  IHistogram1D* m_h_mcmu_ptrbad;
  IHistogram1D* m_h_mcmu_isolfracbad;
  IHistogram1D* m_h_mcmu_isolcheckbad;

  IHistogram1D* m_h_mcmu_failr;
  IHistogram1D* m_h_mcmu_failchi2;
  IHistogram1D* m_h_mcmu_failisol;

  std::string m_prefix;
  double m_etMuonStandardCut;
  double m_maxDeltaRMatchCut;
  std::string m_spclMcName;
  std::string m_muonName;

};

#endif
