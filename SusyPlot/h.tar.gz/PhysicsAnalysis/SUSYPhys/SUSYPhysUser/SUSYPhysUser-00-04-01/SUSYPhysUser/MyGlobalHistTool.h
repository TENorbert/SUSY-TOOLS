#ifndef MYGLOBALHISTTOOL_H
#define MYGLOBALHISTTOOL_H
/***********************************************************************
Filename : MyGlobalHistTool.h
Author   : Frank Paige
Created  : September 2004

Tool to make histograms of etmiss.
***********************************************************************/

#include "SUSYPhysUtils/SusyObjectTool.h"
#include <string>

class IHistogram1D;

class MyGlobalHistTool : public SusyObjectTool 
{
public:

  MyGlobalHistTool(const std::string& type,
                 const std::string& name,
                 const IInterface* parent);

  virtual ~MyGlobalHistTool();

  virtual StatusCode initialize();
  virtual StatusCode takeAction();

private:
  
  IHistogram1D* m_h_miss_ex;
  IHistogram1D* m_h_miss_ey;
  IHistogram1D* m_h_miss_et;
  IHistogram1D* m_h_miss_etcut;
  IHistogram1D* m_h_miss_etfinal;
  IHistogram1D* m_h_miss_etsum;

  IHistogram1D* m_h_mcmiss_ex;
  IHistogram1D* m_h_mcmiss_ey;
  IHistogram1D* m_h_mcmiss_et;
  IHistogram1D* m_h_mcmiss_etcut;
  IHistogram1D* m_h_mcmiss_etsum;

  IHistogram1D* m_h_mcmiss_dex;
  IHistogram1D* m_h_mcmiss_dey;
  IHistogram1D* m_h_mcmiss_det;
  IHistogram1D* m_h_mcmiss_detcut;
  IHistogram1D* m_h_mcmiss_detsum;

  IHistogram1D* m_h_mcmiss_jetet;
  IHistogram1D* m_h_mcmiss_jeteta;
  IHistogram1D* m_h_mcmiss_jetdphi;
  IHistogram1D* m_h_mcmiss_jetphimin;
  IHistogram1D* m_h_mcmiss_jetphimax;
  IHistogram1D* m_h_mcmiss_jetetamin;

  IHistogram1D* m_h_miss_mupt;
  IHistogram1D* m_h_miss_muchi2;
  IHistogram1D* m_h_miss_mueta;
  IHistogram1D* m_h_miss_mueta50;
  IHistogram1D* m_h_miss_muidrat;
  IHistogram1D* m_h_miss_mumoorat;
  IHistogram1D* m_h_miss_mumdt;
  IHistogram1D* m_h_miss_mun;

  IHistogram1D* m_h_miss_mumcpt;
  IHistogram1D* m_h_miss_mumcr;

  IHistogram1D* m_h_susy0id;
  IHistogram1D* m_h_susy1id;
  IHistogram1D* m_h_susy2id;

  IHistogram1D* m_h_meff;
  IHistogram1D* m_h_meff4j;
  IHistogram1D* m_h_meff4jcut;
  IHistogram1D* m_h_meff4jlep;
  IHistogram1D* m_h_mtlx;
  IHistogram1D* m_h_meff4jlepcut;

  std::string m_prefix;
  std::string m_spclMcName;
  std::string m_muonContainerName;
  std::string m_muonMcName;
  double m_muonChi2Cut;
  std::string m_metName;
  double m_muonMooreCut;
  int m_muonMDTCut;

};

#endif
