#ifndef MYMUONHISTTOOL_H
#define MYMUONHISTTOOL_H 1
#include "SUSYPhysUtils/SusyObjectTool.h"
class IHistogram1D;
class MyMuonHistTool : public SusyObjectTool {
 public:
  MyMuonHistTool(const std::string& type,
		 const std::string& name,
		 const IInterface* parent);

  virtual ~MyMuonHistTool();
  
  //
  virtual StatusCode initialize();
  // 
  virtual StatusCode takeAction();

 private:

  // Here all the muon specific variables that are needed.
   IHistogram1D* m_h_mu_n;
   IHistogram1D* m_h_mu_pt1;
   IHistogram1D* m_h_mu_pt;
   IHistogram1D* m_h_mu_ptplus;
   IHistogram1D* m_h_mu_ptminus;
   IHistogram1D* m_h_mu_etaall;
   IHistogram1D* m_h_mu_isol;
   IHistogram1D* m_h_mu_chi2;

   int m_fix90x;

};

#endif // SUSYMUONHISTTOOL_H
