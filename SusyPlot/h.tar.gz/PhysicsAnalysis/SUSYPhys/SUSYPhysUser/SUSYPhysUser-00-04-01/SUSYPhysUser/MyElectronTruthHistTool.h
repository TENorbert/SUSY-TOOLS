#ifndef MYELECTRONTRUTHHISTTOOL_H
#define MYELECTRONTRUTHHISTTOOL_H
/***********************************************************************
Filename : MyElectronTruthHistTool.h
Author   : Frank Paige
Created  : September 2004

Tool to make histograms of Electron kinematics.
***********************************************************************/

#include "SUSYPhysUtils/SusyObjectTool.h"
#include <string>

class IHistogram1D;
class IHistogram2D;

class MyElectronTruthHistTool : public SusyObjectTool
{
public:

  MyElectronTruthHistTool(const std::string& type,
                            const std::string& name,
                            const IInterface* parent);

  virtual ~MyElectronTruthHistTool();

  virtual StatusCode initialize();
  virtual StatusCode takeAction();

private:

  IHistogram1D* m_h_mce_n;
  IHistogram1D* m_h_mce_pt;
  IHistogram1D* m_h_mce_ptplus;
  IHistogram1D* m_h_mce_ptminus;
  IHistogram1D* m_h_mce_eta;
  IHistogram1D* m_h_mce_eta20;
  IHistogram1D* m_h_mce_eta50;
  IHistogram1D* m_h_mce_rmatch;
  IHistogram1D* m_h_mce_rmatch20;
  IHistogram1D* m_h_mce_rmatch50;
  IHistogram1D* m_h_mce_rmatchTk;
  IHistogram1D* m_h_mce_etres;
  IHistogram1D* m_h_mce_mllos;
  IHistogram1D* m_h_mce_mllosz;

  IHistogram1D* m_h_mce_goodemWeight;
  IHistogram1D* m_h_mce_goodepiNN;
  IHistogram1D* m_h_mce_goodeta;
  IHistogram1D* m_h_mce_goodEp;
  IHistogram1D* m_h_mce_goodIsol;
  IHistogram1D* m_h_mce_goodetHad1;
  IHistogram1D* m_h_mce_goodEMbits;

  IHistogram1D* m_h_mce_bademWeight;
  IHistogram1D* m_h_mce_badepiNN;
  IHistogram1D* m_h_mce_badeta;
  IHistogram1D* m_h_mce_badEp;
  IHistogram1D* m_h_mce_badIsol;
  IHistogram1D* m_h_mce_badetHad1;
  IHistogram1D* m_h_mce_badEMbits;
  IHistogram1D* m_h_mce_badRtau;
  IHistogram1D* m_h_mce_badRelec;
  IHistogram2D* m_h_mce_badIsol2D;
  IHistogram1D* m_h_mce_badPtres;

  IHistogram1D* m_h_mce_goodEp200;
  IHistogram1D* m_h_mce_goodetHad1200;

  std::string m_prefix;
  double m_etElectronStandardCut;
  double m_maxDeltaRMatchCut;
  std::string m_spclMcName;
  std::string m_electronKey;
  std::string m_photonKey;
  std::string m_trackKey;
  std::string m_jetKey;

};

#endif
