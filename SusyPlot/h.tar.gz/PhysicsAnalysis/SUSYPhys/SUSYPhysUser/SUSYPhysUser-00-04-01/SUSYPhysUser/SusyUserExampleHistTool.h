#ifndef SUSYEXAMPLEHISTTOOL_H
#define SUSYEXAMPLEHISTTOOL_H 1
#include "SUSYPhysUtils/SusyObjectTool.h"
class IHistogram1D;
class SusyUserExampleHistTool : public SusyObjectTool {
 public:
  SusyUserExampleHistTool(const std::string& type,
		 const std::string& name,
		 const IInterface* parent);

  virtual ~SusyUserExampleHistTool();
  
  //
  virtual StatusCode initialize();
  virtual StatusCode finalize();
  // 
  virtual StatusCode takeAction();

  // Here all the electron specific variables that are needed.
  std::string m_prefix;
    
  IHistogram1D* m_h_electronn;
  IHistogram1D* m_h_electronpt1;
  IHistogram1D* m_h_electronpt2;
  IHistogram1D* m_h_electronetaall;
  IHistogram1D* m_h_electronpairss;
  IHistogram1D* m_h_electronpairos;
  
  IHistogram1D* m_h_muonn;
  IHistogram1D* m_h_muonpt1;
  IHistogram1D* m_h_muonpt2;
  IHistogram1D* m_h_muonetaall;
  IHistogram1D* m_h_muonpairss;
  IHistogram1D* m_h_muonpairos;
  
  
  IHistogram1D* m_h_emupairos;
  IHistogram1D* m_h_emupairss;
  
  IHistogram1D* m_h_etmiss;
  IHistogram1D* m_h_meff;
  
  IHistogram1D* m_h_taun;
  IHistogram1D* m_h_taupt1;
  IHistogram1D* m_h_taupt2;
  IHistogram1D* m_h_tauetaall;
  IHistogram1D* m_h_taupairss;
  IHistogram1D* m_h_taupairos;
  
  IHistogram1D* m_h_leptonspairs;
  IHistogram1D* m_h_leptonspairssub;

  IHistogram1D* m_h_mt2;
  
 private:

  double m_mchi;
};

#endif // SUSYELECTRONHISTTOOL_H
