/***********************************************************************
Make all dilepton and related histograms. For now, all events are used:
there are no SUSY selection cuts.
***********************************************************************/

#ifndef SUSYLLTRUTHHISTTOOL_H
#define SUSYLLTRUTHHISTTOOL_H 1

#include "SUSYPhysUtils/SusyObjectTool.h"
#include "CLHEP/Vector/LorentzVector.h"
#include <string>

class IHistogram1D;

class MyLLTruthHistTool : public SusyObjectTool {
 public:
  MyLLTruthHistTool(const std::string& type,
		 const std::string& name,
		 const IInterface* parent);

  virtual ~MyLLTruthHistTool();
  
  virtual StatusCode initialize();
  virtual StatusCode takeAction();

 private:

  void llqComb(const HepLorentzVector& ell0, const HepLorentzVector& ell1,
               const IParticleContainer* jets,
               double& mllq, double& mlq1, double& mlq2, double& tllq);

  IHistogram1D* m_h_chi2_etnearL;
  IHistogram1D* m_h_chi2_etfarL;
  IHistogram1D* m_h_chi2_mpairL;

  IHistogram1D* m_h_chi2_etnearR;
  IHistogram1D* m_h_chi2_etfarR;
  IHistogram1D* m_h_chi2_mpairR;

  IHistogram1D* m_h_mcemu_ptmx;
  IHistogram1D* m_h_mcemu_id0;
  IHistogram1D* m_h_mcemu_id1;
  IHistogram1D* m_h_mcemu_id2;

  std::string m_prefix;
  std::string m_spclMcName;
  std::string m_softEName;
  double m_ptHardCut;
  std::string m_electronKey;
  std::string m_trackKey;



};

#endif // SUSYLLTRUTHHISTTOOL_H
