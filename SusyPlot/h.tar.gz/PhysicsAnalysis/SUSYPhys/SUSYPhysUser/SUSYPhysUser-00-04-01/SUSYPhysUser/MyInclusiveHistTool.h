#ifndef MYINCLUSIVEHISTTOOL_H
#define MYINCLUSIVEHISTTOOL_H
/***********************************************************************
Filename : MyInclusiveHistTool.h
Author   : Frank Paige
Created  : September 2004

Tool to make histograms of etmiss.
***********************************************************************/

#include "SUSYPhysUtils/SusyObjectTool.h"
#include <string>

class IHistogram1D;

class MyInclusiveHistTool : public SusyObjectTool 
{
public:

  MyInclusiveHistTool(const std::string& type,
                 const std::string& name,
                 const IInterface* parent);

  virtual ~MyInclusiveHistTool();

  virtual StatusCode initialize();
  virtual StatusCode takeAction();

private:

  IHistogram1D* m_h_meff;

  int m_njet_cut;
  double m_jetpt1_cut;
  double m_jetpt2_cut;
  double m_jetpt3_cut;
  double m_jetpt4_cut;
  double m_etmiss_cut;
  double m_etmissfrac_cut;
  double m_meff_cut;
  double m_jetpt_cut;

  std::string m_inputKey;
  std::string m_prefix;

};

#endif
