// --------------------------------------------------
// 
// Algorithm to select global properties and create an object
// for Susy analysis
//
// --------------------------------------------------

#ifndef SUSYPHYSALGS_SUSYGLOBALMCCREATOR_H
#define SUSYPHYSALGS_SUSYGLOBALMCCREATOR_H

#include "SUSYPhysAlgs/SusyCreator.h"

class SusyGlobalMcCreator : public SusyCreator {
 public:
        SusyGlobalMcCreator(const std::string& name, ISvcLocator* pSvcLocator);
        ~SusyGlobalMcCreator();
	virtual StatusCode finalize();
	virtual StatusCode execute();

 private:

};

#endif
