// --------------------------------------------------
// 
// Algorithm to select photons from SpcMC and create a collection 
// for Susy analysis
//
// --------------------------------------------------

#ifndef SUSYPHYSALGS_SUSYPHOTONMCCREATOR_H
#define SUSYPHYSALGS_SUSYPHOTONMCCREATOR_H

#include "SUSYPhysAlgs/SusyCreator.h"

class SusyPhotonMcCreator : public SusyCreator {
 public:
  SusyPhotonMcCreator(const std::string& name, ISvcLocator* pSvcLocator);
  ~SusyPhotonMcCreator();
  virtual StatusCode finalize();
  virtual StatusCode execute();

 private:

};

#endif
