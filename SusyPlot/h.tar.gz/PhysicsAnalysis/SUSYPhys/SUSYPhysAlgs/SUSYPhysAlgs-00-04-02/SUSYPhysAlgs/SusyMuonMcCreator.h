// --------------------------------------------------
// 
// Algorithm to select muons from SpclMC and create a collection 
// for Susy analysis
//
// --------------------------------------------------

#ifndef SUSYPHYSALGS_SUSYMUONMCCREATOR_H
#define SUSYPHYSALGS_SUSYMUONMCCREATOR_H

#include "SUSYPhysAlgs/SusyCreator.h"

class SusyMuonMcCreator : public SusyCreator {
 public:
        SusyMuonMcCreator(const std::string& name, ISvcLocator* pSvcLocator);
        ~SusyMuonMcCreator();
	virtual StatusCode finalize();
	virtual StatusCode execute();

 private:
        double m_isolation;
};

#endif
