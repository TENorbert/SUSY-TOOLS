
//SusyPlot.h
// Description: Algorithm into which selector and plotter tools are pushed.
// AuthorList: see cxx for details
//         Ian Hinchliffe :  Initial Code August 2004

#ifndef SUSYPHYSALGS_SUSYPLOT_H
#define SUSYPHYSALGS_SUSYPLOT_H
 
#include "GaudiKernel/Algorithm.h"
#include "SUSYPhysUtils/SusyTypes.h"
#include "SUSYPhysUtils/ISusyObjectTool.h" 
#include <string>

class SusyPlot : public Algorithm {
 public:
        SusyPlot(const std::string& name, ISvcLocator* pSvcLocator);
        virtual ~SusyPlot();
        StatusCode initialize();
        StatusCode execute();
        StatusCode finalize();

 private:
	// private function. Given a list of string (input key) creates a 
	// SusyBag for the Algorithm to handle
        StatusCode FillBag(const std::vector<std::string>&, SusyBag&);
	int m_in, m_out; 
 protected:
        // Cached variables:
 
        // Local Member Data:
	std::vector<std::string> m_inputPlotVec, m_inputSelVec;
        SusyBag m_inputPlotKey; // set of keys to be used by hist tools
        SusyBag m_inputSelKey; // set of keys to be used by selector tools
        SusyBag m_outputSelKey; // set of keys to be used by selector tools
        SusyBag m_outputRedKey; // set of keys to be returned by redundancy tools
	std::vector<std::string> m_histList; // list of histogram tools to be used.
	std::string m_selector; //name of selector tool to be used
	std::string m_redundancy; //name of redundancy tool to be used
        ISusyObjectTool* m_seltools ; // the pointer to the selection tool
        ISusyObjectTool* m_redtools ; // the pointer to the redundancy tool
	std::vector<ISusyObjectTool*> m_histtools; // contains the hist tool pointers
};
 

susy::SusyTypes giveSusyType(const std::string theType);

#endif
