#ifndef SUSYPHYSALGS_SUSYCREATOR_H
#define SUSYPHYSALGS_SUSYCREATOR_H

#include "GaudiKernel/Algorithm.h"
#include "StoreGate/StoreGateSvc.h"
#include "CLHEP/Units/SystemOfUnits.h"


class SusyCreator : public Algorithm {
 public:
        SusyCreator(const std::string& name, ISvcLocator* pSvcLocator);
        virtual ~SusyCreator();
	StatusCode initialize();

 protected:
	// Cached variables:
	StoreGateSvc* m_pSG;

	// Local Member Data:
	double m_Ptmin;
	double m_EtaCut;
	std::string m_inputKey, m_outputKey;


};

#endif
