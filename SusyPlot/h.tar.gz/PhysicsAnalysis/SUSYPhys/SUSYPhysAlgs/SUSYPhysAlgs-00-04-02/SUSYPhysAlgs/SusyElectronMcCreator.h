// --------------------------------------------------
// 
// Algorithm to select electrons from SpcMC and create a collection 
// for Susy analysis
//
// --------------------------------------------------

#ifndef SUSYPHYSALGS_SUSYELECTRONMCCREATOR_H
#define SUSYPHYSALGS_SUSYELECTRONMCCREATOR_H

#include "SUSYPhysAlgs/SusyCreator.h"

class SusyElectronMcCreator : public SusyCreator {
 public:
  SusyElectronMcCreator(const std::string& name, ISvcLocator* pSvcLocator);
  ~SusyElectronMcCreator();
  virtual StatusCode finalize();
  virtual StatusCode execute();

 private:
  double m_isolation;
};

#endif
