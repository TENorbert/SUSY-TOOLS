// --------------------------------------------------
// 
// Algorithm to select taus and create a collection 
// for Susy analysis
//
// --------------------------------------------------

#ifndef SUSYPHYSALGS_SUSYTAUCREATOR_H
#define SUSYPHYSALGS_SUSYTAUCREATOR_H

#include "SUSYPhysAlgs/SusyCreator.h"
#include <string>

class IParticle;
class IParticleContainer;

class SusyTauCreator : public SusyCreator {
 public:
  SusyTauCreator(const std::string& name, ISvcLocator* pSvcLocator);
  ~SusyTauCreator();
  virtual StatusCode finalize();
  virtual StatusCode execute();

 private:
  double m_likelihoodCut;
  double m_likelihoodSlope;
  double m_likelihoodCut3;
  std::string m_trackKey;
  int m_extraTrack1;
  double m_hadFraction;
  double m_hadTotal;

};

#endif
