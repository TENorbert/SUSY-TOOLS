// --------------------------------------------------
// 
// Algorithm to select electrons and create a collection 
// for Susy analysis
//
// --------------------------------------------------

#ifndef SUSYPHYSALGS_SUSYELECTRONCREATOR_H
#define SUSYPHYSALGS_SUSYELECTRONCREATOR_H

#include "SUSYPhysAlgs/SusyCreator.h"

class SusyElectronCreator : public SusyCreator {
 public:
  SusyElectronCreator(const std::string& name, ISvcLocator* pSvcLocator);
  ~SusyElectronCreator();
  virtual StatusCode finalize();
  virtual StatusCode execute();

 private:
  bool m_useSofte;
  bool m_applyTRTCuts;
  double m_isolation;
  double m_epiNNCut;
  double m_epiWeightCut;
  std::string m_trackKey;
  double m_trackIsolation;

};

#endif
