// --------------------------------------------------
// 
// Algorithm to select jets and create a collection 
// for Susy analysis
//
// --------------------------------------------------

#ifndef SUSYPHYSALGS_SUSYJETTRUTHCREATOR_H
#define SUSYPHYSALGS_SUSYJETTRUTHCREATOR_H

#include "SUSYPhysAlgs/SusyCreator.h"
#include <string>

class IParticle;
class IParticleContainer;

class SusyJetTruthCreator : public SusyCreator {
 public:
  SusyJetTruthCreator(const std::string& name, ISvcLocator* pSvcLocator);
  ~SusyJetTruthCreator();
  virtual StatusCode finalize();
  virtual StatusCode execute();

 private:

};

#endif
