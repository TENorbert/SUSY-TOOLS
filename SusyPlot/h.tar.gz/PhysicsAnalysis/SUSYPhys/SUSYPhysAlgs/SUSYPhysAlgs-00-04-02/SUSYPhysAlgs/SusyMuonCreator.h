// --------------------------------------------------
// 
// Algorithm to select muons and create a collection 
// for Susy analysis
//
// --------------------------------------------------

#ifndef SUSYPHYSALGS_SUSYMUONCREATOR_H
#define SUSYPHYSALGS_SUSYMUONCREATOR_H

#include "SUSYPhysAlgs/SusyCreator.h"

class SusyMuonCreator : public SusyCreator {
 public:
  SusyMuonCreator(const std::string& name, ISvcLocator* pSvcLocator);
  ~SusyMuonCreator();
  virtual StatusCode finalize();
  virtual StatusCode execute();

 private:
  double m_Chi2;
  double m_Chi2Slope;
  double m_isolation;
};

#endif
