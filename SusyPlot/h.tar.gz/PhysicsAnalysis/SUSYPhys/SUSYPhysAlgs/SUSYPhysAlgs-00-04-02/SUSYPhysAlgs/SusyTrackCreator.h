// --------------------------------------------------
// 
// Algorithm to select taus and create a collection 
// for Susy analysis
//
// --------------------------------------------------

#ifndef SUSYPHYSALGS_SUSYTRACKCREATOR_H
#define SUSYPHYSALGS_SUSYTRACKCREATOR_H

#include "SUSYPhysAlgs/SusyCreator.h"
#include <string>

class IParticle;
class IParticleContainer;

class SusyTrackCreator : public SusyCreator {
 public:
  SusyTrackCreator(const std::string& name, ISvcLocator* pSvcLocator);
  ~SusyTrackCreator();
  virtual StatusCode finalize();
  virtual StatusCode execute();

 private:
  double m_ptCut;
  double m_ptIsolCut;
  double m_ptIsolR;

};

#endif
