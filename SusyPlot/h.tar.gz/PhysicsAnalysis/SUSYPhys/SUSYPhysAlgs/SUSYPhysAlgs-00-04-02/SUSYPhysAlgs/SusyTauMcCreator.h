// --------------------------------------------------
// 
// Algorithm to select taus from SpclMC and create a collection 
// for Susy analysis
//
// --------------------------------------------------

#ifndef SUSYPHYSALGS_SUSYTAUMCCREATOR_H
#define SUSYPHYSALGS_SUSYTAUMCCREATOR_H

#include "SUSYPhysAlgs/SusyCreator.h"

class SusyTauMcCreator : public SusyCreator {
 public:
        SusyTauMcCreator(const std::string& name, ISvcLocator* pSvcLocator);
        ~SusyTauMcCreator();
	virtual StatusCode finalize();
	virtual StatusCode execute();

 private:
        double m_isolation;
};

#endif
