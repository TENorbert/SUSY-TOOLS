// --------------------------------------------------
// 
// Algorithm to select muons and create a collection 
// for Susy analysis
//
// --------------------------------------------------

#ifndef SUSYPHYSALGS_SUSYJETCREATOR_H
#define SUSYPHYSALGS_SUSYJETCREATOR_H

#include "SUSYPhysAlgs/SusyCreator.h"

class SusyJetCreator : public SusyCreator {
 public:
        SusyJetCreator(const std::string& name, ISvcLocator* pSvcLocator);
        ~SusyJetCreator();
	virtual StatusCode finalize();
	virtual StatusCode execute();

 private:

};

#endif
