// --------------------------------------------------
// 
// Algorithm to select photons and create a collection 
// for Susy analysis
//
// --------------------------------------------------

#ifndef SUSYPHYSALGS_SUSYPHOTONCREATOR_H
#define SUSYPHYSALGS_SUSYPHOTONCREATOR_H

#include "SUSYPhysAlgs/SusyCreator.h"

class SusyPhotonCreator : public SusyCreator {
 public:
        SusyPhotonCreator(const std::string& name, ISvcLocator* pSvcLocator);
        ~SusyPhotonCreator();
	virtual StatusCode finalize();
	virtual StatusCode execute();

 private:
};

#endif
