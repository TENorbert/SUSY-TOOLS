// --------------------------------------------------
// 
// Algorithm to select bjets and create a collection 
// for Susy analysis
// Created from SusyJetCreator.h (Fredrik Tegenfeldt 2004)
//
// --------------------------------------------------

#ifndef SUSYPHYSALGS_SUSYBJETCREATOR_H
#define SUSYPHYSALGS_SUSYBJETCREATOR_H

#include "SUSYPhysAlgs/SusyCreator.h"

class SusyBJetCreator : public SusyCreator {
public:
  SusyBJetCreator(const std::string& name, ISvcLocator* pSvcLocator);
  ~SusyBJetCreator();
  virtual StatusCode finalize();
  virtual StatusCode execute();
  
private:

protected:
  double m_lhSigCut;
  double m_lhBkgCut;
};

#endif
