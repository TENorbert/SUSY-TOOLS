// --------------------------------------------------
// 
// Algorithm to select global properties and create an object
// for Susy analysis
//
// --------------------------------------------------

#ifndef SUSYPHYSALGS_SUSYGLOBALCREATOR_H
#define SUSYPHYSALGS_SUSYGLOBALCREATOR_H

#include "SUSYPhysAlgs/SusyCreator.h"

class SusyGlobalCreator : public SusyCreator {
 public:
  SusyGlobalCreator(const std::string& name, ISvcLocator* pSvcLocator);
  ~SusyGlobalCreator();
  virtual StatusCode finalize();
  virtual StatusCode execute();

 private:
  std::string m_sim;
  std::string m_metMuonName;
  std::string m_muonContainerName;
  double m_muonChi2Cut;
  double m_muonIsolCut;
  double m_muonMooreCut;
  int m_muonMDTCut;

};

#endif
