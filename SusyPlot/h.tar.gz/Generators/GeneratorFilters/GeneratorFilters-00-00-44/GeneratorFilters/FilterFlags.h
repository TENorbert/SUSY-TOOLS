#ifndef GENERATORFILTERSFILTERFLAGS_H
#define GENERATORFILTERSFILTERFLAGS_H
//Class to contain the filter names and results than can be put into storegate
//it just wraps a collection of strings and bools
// Ian Hinchliffe May 2002
//
#include <string>
#include <vector>

class FilterFlags  {
public: 
  FilterFlags() {};
  FilterFlags(std::vector<std::string> list, std::vector<bool> list_val ) ;
  FilterFlags(std::string str , bool val) ;
  virtual ~FilterFlags(){};
  std::vector<std::string> names() const;
  std::vector<bool> values() const;
  int length() const;
  void add_value(bool m);
  void add_names(std::string part);
private:
  std::vector<std::string>  m_tname; // name of filters
  std::vector<bool>  m_tpass; // state of filter
};
//This is required and checked at compile time when you try to record/retrieve
#include "CLIDSvc/CLASS_DEF.h"
  CLASS_DEF(FilterFlags, 20244, 1) 
#endif

