/*
File: GeneratorFilters/QCDBkgFilter.h

Description: Select QCD jet events that are (potential) backgrounds for
other physics. Selection criteria are 0 plus any of 1-5:
0       ptj0 > 75GeV, Meff > 300GeV
1       N >= 2 extra jets with pt > 50GeV, 0.1*Meff && ptjsum/Meff > 0.30
2       ptnu > 50GeV
3       ptmu > 10GeV && ETisol < 25GeV
4       ptj > 100GeV && 2.9 < etaj < 3.5
5       Nch <= 3 && Q <= 1 && ( pt(.05)/ptj > 0.8 && pt(.10)/ptj > 0.9 )
        && Mch < 2.5GeV && any of cuts 1-4

Author:
Frank Paige, June 2005
*/


#ifndef GENERATORFILTERSQCDBKGFILTER_H
#define GENERATORFILTERSQCDBKGFILTER_H

#include "GenFilter.h"
#include "CLHEP/HepPDT/ParticleDataTable.hh"

#include <string>


class QCDBkgFilter : public GenFilter {
 public:
  QCDBkgFilter(const std::string& name, ISvcLocator* pSvcLocator);
  virtual ~QCDBkgFilter();
  virtual StatusCode filterInitialize();
  virtual StatusCode filterFinalize();
  virtual StatusCode filterEvent();

 private:

  std::string m_JetCollectionName;
  double m_ptj0Cut;
  double m_meffCut;
  double m_ptjCut;
  double m_fracjCut;
  double m_njsumCut;
  double m_fracjsumCut;
  double m_ptnuCut;
  double m_fracnuCut;
  double m_ptmuCut;
  double m_isolmuCut;
  double m_ptThinJetCut;
  double m_mThinJetCut;
  double m_frac05ThinJetCut;
  double m_frac10ThinJetCut;
  double m_crackEtaMin;
  double m_crackEtaMax;
  double m_crackPtCut;

  HepPDT::ParticleDataTable* m_particleTable;

};

#endif
