// --------------------------------------------------
// 
// File:  GeneratorFilters/PhotonFilter.h
// Description:
// Filters and looks for photons
//
// AuthorList:
//         I Hinchliffe:  May 2004


#ifndef GENERATORFILTERSPHOTONFILTER_H
#define GENERATORFILTERSPHOTONFILTER_H

#include "GenFilter.h"




class PhotonFilter:public GenFilter {
public:
        PhotonFilter(const std::string& name, ISvcLocator* pSvcLocator);
        virtual ~PhotonFilter();
        virtual StatusCode filterInitialize();
        virtual StatusCode filterFinalize();
        virtual StatusCode filterEvent();

private:
	// Setable Properties:-

	double m_Ptmin;
	double m_EtaRange;
        int m_NPhotons; 
	// Private Methods:=

};

#endif
