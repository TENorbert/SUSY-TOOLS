// --------------------------------------------------
// 
// File:  GeneratorFilters//HLTDC1Filter.h
// Description:
// Filters and looks for electrons
//
// AuthorList:
//         I Hinchliffe: MAY 2002
// added user settable properties sept 2002


#ifndef GENERATORFILTERSJETFILTER_H
#define GENERATORFILTERSJETFILTER_H

#include "GenFilter.h"
#include "CLHEP/Vector/LorentzVector.h"
#include "McObj.h"
#include <math.h>



class JetFilter:public GenFilter {
public:
        JetFilter(const std::string& name, ISvcLocator* pSvcLocator);
        virtual ~JetFilter();
        virtual StatusCode filterInitialize();
        virtual StatusCode filterFinalize();
        virtual StatusCode filterEvent();

private:
	// Fixed Properties:-
	static const int m_grphi=105 ; // -pi to pi in units of 0.06 (approx)
	static const int m_greta=200 ; // -6.0 to 6.0 in units 0.06 {approx}
	// Setable Properties:-
	double m_UserEta;  //range over which triggers are searched for
	int m_UserNumber; // how many are we looking for
	double  m_UserThresh; // lowest et jet
	double m_Stop; //seed tower threshold
        double m_Cone; //cone sixe
	int m_Gride; //how many cells in eta
	int m_Gridp; //how many cells in phi
	bool m_Type; // cone or grid to define jet
	// internal parameters
	double m_EtaRange; //range over which search runs
	double m_emaxeta; // largest eta of bins
	double m_edeta; // size of eta bins
	double m_edphi; //size of phi bins
	double m_twopi; //twopi
	int m_nphicell; // number of phi cells inside half cone
	int m_netacell; // number of eta cells inside half cone
	int m_nphicell2; // number of phi cells inside full cone
	int m_netacell2; // number of eta cells inside full cone
	std::vector<McObj> m_Jets; //store jets

	// Private Methods:=

};

#endif
