// --------------------------------------------------
// 
// File:  GeneratorFilters/ZtoLeptonFilter.h
// Description:
// Filters and looks for Z's decaying to leptons
//
// AuthorList:
//         I Hinchliffe Jan 2001


#ifndef GENERATORFILTERSZTOLEPTONFILTER_H
#define GENERATORFILTERSZTOLEPTONFILTER_H

#include "GenFilter.h"




class ZtoLeptonFilter:public GenFilter {
public:
        ZtoLeptonFilter(const std::string& name, ISvcLocator* pSvcLocator);
        virtual ~ZtoLeptonFilter();
        virtual StatusCode filterInitialize();
        virtual StatusCode filterFinalize();
        virtual StatusCode filterEvent();

private:
	// Setable Properties:-

	// Local Member Data:-
	double m_Ptmin;
	double m_EtaRange;

	// Private Methods:=

};

#endif
