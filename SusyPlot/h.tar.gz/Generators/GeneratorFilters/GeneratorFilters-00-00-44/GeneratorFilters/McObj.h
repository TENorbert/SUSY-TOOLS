//////////////////////////////////////////////////////////////////////

/*
* The base class McObj provides the common handling of the four-vector
* and of the sorting. We never need to modify these, so we do not
* declare them virtual. We make the four-vector protected so we can
* access it from the derived classes.
*/

#ifndef __CINT__
#include <cmath>
#include <iostream>
#include "CLHEP/Vector/LorentzVector.h"
#endif

#ifndef MCOBJ_H
#define MCOBJ_H

////////// Base class McObj //////////

class McObj;

class McObj{
public:
// Constructors and destructor
  McObj();
  McObj(HepLorentzVector& p){m_p=p;};
  ~McObj() {}
// Get functions
  HepLorentzVector& P() {return m_p;}
  double P(int i) {return m_p[i];}
  int Nobj() {return m_Nobj;}
// Set functions
  void SetP(const HepLorentzVector& p) {m_p=p;}
  void SetP(const double&,const double&,const double&,const double&);
  void SetXYZM(const double&,const double&,const double&,
  const double&);
  void SetNobj(int& nn) {m_Nobj = nn;}

// Overloaded operators for sorting on Pt
  bool operator<(const McObj& rhs) const {return m_p.perp()<rhs.m_p.perp();}
  bool operator>(const McObj& rhs) const {return m_p.perp()>rhs.m_p.perp();}
protected:
  HepLorentzVector m_p;
  int m_Nobj;
};


#endif // MCOBJ_H
