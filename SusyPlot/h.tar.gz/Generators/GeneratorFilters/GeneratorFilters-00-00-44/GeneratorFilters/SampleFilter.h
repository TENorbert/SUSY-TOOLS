// --------------------------------------------------
// 
// File:  GeneratorFilters/SampleFilter.h

//
// AuthorList:
//        Ian Hinchliffe:  Initial Code December 2001

#ifndef GENERATORFILTERSSampleFilter_H
#define GENERATORFILTERSSampleFilter_H

#include "GaudiKernel/Algorithm.h"
//#include  "AthenaServices/AthenaOutputStream.h"

// Temporary
// #include "HepMC/ParticleDataTable.h"
#include "CLHEP/HepPDT/ParticleDataTable.hh"
#include "HepMC/GenEvent.h"

using HepMC::GenEvent;
class StoreGateSvc;

class SampleFilter:public Algorithm {
public:
        SampleFilter(const std::string& name, ISvcLocator* pSvcLocator);
        virtual ~SampleFilter();
        StatusCode initialize();
        StatusCode execute();
        StatusCode finalize();

protected:
	// Here are setable properties:-
	// The following is temporary.  The particle properties should come 
	// from the ParticlePropertiesService, but that means replacing the
	// Gaudi one with the Atlas one
//         HepMC::ParticleDataTable m_particleTable;
  HepPDT::ParticleDataTable m_particleTable;
	// Storegate
        StoreGateSvc* m_sgSvc;
};
#endif

