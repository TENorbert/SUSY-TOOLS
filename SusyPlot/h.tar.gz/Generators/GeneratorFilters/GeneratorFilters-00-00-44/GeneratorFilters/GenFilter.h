// --------------------------------------------------
// 
// File:  GeneratorFilters/GenFilter.h
// Description:
//    This class is the base class used to specify the behavior of all
//    event generator filtering modules and is meant to capture the common behavior
//    of these modules.  GenFilter inherits the Algorithm interface.  
//    

//    The following virtual methods should be overloaded from the child class:
//         StatusCode filterInitialize()
//         StatusCode filterEvent()
//         StatusCode filterFinalize()
//
// AuthorList:
//        Ian Hinchliffe:  Initial Code December 2001

#ifndef GENERATORFILTERSGENFILTER_H
#define GENERATORFILTERSGENFILTER_H

#include "GaudiKernel/Algorithm.h"
#include "StoreGate/StoreGateSvc.h"
#include "StoreGate/DataHandle.h"

#include "GeneratorObjects/McEventCollection.h"

// Temporary
#include "CLHEP/HepPDT/ParticleDataTable.hh"
// #include "HepMC/ParticleDataTable.h"
#include "HepMC/GenEvent.h"

using HepMC::GenEvent;
class StoreGateSvc;

class GenFilter:public Algorithm {
public:
        GenFilter(const std::string& name, ISvcLocator* pSvcLocator);
        virtual ~GenFilter();
        StatusCode initialize();
        StatusCode execute();
        StatusCode finalize();

        virtual StatusCode filterInitialize();
        virtual StatusCode filterEvent();
        virtual StatusCode filterFinalize();
	//        virtual StatusCode fillEvt(GenEvent* evt);

protected:
	// Here are setable properties:-
	// The following is temporary.  The particle properties should come 
	// from the ParticlePropertiesService, but that means replacing the
	// Gaudi one with the Atlas one
//         HepMC::ParticleDataTable m_particleTable;
  HepPDT::ParticleDataTable* m_particleTable;
	// Storegate
        StoreGateSvc* m_sgSvc;
        int m_nPass;
	int m_nFail;
	int m_nNeeded;
        const DataHandle<McEventCollection> m_cCollptr;
};
#endif






