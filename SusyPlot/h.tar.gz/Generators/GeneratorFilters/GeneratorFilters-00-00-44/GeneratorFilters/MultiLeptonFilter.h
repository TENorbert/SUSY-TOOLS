// --------------------------------------------------
// 
// File:  GeneratorFilters/MultiLeptonFilter.h
// Description:
// Filters and looks for leptons
//
// D. Costanzo private version. Added feature to select N leptons
//
//
// AuthorList:
//         I Hinchliffe:  December 2001


#ifndef GENERATORFILTERSMULTILEPTONFILTER_H
#define GENERATORFILTERSMULTILEPTONFILTER_H

#include "GenFilter.h"




class MultiLeptonFilter:public GenFilter {
public:
        MultiLeptonFilter(const std::string& name, ISvcLocator* pSvcLocator);
        virtual ~MultiLeptonFilter();
        virtual StatusCode filterInitialize();
        virtual StatusCode filterFinalize();
        virtual StatusCode filterEvent();

private:
	// Setable Properties:-

	// Local Member Data:-
	double m_Ptmin;
	double m_EtaRange;
        int m_NLeptons;   
	// Private Methods:=

};

#endif
