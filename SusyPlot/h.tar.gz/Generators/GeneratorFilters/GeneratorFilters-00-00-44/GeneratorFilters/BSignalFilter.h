// -------------------------------------------------------------------------------------------------------------------
// 
// File:         GeneratorFilters/BSignalFilter.h
//
// Description:  Finds all B-chains, applies cuts specified in jobOptionsFile
//               and writes all events that passed into an nTuple.
//
// Author: Malte Muller   <maltemlr@yahoo.co.uk>
// August 2002
//
// -------------------------------------------------------------------------------------------------------------------


#ifndef GENERATORFILTERSBSIGNALFILTER_H
#define GENERATORFILTERSBSIGNALFILTER_H


#include <vector>

#include "GeneratorFilters/GenFilter.h"

#include "GaudiKernel/Algorithm.h"
#include "GaudiKernel/NTuple.h"

#include "HepMC/GenEvent.h"
#include "HepMC/GenParticle.h"
#include "HepMC/GenVertex.h"

//#include "HepMC/ParticleData.h"
//#include "HepMC/ParticleDataTable.h"
//#include "HepMC/IO_PDG_ParticleDataTable.h"

// class StoreGateSvc;



// slave structs for tempStore

struct tS_particle
{
	long eventCnt;
	long chainCnt;
	long particleCnt;
	long id;
	long status;
	long parent;
	double px;
	double py;
	double pz;
	double pE;
	double pT;
	double mass;
	double phi;
	double rapidity;
	double pseudoRapidity;
};

struct tS_chain
{
	std::vector<tS_particle> vec;
	bool passedCuts;
};


// class that temporarily stores all found events,
// until the ones selected by cuts are put into nTuples

class tempStore
{
	private:
		std::vector<tS_chain> m_Chains;
		
	public:
		// constructor
		tempStore();
	
		// to reset the vector
		void reset();
		
		// to fill the vector
		void newChain();
		void addParticle( const HepMC::GenParticle* p, const int parent);
		void addCutResult( const bool newResult );
		
		// to read out the vector
		long chains() const;
		int particles() const;  // returns particles in current (last) chain
		int particles( const long chain ) const;
		
		double value( const long chain, const long particle,
			const std::string propertyStr ) const;
		bool passedCuts( const long chain ) const;
};




class BSignalFilter : public GenFilter
{

	public:

		BSignalFilter(const std::string& name, ISvcLocator* pSvcLocator);

        virtual StatusCode filterInitialize();
        virtual StatusCode filterFinalize();
        virtual StatusCode filterEvent();

		// utility method to convert a long to a string
		std::string longToStr( const long n ) const;


	private:

		// data members

		// for cuts on final particle pT and eta
		bool   m_cuts_f_e_on,    m_cuts_f_mu_on,   m_cuts_f_had_on,
		       m_cuts_f_gam_on,  m_cuts_f_K0_on,
                       localLVL1MuonCutOn, localLVL2MuonCutOn,
	               localLVL2ElectronCutOn;
		double m_cuts_f_e_pT,    m_cuts_f_mu_pT,   m_cuts_f_had_pT,
		       m_cuts_f_gam_pT,  m_cuts_f_K0_pT;
		double m_cuts_f_e_eta,   m_cuts_f_mu_eta,  m_cuts_f_had_eta,
		       m_cuts_f_gam_eta, m_cuts_f_K0_eta;
		double localLVL1MuonCutPT,  localLVL1MuonCutEta, localLVL2MuonCutPT,
                       localLVL2MuonCutEta, localLVL2ElectronCutPT,
	               localLVL2ElectronCutEta;
		double LVL1Counter;    //counting variables for events passing LVL1
		double LVL2Counter;    // LVL2
		double rejected;       // failed to pass trigger
		double rejectedAll;    // failed to pass filter (both trigger and stable)  

		// for temporarily storing all B-events
		tempStore m_tempStore;
		
		int m_EventCnt;
		//  for how many events user wants to store B in Ntuple - define in datacards
		double m_Ntuples;
		
		// for the output-nTuple
		
		NTuple::Tuple*			m_nTuple;
		
		// NB! Array<double> does not work with HBOOK nTuples,
		//     they are rejected with error message
		//     "address not double-word aligned".
		//     Using float instead for that reason.
		
		NTuple::Item<long>		m_nTuple_nParticles;
		
		NTuple::Array<long>		m_nTuple_eventCnt;
		NTuple::Array<long>		m_nTuple_chainCnt;
		NTuple::Array<long>		m_nTuple_particleCnt;
		NTuple::Array<long>		m_nTuple_id;
		NTuple::Array<long>		m_nTuple_status;
		NTuple::Array<long>		m_nTuple_parent;
		
		NTuple::Array<float>	m_nTuple_px;
		NTuple::Array<float>	m_nTuple_py;
		NTuple::Array<float>	m_nTuple_pz;
		NTuple::Array<float>	m_nTuple_pE;
		NTuple::Array<float>	m_nTuple_pT;
		NTuple::Array<float>	m_nTuple_mass;
		
		NTuple::Array<float>	m_nTuple_phi;
		NTuple::Array<float>	m_nTuple_rapidity;
		NTuple::Array<float>	m_nTuple_pseudoRapidity;


		// private member functions
		
		// core method, calls itself recursively to find the whole decay chain
		void findAllChildren(const HepMC::GenParticle* mother,
			std::string treeIDStr, bool fromFinalB);
		
		// LVL1 and LVL2 cuts
		bool LVL1Trigger(const HepMC::GenParticle* child) const;
		bool LVL2Trigger(const HepMC::GenParticle* child) const;

		// for testing whether final states pass cuts
		bool finalStateCutsPassed(const HepMC::GenParticle* child) const;
        	bool fSC_Test(const double myPT, const double testPT,
			const double myEta, const double testEta) const;
		
		bool Trigger_Test(const double myPT, const double testPT,
			const double myEta, const double testEta) const;
		
		// for (debug) printout
		void printChild(const HepMC::GenParticle* child,
			const std::string treeIDStr, const  bool fromFinalB) const;
		
		// decide whether given particle is a B-hadron
		bool isBMeson(const int pID) const;
		bool isBBaryon(const int pID) const;
		
		// (for final state cuts)
		bool isChargedHadron(const int pID) const;
		
		// to permanently write decay trees to nTuples
		void initNTuple();
		void writeToNTuple();
};


#endif
