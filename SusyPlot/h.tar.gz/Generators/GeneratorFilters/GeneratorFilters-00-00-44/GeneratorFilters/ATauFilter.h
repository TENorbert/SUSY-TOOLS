// --------------------------------------------------
// 
// File:  GeneratorFilters/ATauFilter.h
// Description:
// Filters and looks for leptons
//
// AuthorList:
//         Michael Heldmann Jan 2003 from LeptonFilter by Ian Hinchliffe
// Modified by Ian H for release 7.7.0 -- Energy units and changes in HepMC

#ifndef GENERATORFILTERSATAUFILTER_H
#define GENERATORFILTERSATAUFILTER_H

#include "GenFilter.h"


class ATauFilter:public GenFilter {
public:
        ATauFilter(const std::string& name, ISvcLocator* pSvcLocator);
        virtual ~ATauFilter();
        virtual StatusCode filterInitialize();
        virtual StatusCode filterFinalize();
        virtual StatusCode filterEvent();

private:
	// Setable Properties:-

	// Local Member Data:-
	double m_Ptmin;
	double m_EtaRange;

	double m_llPtmine;
	double m_llPtminmu;

	double m_lhPtmine;
	double m_lhPtminmu;
	double m_lhPtminh;

	double m_hhPtmin;

	double m_eventsaccepted;
	double m_eventsrefused;

	double m_eventsll;
	double m_eventslh;
	double m_eventshh;
	
	double m_eventsllacc;
	double m_eventslhacc;
	double m_eventshhacc;
	
	// Private Methods:=

};

#endif




