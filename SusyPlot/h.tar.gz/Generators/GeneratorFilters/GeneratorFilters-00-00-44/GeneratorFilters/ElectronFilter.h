// --------------------------------------------------
// 
// File:  GeneratorFilters/ElectronFilter.h
// Description:
// Filters and looks for electrons
//
// AuthorList:
//         I Hinchliffe:  December 2001


#ifndef GENERATORFILTERSELECTRONFILTER_H
#define GENERATORFILTERSELECTRONFILTER_H

#include "GenFilter.h"




class ElectronFilter:public GenFilter {
public:
        ElectronFilter(const std::string& name, ISvcLocator* pSvcLocator);
        virtual ~ElectronFilter();
        virtual StatusCode filterInitialize();
        virtual StatusCode filterFinalize();
        virtual StatusCode filterEvent();

private:
	// Setable Properties:-

	double m_Ptmin;
	double m_EtaRange;

	// Private Methods:=

};

#endif
