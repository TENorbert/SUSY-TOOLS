// -------------------------------------------------------------
// File: GeneratorFilters/HLTCheckFilter.h
// Description:
//  Applies the generator level filter for electron and jet candidates for DC1
// Must be called after something (e.g. HLTDC1Filter) has created a FilterFlags object and placed it in Storegate
// several instances of this algorithm can be created to return the decisions on the set of Filters in the FilterFlags class
// AuthorList:
//         
// Ian Hinchliffe  May 2002
//
#ifndef GENERATORFILTERSCHECKFILTER_H
#define GENERATORFILTERSCHECKFILTER_H

#include "GaudiKernel/Algorithm.h"
#include "StoreGate/StoreGateSvc.h"
#include "GeneratorFilters/FilterFlags.h" 
#include "StoreGate/DataHandle.h"


class StoreGateSvc;
class HLTCheckFilter:public Algorithm {
public:
        HLTCheckFilter(const std::string& name, ISvcLocator* pSvcLocator);
        virtual ~ HLTCheckFilter();
        StatusCode initialize();
        StatusCode execute();
        StatusCode finalize();


private:
        StoreGateSvc* m_sgSvc;
	std::string m_FilterKey;  //key to filter data in Storegate
	std::string m_FilterName;  //name of filter being tested
	const DataHandle<FilterFlags> m_collptr;
};


#endif
