// --------------------------------------------------
// 
// File:  GeneratorFilters/ParticleFilter.h
// Description:
// Filters and looks for Particles
// The filter will pass only if it finds a particle with 
// the specified properties
// AuthorList:
//         I Hinchliffe:  May 2004


#ifndef GENERATORFILTERSPARTICLEFILTER_H
#define GENERATORFILTERSPARTICLEFILTER_H

#include "GenFilter.h"




class ParticleFilter:public GenFilter {
public:
        ParticleFilter(const std::string& name, ISvcLocator* pSvcLocator);
        virtual ~ParticleFilter();
        virtual StatusCode filterInitialize();
        virtual StatusCode filterFinalize();
        virtual StatusCode filterEvent();

private:
	// Setable Properties:-

	double m_Ptmin;
	double m_EtaRange;
	double m_EnergyRange;
	int    m_PDGID;

	// Private Methods:=

};

#endif
