###############################################################
#
# Job options file
#
#==============================================================
#
# This job options file runs HepMC Generator simulations in the
# Athena framework and saves Generator TES objects in ROOT
# using AthenaRoot conversion service
#
theApp.setup( MONTECARLO )

include( "PartPropSvc/PartPropSvc.py" )

EventSelector = Service( "EventSelector" )
EventSelector.RunNumber   = 1
EventSelector.FirstEvent  = 1
# load relevant libraries
theApp.Dlls += [ "GaudiAlg" ]
theApp.Dlls += [ "Pythia_i"]
theApp.Dlls += [ "GeneratorFilters" ]
theApp.Dlls += [ "GaudiAud" ]
theApp.Dlls += [ "HbookCnv" ]
theAuditorSvc = AuditorSvc()
theAuditorSvc.Auditors  = [ "ChronoAuditor" ]
# No histogramming at the Generator stage
#--------------------------------------------------------------
# Event related parameters
#--------------------------------------------------------------
# Number of events to be processed (default is 0)
theApp.EvtMax = 10
#--------------------------------------------------------------
# Private Application Configuration options
#--------------------------------------------------------------
# OUTPUT PRINTOUT LEVEL
# Set output level threshold (2=DEBUG, 3=INFO, 4=WARNING, 5=ERROR, 6=FATAL )
# you can override this for individual modules if necessary
MessageSvc = Service( "MessageSvc" )
MessageSvc.OutputLevel               = 2
# Execution of algorithms given in sequencer
#
theApp.TopAlg = ["Sequencer/TopSequence"]
#--------------------------------------------------------------
# Algorithms Private Options
#--------------------------------------------------------------
#
#GENERATORS SETUP (select by uncommenting/commenting)
#----------------
TopSequence = Algorithm( "TopSequence" )
TopSequence.Members  = ["Sequencer/Generator"]
#//TopSequence.Members  += {"Sequencer/Atlfast"};
TopSequence.Members  += ["Sequencer/Filter"]
Generator = Algorithm( "Generator" )
Generator.Members    = ["Pythia"]
Filter = Algorithm( "Filter" )
Filter.Members = ["JetFilter"]
#//#include "AtlfastStandardOptions.txt"
# DC1 di-jet for test puropses only!
Pythia = Algorithm( "Pythia" )
Pythia.PythiaCommand = [
			      "pysubs msel 0",
			      "pysubs ckin 3 17.",
			      "pysubs msub 11 1",
			      "pysubs msub 12 1",
			      "pysubs msub 13 1",
			      "pysubs msub 68 1",
			      "pysubs msub 28 1",
			      "pysubs msub 53 1",
			      "pypars mstp 82 4",
			      "pydat1 mstj 11 3",
			      "pydat1 mstj 22 2",
			      "pydat1 parj 54 -0.07",
			      "pydat1 parj 55 -0.006",
			      "pypars parp 82 1.8",
			      "pypars parp 84 0.5",
			      "pyinit pylisti 12",
			      "pyinit pylistf 1",
			      "pystat 1 3 4 5",
			      "pyinit dumpr 1 5",
			      "pypars mstp 128 0"]
# if you want to print each MC event for debugging purposes, uncomment:
# Generator.Members += {"DumpMC"};
#
# Filter to get one jet
#
JetFilter = Algorithm( "JetFilter" )
JetFilter.JetNumber = 1
JetFilter.EtaRange = 2.7
JetFilter.JetThreshold = 17000.;  # Note this is 17 GeV
JetFilter.GridSizeEta=2; # sets the number of (approx 0.06 size) eta
JetFilter.GridSizePhi=2; # sets the number of (approx 0.06 size) phi cells
#the above pair are not used if cone is selected
JetFilter.JetType=FALSE; #true is a cone, false is a grid
JetFilter.ConeSize=0.4; #cone size (not used if grid is selected)
Generator.Members += ["EventCounter"]
#
# Atlfast stuff
#
# HBOOK OUTPUT:
# This is the name of the file where your histograms will be created.
#
theApp.HistogramPersistency = "HBOOK"
HistogramPersistencySvc = Service( "HistogramPersistencySvc" )
HistogramPersistencySvc.OutputFile  = "atlfast.hbook"
#NtupleSvc.Output                  = {"FILE1#ntuple.hbook" };
#NtupleSvc.Type                    = 6;
NtupleSvc = Service( "NtupleSvc" )
NtupleSvc.Output = ["FILE1 DATAFILE='atlfast.ntup' TYP='HBOOK' OPT='NEW'"]
#pool persistancy
# ---------------------------------------------------------------
include( 'AthenaPoolCnvSvc/WriteAthenaPool_jobOptions.py' )
include( 'GeneratorObjectsAthenaPool/GeneratorObjectsAthenaPool_joboptions.py' )

# 2101   == EventInfo
# 133273 == MC Truth (HepMC)
Stream1.ItemList += [ '2101#*', '133273#*' ]

include( 'AthenaSealSvc/AthenaSealSvc_joboptions.py' )
AthenaSealSvc.CheckDictionary = TRUE

Stream1.AcceptAlgs=["Filter"]
Stream1.OutputFile = 'McEvent.root'
#==============================================================
#
# End of job options file
#
###############################################################
