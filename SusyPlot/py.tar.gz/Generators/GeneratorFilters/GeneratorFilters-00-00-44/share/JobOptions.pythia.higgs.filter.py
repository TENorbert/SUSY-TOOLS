###############################################################
#
# Job options file
#
#==============================================================
#
# This job options file runs HepMC Generator simulations in the
# Athena framework and saves Generator TES objects in ROOT
# using AthenaRoot conversion service
#
theApp.setup( MONTECARLO )

include( "PartPropSvc/PartPropSvc.py" )

EventSelector = Service( "EventSelector" )
EventSelector.RunNumber   = 1
EventSelector.FirstEvent  = 1
# load relevant libraries
theApp.Dlls += [ "GaudiAlg" ]
# ApplicationMgr.DLLs += { "Isajet_i"};
theApp.Dlls += [ "Pythia_i"]
theApp.Dlls += [ "GeneratorFilters" ]
theApp.Dlls += [ "GaudiAud" ]
#//ApplicationMgr.DLLs += { "AtlfastAlgs"};
theApp.Dlls += [ "HbookCnv" ]
theAuditorSvc = AuditorSvc()
theAuditorSvc.Auditors  = [ "ChronoAuditor" ]
# No histogramming at the Generator stage
#--------------------------------------------------------------
# Event related parameters
#--------------------------------------------------------------
# Number of events to be processed (default is 0)
theApp.EvtMax = 50
#--------------------------------------------------------------
# Private Application Configuration options
#--------------------------------------------------------------
# OUTPUT PRINTOUT LEVEL
# Set output level threshold (2=DEBUG, 3=INFO, 4=WARNING, 5=ERROR, 6=FATAL )
# you can override this for individual modules if necessary
MessageSvc = Service( "MessageSvc" )
MessageSvc.OutputLevel               = 2
# Execution of algorithms given in sequencer
#
theApp.TopAlg = ["Sequencer/TopSequence"]
#--------------------------------------------------------------
# Algorithms Private Options
#--------------------------------------------------------------
#
#GENERATORS SETUP (select by uncommenting/commenting)
#----------------
TopSequence = Algorithm( "TopSequence" )
TopSequence.Members  = ["Sequencer/Generator"]
#//TopSequence.Members  += {"Sequencer/Atlfast"};
TopSequence.Members  += ["Sequencer/Filter"]
# Generator.Members = {"Isajet"};
Generator = Algorithm( "Generator" )
Generator.Members    = ["Pythia"]
Filter = Algorithm( "Filter" )
Filter.Members = ["MultiLeptonFilter"]
#//#include "AtlfastStandardOptions.txt"
# DC1 di-jet for test puropses only!
Pythia = Algorithm( "Pythia" )
Pythia.PythiaCommand = [

# Higgs mass set:
                                "pydat2 pmas 25 1 150.",
# Select Higgs production
				"pysubs msel 16",
# Higgs Decays
                                "pydat3 mdme 210 1 0",
                                "pydat3 mdme 211 1 0",
                                "pydat3 mdme 212 1 0",
                                "pydat3 mdme 213 1 0",
                                "pydat3 mdme 214 1 0",
                                "pydat3 mdme 215 1 0",
                                "pydat3 mdme 218 1 0",
                                "pydat3 mdme 219 1 0",
                                "pydat3 mdme 220 1 0",
                                "pydat3 mdme 222 1 0",
                                "pydat3 mdme 223 1 0",
                                "pydat3 mdme 224 1 0",
                                "pydat3 mdme 225 1 1",
                                "pydat3 mdme 226 1 0",

# Z Decays
                                "pydat3 mdme 174 1 0",
                                "pydat3 mdme 175 1 0",
                                "pydat3 mdme 176 1 0",
                                "pydat3 mdme 177 1 0",
                                "pydat3 mdme 178 1 0",
                                "pydat3 mdme 179 1 0",
                                "pydat3 mdme 180 1 0",
                                "pydat3 mdme 181 1 0",
                                "pydat3 mdme 182 1 1",
                                "pydat3 mdme 183 1 0",
                                "pydat3 mdme 184 1 1",
                                "pydat3 mdme 185 1 0",
                                "pydat3 mdme 186 1 0",
                                "pydat3 mdme 187 1 0",
                                "pydat3 mdme 188 1 0",
                                "pydat3 mdme 189 1 0",
# Other stuff
                                "pyinit pylisti 12",
                                "pyinit pylistf 1",
                                "pypars parp 82 2.2",
                                "pyinit dumpr 1 1"]
# if you want to print each MC event for debugging purposes, uncomment:
# Generator.Members += {"DumpMC"};
#
# Filter to get 4 leptons
#
MultiLeptonFilter = Algorithm( "MultiLeptonFilter" )
MultiLeptonFilter.NLeptons = 4
MultiLeptonFilter.Etacut = 2.7
MultiLeptonFilter.Ptcut = 4000.;  # Note this is 4 GeV
Generator.Members += ["EventCounter"]
#
# Atlfast stuff
#
# HBOOK OUTPUT:
# This is the name of the file where your histograms will be created.
#
theApp.HistogramPersistency = "HBOOK"
HistogramPersistencySvc = Service( "HistogramPersistencySvc" )
HistogramPersistencySvc.OutputFile  = "atlfast.hbook"
#NtupleSvc.Output                  = {"FILE1#ntuple.hbook" };
#NtupleSvc.Type                    = 6;
NtupleSvc = Service( "NtupleSvc" )
NtupleSvc.Output = ["FILE1 DATAFILE='atlfast.ntup' TYP='HBOOK' OPT='NEW'"]
#--------------------------------------------------------------
# AthenaRoot Persistency
#--------------------------------------------------------------
include( 'AthenaPoolCnvSvc/WriteAthenaPool_jobOptions.py' )
include( 'GeneratorObjectsAthenaPool/GeneratorObjectsAthenaPool_joboptions.py' )

# 2101   == EventInfo
# 133273 == MC Truth (HepMC)
Stream1.ItemList += [ '2101#*', '133273#*' ]

include( 'AthenaSealSvc/AthenaSealSvc_joboptions.py' )
AthenaSealSvc.CheckDictionary = TRUE

Stream1.AcceptAlgs=["Filter"]
Stream1.OutputFile = 'Higgsto4l_1.root'
#==============================================================
#
# End of job options file
#
###############################################################
