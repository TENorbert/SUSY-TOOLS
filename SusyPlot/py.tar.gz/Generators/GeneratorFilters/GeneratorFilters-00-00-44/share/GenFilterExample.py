###############################################################
#
# Job options file
#
#==============================================================
#--------------------------------------------------------------
# General Application Configuration options
#--------------------------------------------------------------
theApp.setup( MONTECARLO )

include( "PartPropSvc/PartPropSvc.py" )

#--------------------------------------------------------------
# Private Application Configuration options
#--------------------------------------------------------------
theApp.Dlls  += [ "Herwig_i" ]
theApp.Dlls  += [ "TruthExamples" ]
theApp.Dlls += [ "HbookCnv" ]
theApp.Dlls += [ "GeneratorFilters" ]
theApp.Dlls += ["GaudiAlg"]
theApp.HistogramPersistency = "HBOOK"
theApp.TopAlg = ["Sequencer/Generator"]
Generator = Algorithm( "Generator" )
Generator.Members = ["Herwig", "ElectronFilter", "HistSample"]
HistogramPersistencySvc = Service( "HistogramPersistencySvc" )
HistogramPersistencySvc.OutputFile  = "herwig.hbook"
NTupleSvc = Service( "NTupleSvc" )
NTupleSvc.Output     = [ "FILE1 DATAFILE='herwigtuple1.hbook' OPT='NEW'" ]
# Set output level threshold (2=DEBUG, 3=INFO, 4=WARNING, 5=ERROR, 6=FATAL )
MessageSvc = Service( "MessageSvc" )
MessageSvc.OutputLevel               = 6
#--------------------------------------------------------------
# Event related parameters
#--------------------------------------------------------------
# Number of events to be processed (default is 10)
theApp.EvtMax = 500
#--------------------------------------------------------------
# Algorithms Private Options
#--------------------------------------------------------------
Herwig = Algorithm( "Herwig" )
Herwig.HerwigCommand = ["iproc 2150","modpdf 46", "autpdf CTEQ", "ptmin 20.", "ptmax 40.", "emmin 80.", "emmax 100."]; 