###############################################################
#
# Job options file
#
#==============================================================
#--------------------------------------------------------------
# General Application Configuration options
#--------------------------------------------------------------
theApp.setup( MONTECARLO )

include( "PartPropSvc/PartPropSvc.py" )

#--------------------------------------------------------------
# Private Application Configuration options
#--------------------------------------------------------------
theApp.Dlls  += [ "TruthExamples", "Pythia_i", "GeneratorFilters"]
theApp.TopAlg = ["Pythia", "HLTDC1Filter", "DumpMC"]
# Set output level threshold (2=DEBUG, 3=INFO, 4=WARNING, 5=ERROR, 6=FATAL )
MessageSvc = Service( "MessageSvc" )
MessageSvc.OutputLevel               = 2
#--------------------------------------------------------------
# Event related parameters
#--------------------------------------------------------------
# Number of events to be processed (default is 10)
theApp.EvtMax = 5
Pythia = Algorithm( "Pythia" )
Pythia.PythiaCommand = ["pydatr mrpy 1 98457671",
			"pysubs msel 0",
			"pysubs ckin 3 17.",
			"pysubs msub 11 1",
			"pysubs msub 12 1",
			"pysubs msub 13 1",
			"pysubs msub 28 1",
			"pysubs msub 53 1",
			"pysubs msub 68 1",
			"pysubs msub 81 1",
			"pysubs msub 82 1",
			"pysubs msub 14 1",
			"pysubs msub 29 1",
			"pysubs msub 1 1",
			"pysubs msub 2 1",
			"pypars mstp 82 4",
			"pypars mstp 82 4",
			"pypars mstp 7 6",
			"pydat1 mstj 22 2",
			"pydat1 parj 54 -0.07",
			"pydat1 parj 55 -0.006",
			"pypars parp 82 2.2" ]
#--------------------------------------------------------------
# Algorithms Private Options
#--------------------------------------------------------------
#---------------------------------------------------------------
# Ntuple service output
#---------------------------------------------------------------
#==============================================================
#
# End of job options file
#
###############################################################
