# This file contains a Python equivalent of the analysis example
# available in C++ in the SusyUserExampleHistTool class in the
# SUSYPhysUser package.
#
# szymon.gadomski@cern.ch
# 03.05.2005

#
# class SusyUserExample( PyAlgorithm ):
# this we can not do yet since the Gaudi Analysis
# class does not work  in Athena (bug 7712).
#
# Instead of the Gaudi PyAlgorithm class
# we use parent class from Scott Snyder 
# (see http://www.usatlas.bnl.gov/~snyder/recipes/pyalgorithm.html)
#
class SusyUserPyAlg(AthenaPyAlgorithm):
   """Python implementation of the SUSY user example."""

   #   def __init__( self, name ):
   #      PyAlgorithm.__init__( self, name )
   #
   #      self.name  = name
   
   print "SusyUserPyAlg is constructed"
      
   def initialize(self):

       print "SusyUserPyAlg is initialized"
       self.EventCounter=0
       print "booking histos in folder /SusyUserPyExample"

       self.h_electronn =  book('/stat/SusyUserPyExample/n_electron','n_electron',20,-0.5,19.5)
       self.h_electronetaall =  book('/stat/SusyUserPyExample/electron_eta','electron_eta',50,-5.,5.)
       self.h_electronpairos= book('/stat/SusyUserPyExample/e_pair_os_invariant_mass','e_pair_os_invariant_mass',25,0.,200.) 
       self.h_electronpairss = book('/stat/SusyUserPyExample/e_pair_ss_invariant_mass','e_pair_ss_invariant_mass',25,0.,200.)
       self.h_electronpt1 =  book('/stat/SusyUserPyExample/electron_1_pt','electron_1_pt',50,0.,400.)
       self.h_electronpt2 =  book('/stat/SusyUserPyExample/electron_2_pt','electron_2_pt',50,0.,400.)

       self.h_muonn =  book('/stat/SusyUserPyExample/n_muon','n_muon',20,-0.5,19.5)
       self.h_muonetaall =  book('/stat/SusyUserPyExample/muon_eta','muon_eta',50,-5.,5.)
       self.h_muonpairos= book('/stat/SusyUserPyExample/mu_pair_os_invariant_mass','mu_pair_os_invariant_mass',25,0.,200.) 
       self.h_muonpairss = book('/stat/SusyUserPyExample/mu_pair_ss_invariant_mass','mu_pair_ss_invariant_mass',25,0.,200.)
       self.h_muonpt1 =  book('/stat/SusyUserPyExample/muon_1_pt','muon_1_pt',50,0.,400.)
       self.h_muonpt2 =  book('/stat/SusyUserPyExample/muon_2_pt','muon_2_pt',50,0.,400.)

       self.h_taun =  book('/stat/SusyUserPyExample/n_tau','n_tau',20,-0.5,19.5)
       self.h_tauetaall =  book('/stat/SusyUserPyExample/tau_eta','tau_eta',50,-5.,5.)
       self.h_taupairos= book('/stat/SusyUserPyExample/tau_pair_os_invariant_mass','tau_pair_os_invariant_mass',25,0.,200.) 
       self.h_taupairss = book('/stat/SusyUserPyExample/tau_pair_ss_invariant_mass','tau_pair_ss_invariant_mass',25,0.,200.)
       self.h_taupt1 =  book('/stat/SusyUserPyExample/tau_1_pt','tau_1_pt',50,0.,400.)
       self.h_taupt2 =  book('/stat/SusyUserPyExample/tau_2_pt','tau_2_pt',50,0.,400.)

       self.h_emupairos =  book('/stat/SusyUserPyExample/e_mu_os_invariant_mass','e_mu_os_invariant_mass',50,0.,400.)
       self.h_emupairss =  book('/stat/SusyUserPyExample/e_mu_ss_invariant_mass','e_mu_ss_invariant_mass',50,0.,400.)

       self.h_etmiss = book('/stat/SusyUserPyExample/missing_energy','missing_energy',25,0.,1000.)
       self.h_meff = book('/stat/SusyUserPyExample/effective_mass','effective_mass',25,0.,2000.)

       self.h_leptonspairs = book('/stat/SusyUserPyExample/dilep_pair_ss_invariant_mass','dilep_pair_ss_invariant_mass',25,0.,200.)

       print "finished booking histos"

       # this is needed to get a SUSY class from StoreGate
       pylcgdict.loadDictionary("SUSYPhysUtilsDict")

       print "loaded dictionary SUSYPhysUtilsDict"
       print "SusyUserPyAlg finished initializing"
     
       return True

   def execute(self):

       self.EventCounter+=1
       if self.EventCounter < 100: print "SusyUserPyAlg executing"

       try:
          myElectrons = PyParticleTools.getIParticles("SusyElectronRed")
          myJets = PyParticleTools.getIParticles("SusyJetRed")
          myMuons = PyParticleTools.getIParticles("SusyMuonRed")
          myTaus = PyParticleTools.getIParticles("SusyTauRed")

          
          if self.EventCounter < 100:
             print "Found",len(myElectrons),"electrons"
             print "Found",len(myJets),"jets"
             print "Found",len(myTaus),"taus"
             print "Found",len(myMuons),"muons"
          else:
             tst = [len(myElectrons), len(myJets), len(myTaus), len(myMuons)]

       except TypeError:
          # we skip this event
          return True
       
       # get _the_ missing ET of the SUSY group
       # SusyGlobalObject class in StoreGate
       myEtmiss=g.PyGate(g.SusyGlobalObject).retrieve(g.StoreGate.pointer(),"SusyGlobal")
       if self.EventCounter < 100: print "Missing Et from SusyGlobalObject",myEtmiss.etmiss()/GeV

       # event properties
       self.h_electronn.Fill(len(myElectrons),1.0)
       self.h_muonn.Fill(len(myMuons),1.0)
       self.h_taun.Fill(len(myTaus),1.0)

       self.h_etmiss.Fill(myEtmiss.etmiss()/GeV,1.0)

       # electrons
       for thisElectron in myElectrons: 
           self.h_electronetaall.Fill(thisElectron.eta(),1.)

       if len(myElectrons) > 1:
           indexList = range(len(myElectrons))   
           for i1 in indexList:
               e1 = myElectrons[i1]
               for i2 in indexList[i1+1:]:
                   e2 = myElectrons[i2]
                   print "electron pair with pT", e1.pt(),e2.pt()
                   if e1.pt() >= 10000 and e2.pt() >= 10000:
                       self.h_electronpt1.Fill(e1.pt()/GeV,1.)
                       self.h_electronpt2.Fill(e2.pt()/GeV,1.)
                       Mpair = (e1.hlv()+e2.hlv()).m()
                       if e1.charge()*e2.charge() > 0.5: 
                           self.h_electronpairss.Fill(Mpair/GeV,1.)
                       else:
                           self.h_electronpairos.Fill(Mpair/GeV,1.)

       # muons
       for thisMuon in myMuons: 
           self.h_muonetaall.Fill(thisMuon.eta(),1.)

       if len(myMuons) > 1:
           indexList = range(len(myMuons))
           for i1 in indexList:
               mu1 = myMuons[i1]
               for i2 in indexList[i1+1:]:
                   mu2 = myMuons[i2]
                   print "muon pair with pT", mu1.pt(),mu2.pt()
                   if mu1.pt() >= 10000 and mu2.pt() >= 10000:
                       self.h_muonpt1.Fill(mu1.pt()/GeV,1.)
                       self.h_muonpt2.Fill(mu2.pt()/GeV,1.)
                       Mpair = (mu1.hlv()+mu2.hlv()).m()
                       if mu1.charge()*mu2.charge() > 0.5: 
                           self.h_muonpairss.Fill(Mpair/GeV,1.)
                       else:
                           self.h_muonpairos.Fill(Mpair/GeV,1.)

       # e-mu
       if len(myMuons)>0 and len(myElectrons)>0:
           for mu in myMuons:
               for e in myElectrons:
                   if mu.pt()>10000 and e.pt()>10000:
                       Mpair = (mu.hlv()+e.hlv()).m()
                       if mu.charge()*e.charge() > 0.5:
                           self.h_emupairss.Fill(Mpair/GeV,1.)
                       else:
                           self.h_emupairos.Fill(Mpair/GeV,1.)

       # tau
       # eneral cut: at least one jet with pt > 100 GeV
       # and at least one jet with pt > 40 GeV; Etmiss > 300 GeV

       for tau in myTaus: self.h_tauetaall.Fill(tau.eta(),1.)

       if len(myTaus) >= 2:
           if myTaus[0].pt() >= 40000 and myTaus[1].pt() >= 25000:
               self.h_taupt1.Fill(myTaus[0].pt()/GeV,1.)
               self.h_taupt2.Fill(myTaus[1].pt()/GeV,1.)
               Mpair = (myTaus[0].hlv()+myTaus[1].hlv()).m()
               if myTaus[0].charge()*myTaus[1].charge() > 0.5:
                   self.h_taupairss.Fill(Mpair/GeV,1.)
               else:
                   self.h_taupairos.Fill(Mpair/GeV,1.)

       # effective mass
       if len(myJets)>=4:
           if (myJets[1].pt()>100000 and myJets[3].pt()>50000
               and  myEtmiss.etmiss()>100000): 
               Meff = (myJets[0].pt()+myJets[1].pt()+myJets[2].pt()
                       +myJets[3].pt()+myEtmiss.etmiss())
               self.h_meff.Fill(Meff/GeV,1.)
               # print "Effective mass",Meff

       # print "SusyUserPyAlg execute finished"
       return True

   def finalize(self):

       # print "SusyUserPyAlg finishing"

       self.h_leptonspairs.Add(self.h_electronpairos)
       self.h_leptonspairs.Add(self.h_muonpairos)

       print "SusyUserPyAlg finished"

       return True

#
# This is a fallback when the base algorithm class does not work
# in Athena. Otherwise this function is not needed, but it makes
# no harm to define it.
#
def runSusyUserPyAlg(Nevent):
    "Control event loop and execute the SUSY analysis example"

    print "runSusyUserPyAlg starts"
    sc = theApp.initialize()
    sueInst = SusyUserPyAlg('alg')
    sueInst.initialize()

    for iE in range(Nevent):
        if iE<100 or not (iE%100):
            print "runSusyUserPyAlg goes to event",iE
        sc = theApp.nextEvent()
        try:
            sueInst.execute()
        except TypeError:
            # type error indicates no data in StorgeGate
            # a SUSY algo upstream gave up on this event
            # nothing to worry about
            # print "Type error at event ",iE,", but we continue anyway!"
            continue
        
    sueInst.finalize()
    print "runSusyAnalysis is done"
 
