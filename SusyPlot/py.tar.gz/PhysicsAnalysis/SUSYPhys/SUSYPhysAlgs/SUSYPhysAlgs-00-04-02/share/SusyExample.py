# setup SusyPlot:
include ("SUSYPhysAlgs/SusySetup.py")

# define cuts to be applied to particles (eta, pt, ...)
include ("SUSYPhysAlgs/SusyCuts.py")

# This are the default creators
include ("SUSYPhysAlgs/SusyDataCreator.py")
include ("SUSYPhysAlgs/SusyMcCreator.py")

# Add here additional creators if you want:

# This is the default SusyPlot:
theApp.TopAlg += ["SusyPlot"]
SusyPlot=Algorithm("SusyPlot")
SusyPlot.PlotInputKeys  =[ "jet:SusyJet", "muon:SusyMuon", "electron:SusyElectron", "photon:SusyPhoton", "tau:SusyTau","global:SusyGlobal"]
SusyPlot.PlotInputKeys +=["jetmc:SusyJetTruth","electronmc:SusyElectronMc", "muonmc:SusyMuonMc", "photonmc:SusyPhotonMc", "taumc:SusyTauMc", "globalmc:SusyGlobalMc"]

# Set the selection tool here
SusyPlot.Selector = "SusySimpleSelTool"
### Change selector cuts
# SusyPlot.SusySimpleSelTool.EtMissCut=0*GeV;
# SusyPlot.SusySimpleSelTool.Jet4EtCut=50*GeV;
# SusyPlot.SusySimpleSelTool.Jet2EtCut=100*GeV;



# The list of histograms tools that you would like to have
SusyPlot.HistogramList=["SusyMuonHistTool", "SusyElectronHistTool", "SusyJetHistTool", "SusyTauHistTool", "SusyGlobalHistTool"]

# User adds more histograms here:
SusyPlot.HistogramList+=["SusyUserExampleHistTool"]

#
#
# Add additional instances of SusyPlot

###############################################################
