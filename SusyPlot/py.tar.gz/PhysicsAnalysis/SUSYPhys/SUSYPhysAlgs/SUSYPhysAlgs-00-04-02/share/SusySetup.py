#---
# General setup

# the Dlls
theApp.Dlls += ["SUSYPhysAlgs"]
theApp.Dlls += ["SUSYPhysUtils"]
theApp.Dlls += ["SUSYPhysUser"]
theApp.Dlls += ["AnalysisTools"]
theApp.Dlls += ["TruthParticleAlgs"]

# Load Pool support
include( "AthenaPoolCnvSvc/ReadAthenaPool_jobOptions.py" )

# POOL converters
include( "EventAthenaPool/EventAthenaPool_joboptions.py" )
include( "GeneratorObjectsAthenaPool/GeneratorObjectsAthenaPool_joboptions.py")
include( "RecAthenaPool/RecAthenaPool_joboptions.py" )
include( "LArAthenaPool/LArAthenaPool_joboptions.py" )
include( "TileEventAthenaPool/TileEventAthenaPool_joboptions.py" )
include( "InDetEventAthenaPool/InDetEventAthenaPool_joboptions.py" )
include( "TrkEventAthenaPool/TrkEventAthenaPool_joboptions.py" )
include( "ParticleEventAthenaPool/ParticleEventAthenaPool_joboptions.py" )
include( "AnalysisTriggerEventAthenaPool/AnalysisTriggerEventAthenaPool_joboptions.py" )

# The AOD input files
EventSelector = Service( "EventSelector" )
if (not "InputCollections" in dir() ):
    InputCollections = ["/usatlas/workarea/costanzo/904/data/rome.004100.reco.T1_McAtNLO_top._00001.AOD.pool.root"]
EventSelector.InputCollections = InputCollections

# Number of Events to process, default is all:
if (not "EvtMax" in dir() ):
    EvtMax=-1
theApp.EvtMax = EvtMax

# Set output level threshold (2=DEBUG, 3=INFO, 4=WARNING, 5=ERROR, 6=FATAL )
if (not "OutputLevel" in dir() ):
    OutputLevel=3
MessageSvc = Service( "MessageSvc" )
MessageSvc.OutputLevel = OutputLevel

# Root Ntuple output
theApp.Dlls += [ "RootHistCnv" ]
theApp.HistogramPersistency = "ROOT"
HistogramPersistencySvc = Service( "HistogramPersistencySvc" )
HistogramPersistencySvc.OutputFile = "hist.root";


#
# Extra features
#

# write out a summary of the time spent
theApp.Dlls += [ "GaudiAud" ]
theAuditorSvc = AuditorSvc()
theAuditorSvc.Auditors  += [ "ChronoAuditor", "MemStatAuditor"]

###############################################################
#--------------------------------------------------------------
#---   Secondary Write portion  ----- Don't change it !!!
#--------------------------------------------------------------
if (not "doWriteOutput" in dir() ):
    doWriteOutput=False

if (not "PoolAODOutput" in dir() ):
    PoolAODOutput="SusyMergedAOD.pool.root"

if doWriteOutput:
    theApp.OutStream     =["Stream1"]
    theApp.OutStreamType ="AthenaOutputStream"
    Stream1 = Algorithm( "Stream1" )
    Stream1.Output = PoolAODOutput
    Stream1.EvtConversionSvc     ="AthenaPoolCnvSvc"
    PoolSvc = Service( "PoolSvc" )
    Stream1.ForceRead=TRUE;  #force read of output data objs

    # list of output objects
    include( "ParticleEventAthenaPool/AOD_OutputList_jobOptions.py")
    Stream1.ItemList = AOD_ItemList
    Stream1.AcceptAlgs = [ "SusyPlot" ]


