# import the data types 
import EventKernel.ParticleDataType

# define the units
include( "AthenaCommon/SystemOfUnits.py" )

include( "AthenaPoolCnvSvc/ReadAthenaPool_jobOptions.py" )
include( "EventAthenaPool/EventAthenaPool_joboptions.py" )
include( "LArAthenaPool/LArAthenaPool_joboptions.py" )
include( "TileEventAthenaPool/TileEventAthenaPool_joboptions.py" )
include( "InDetEventAthenaPool/InDetEventAthenaPool_joboptions.py" )
include ("RecAthenaPool/RecAthenaPool_joboptions.py" )
include( "AnalysisTriggerEventAthenaPool/AnalysisTriggerEventAthenaPool_joboptions.py" )

EventSelector = Service( "EventSelector" )

# POOL converters for Missing ET and TrackParticles

# POOL converters for Particle Builders
include( "ParticleEventAthenaPool/ParticleEventAthenaPool_joboptions.py" )

# the Dlls

# write out a summary of the time spent
theApp.Dlls += [ "GaudiAud" ]
theAuditorSvc = AuditorSvc()
theAuditorSvc.Auditors  += [ "ChronoAuditor", "MemStatAuditor"]

theApp.Dlls += ["SUSYPhysAlgs"]
theApp.Dlls += ["SUSYPhysUtils"]
theApp.TopAlg += ["SusyMuonCreator"]
theApp.TopAlg += ["SusyJetCreator"]
theApp.TopAlg += ["SusyElectronCreator"]
theApp.TopAlg += ["SusyPhotonCreator"]
# theApp.TopAlg += ["SusyTauCreator"]
theApp.TopAlg += ["SusyGlobalCreator"]
theApp.TopAlg += ["SusyGlobalMcCreator"]

SusyMuonCreator = Algorithm("SusyMuonCreator")
SusyMuonCreator.InputKey = "MuonCollection"
SusyMuonCreator.OutputKey = "SusyMuon"

SusyElectronCreator = Algorithm("SusyElectronCreator")
SusyElectronCreator.InputKey = "ElectronCollection"
SusyElectronCreator.OutputKey = "SusyElectron"

SusyPhotonCreator = Algorithm("SusyPhotonCreator")
SusyPhotonCreator.InputKey = "PhotonCollection"
SusyPhotonCreator.OutputKey = "SusyPhoton"

# SusyTauCreator = Algorithm("SusyTauCreator")
# SusyTauCreator.InputKey = "TauJetCollection"
# SusyTauCreator.OutputKey = "SusyTau"

SusyJetCreator = Algorithm("SusyJetCreator")
SusyJetCreator.Etacut=5.0
SusyJetCreator.InputKey = "ParticleJetContainer"
SusyJetCreator.OutputKey = "SusyJet"

SusyGlobalCreator = Algorithm("SusyGlobalCreator")
SusyGlobalCreator.SimType = "Full"
SusyGlobalCreator.CalibrationType = "H1"
SusyGlobalCreator.InputKey = "MissingETObj"
SusyGlobalCreator.OutputKey = "SusyGlobal"

SusyGlobalCreator = Algorithm("SusyGlobalMcCreator")
SusyGlobalCreator.TruthType = "Calo"
SusyGlobalCreator.Etacut = 5.0
SusyGlobalCreator.InputKey = "SpclMC"
SusyGlobalCreator.OutputKey = "SusyGlobalMc"

theApp.TopAlg += ["SusyPlot"]
SusyPlot=Algorithm("SusyPlot")
SusyPlot.SelectInputKeys=["SusyInclusiveSelTool"]
SusyPlot.PlotInputKeys=[ "jet:SusyJet", "muon:SusyMuon", "electron:SusyElectron", "global:SusyGlobal", "globalmc:SusyGlobalMc"]
SusyPlot.HistogramList=["SusyMuonHistTool", "SusyElectronHistTool", "SusyJetHistTool","SusyGlobalHistTool","SusyInclusiveHistTool"]
# make another folder inside the root file
theApp.TopAlg += ["SusyPlot/OnlyMuon"]
OnlyMuon=Algorithm("OnlyMuon")
OnlyMuon.PlotInputKeys=[ "muon:SusyMuon"]
OnlyMuon.HistogramList=[ "SusyMuonHistTool"]
# The AOD input file
EventSelector.InputCollections = [ 
"/afs/cern.ch/user/c/costanzo/scratch0/AOD/data/AOD_susy0.root",
"/afs/cern.ch/user/c/costanzo/scratch0/AOD/data/AOD_susy1.root",
"/afs/cern.ch/user/c/costanzo/scratch0/AOD/data/AOD_susy2.root",
"/afs/cern.ch/user/c/costanzo/scratch0/AOD/data/AOD_susy3.root",
"/afs/cern.ch/user/c/costanzo/scratch0/AOD/data/AOD_susy4.root",
"/afs/cern.ch/user/c/costanzo/scratch0/AOD/data/AOD_susy5.root",
"/afs/cern.ch/user/c/costanzo/scratch0/AOD/data/AOD_susy6.root",
"/afs/cern.ch/user/c/costanzo/scratch0/AOD/data/AOD_susy7.root",
"/afs/cern.ch/user/c/costanzo/scratch0/AOD/data/AOD_susy8.root",
"/afs/cern.ch/user/c/costanzo/scratch0/AOD/data/AOD_susy9.root"
]

# Set output level threshold (2=DEBUG, 3=INFO, 4=WARNING, 5=ERROR, 6=FATAL )
MessageSvc = Service( "MessageSvc" )
MessageSvc.OutputLevel = 3

# Number of Events to process
theApp.EvtMax = 10000

# Root Ntuple output
theApp.Dlls += [ "RootHistCnv" ]
theApp.HistogramPersistency = "ROOT"
NTupleSvc = Service( "NTupleSvc" )
NTupleSvc.Output = [ "FILE1 DATAFILE='Zll.root' OPT='NEW'" ]
HistogramPersistencySvc = Service( "HistogramPersistencySvc" )
HistogramPersistencySvc.OutputFile = "hist.root";


