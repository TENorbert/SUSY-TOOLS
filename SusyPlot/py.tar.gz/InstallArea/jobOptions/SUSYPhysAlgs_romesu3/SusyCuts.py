# Use Python ntuple to store default cuts
SusyCuts = {
      'ElectronEtaCut'    : 2.5,
      'MuonEtaCut'        : 2.5,
      'JetEtaCut'         : 5.0,
      'TauEtaCut'         : 2.5,
      'PhotonEtaCut'      : 2.5,
      'ElectronPtCut'     : 10000.,
      'MuonPtCut'         : 10000.,
      'JetPtCut'          : 10000.,
      'TauPtCut'          : 30000.,
      'PhotonPtCut'       : 10000.,
      'TauLikelihoodCut'  : 0,
      'MuEtIsolCut'       : 10000,
      'MuChi2Cut'         : 10,
      'ElectronEtIsolCut' : 5000
}

     
# set variable to default if not already set
for o in [ o for o in SusyCuts.keys() if not o in dir() ]:
    exec '%s = SusyCuts[ "%s" ]' % (o,o)

# dump Cuts (it works don't touch it...)
print "Cut Values values:"
for o in SusyCuts.keys():
    exec 'print "%s =",%s ' % (o,o)

