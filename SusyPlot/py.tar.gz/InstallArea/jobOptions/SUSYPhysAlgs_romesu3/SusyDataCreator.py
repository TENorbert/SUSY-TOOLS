# Add the list of Algorithms to run

theApp.TopAlg += ["SusyElectronCreator"]
theApp.TopAlg += ["SusyGlobalCreator"]
theApp.TopAlg += ["SusyJetCreator"]
theApp.TopAlg += ["SusyMuonCreator"]
theApp.TopAlg += ["SusyPhotonCreator"]
theApp.TopAlg += ["SusyTauCreator"]

# set the SG keys for the creators

SusyElectronCreator = Algorithm("SusyElectronCreator")
SusyElectronCreator.InputKey = "ElectronCollection"
SusyElectronCreator.OutputKey = "SusyElectron"
SusyElectronCreator.Etacut=ElectronEtaCut
SusyElectronCreator.Ptcut=ElectronPtCut
SusyElectronCreator.Isolation=ElectronEtIsolCut

SusyGlobalCreator = Algorithm("SusyGlobalCreator")
# This is not right
#SusyGlobalCreator.InputKey = "MET_Calib"
SusyGlobalCreator.InputKey = "MET_Final"
SusyGlobalCreator.OutputKey = "SusyGlobal"

SusyJetCreator = Algorithm("SusyJetCreator")
SusyJetCreator.InputKey = "ConeTowerParticleJets"
SusyJetCreator.OutputKey = "SusyJet"
SusyJetCreator.Etacut=JetEtaCut
SusyJetCreator.Ptcut=JetPtCut

SusyMuonCreator = Algorithm("SusyMuonCreator")
SusyMuonCreator.InputKey = "MuonCollection"
SusyMuonCreator.OutputKey = "SusyMuon"
SusyMuonCreator.Etacut=MuonEtaCut
SusyMuonCreator.Ptcut=MuonPtCut
SusyMuonCreator.Chi2Cut=MuChi2Cut
SusyMuonCreator.Isolation=MuEtIsolCut

SusyPhotonCreator = Algorithm("SusyPhotonCreator")
SusyPhotonCreator.InputKey = "PhotonCollection"
SusyPhotonCreator.OutputKey = "SusyPhoton"
SusyPhotonCreator.Etacut=PhotonEtaCut
SusyPhotonCreator.Ptcut=PhotonPtCut

SusyTauCreator = Algorithm("SusyTauCreator")
SusyTauCreator.InputKey = "TauJetCollection"
SusyTauCreator.OutputKey = "SusyTau"
SusyTauCreator.Etacut=TauEtaCut
SusyTauCreator.Ptcut=TauPtCut
SusyTauCreator.LikelihoodCut=TauLikelihoodCut
