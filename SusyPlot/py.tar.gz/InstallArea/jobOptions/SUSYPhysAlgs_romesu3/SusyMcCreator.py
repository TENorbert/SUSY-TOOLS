# List of MC creators to run:
theApp.TopAlg += ["SusyElectronMcCreator"]
theApp.TopAlg += ["SusyGlobalMcCreator"]
theApp.TopAlg += ["SusyJetTruthCreator"]
theApp.TopAlg += ["SusyMuonMcCreator"]
theApp.TopAlg += ["SusyPhotonMcCreator"]
theApp.TopAlg += ["SusyTauMcCreator"]

# set keys for the SG containers
if (not "InputKey" in dir()):
    InputKey = "SpclMC"

SusyElectronMcCreator = Algorithm("SusyElectronMcCreator")
SusyElectronMcCreator.InputKey = InputKey
SusyElectronMcCreator.OutputKey = "SusyElectronMc"
SusyElectronMcCreator.Etacut=ElectronEtaCut
SusyElectronMcCreator.Ptcut=ElectronPtCut
SusyElectronMcCreator.Isolation=ElectronEtIsolCut

SusyGlobalMcCreator = Algorithm("SusyGlobalMcCreator")
SusyGlobalMcCreator.InputKey = "MET_Truth"
SusyGlobalMcCreator.OutputKey = "SusyGlobalMc"

SusyJetTruthCreator = Algorithm("SusyJetTruthCreator")
SusyJetTruthCreator.InputKey = "ConeTruthParticleJets"
# NOT "SusyJetTruth" !!!
SusyJetTruthCreator.OutputKey = "SusyJetMc"
SusyJetTruthCreator.Etacut=JetEtaCut
SusyJetCreator.Ptcut=JetPtCut

SusyMuonMcCreator = Algorithm("SusyMuonMcCreator")
SusyMuonMcCreator.InputKey = InputKey
SusyMuonMcCreator.OutputKey = "SusyMuonMc"
SusyMuonMcCreator.Etacut=MuonEtaCut
SusyMuonMcCreator.Ptcut=MuonPtCut
SusyMuonMcCreator.Isolation=MuEtIsolCut

SusyPhotonMcCreator = Algorithm("SusyPhotonMcCreator")
SusyPhotonMcCreator.InputKey = InputKey
SusyPhotonMcCreator.OutputKey = "SusyPhotonMc"
SusyPhotonMcCreator.Etacut=PhotonEtaCut
SusyPhotonMcCreator.Ptcut=PhotonPtCut

SusyTauMcCreator = Algorithm("SusyTauMcCreator")
SusyTauMcCreator.InputKey = InputKey
SusyTauMcCreator.OutputKey = "SusyTauMc"
SusyTauMcCreator.Etacut=TauEtaCut
SusyTauMcCreator.Ptcut=TauPtCut
