###############################################################
#
# Job options file
#
#==============================================================
#--------------------------------------------------------------
# General Application Configuration options
#--------------------------------------------------------------
theApp.setup( MONTECARLO )

include( "PartPropSvc/PartPropSvc.py" )

#--------------------------------------------------------------
# Private Application Configuration options
#--------------------------------------------------------------
theApp.ExtSvc += ["AtRndmGenSvc"]
# Set output level threshold (2=DEBUG, 3=INFO, 4=WARNING, 5=ERROR, 6=FATAL )
MessageSvc = Service( "MessageSvc" )
MessageSvc.OutputLevel               = 5
#--------------------------------------------------------------
# Event related parameters
#--------------------------------------------------------------
# Number of events to be processed (default is 10)
theApp.EvtMax = 100000
#
#replace this with the item that you are producing
###include( "GeneratorOptionsRome/rome_M1_pythia_minbais.py" )
include( "./rome_J4_pythia_jetjet.py" )

# these lines are  only essential if your events are weighted.
theApp.Dlls  += [ "GeneratorModules" ]
theApp.TopAlg += [ "CopyEventWeight" ]
# The following lines are needed only if the HepMC event is in a 
# McEventCollection different than G4Truth (this is true if you are running generation)
CopyEventWeight = Algorithm( "CopyEventWeight" )
CopyEventWeight.TruthCollKey = "GEN_EVENT"
#
#---------------------------------------------------------------
#---------------------------------------------------------------
# Pool Persistency
#---------------------------------------------------------------
include( "GeneratorOptionsRome/Generator_pool_out_frag.py" )
Generator_pool_out_frag.py:Stream1.OutputFile = "McEventJ4.root"
#---------------------------------------------------------------
#uncomment the line below if you want to make an atfast ntuple
#
#include( "GeneratorOptionsRome/Generator_to_atlfast.py" )

#
###############################################################

