###############################################################
#
# Job options file
#
#==============================================================
#--------------------------------------------------------------
# Load POOL support
#--------------------------------------------------------------
include( "AthenaPoolCnvSvc/ReadAthenaPool_jobOptions.py" )
include( "GeneratorObjectsAthenaPool/GeneratorObjectsAthenaPool_joboptions.py" )    

include( "PartPropSvc/PartPropSvc.py" )

#--------------------------------------------------------------
# Event related parameters
#--------------------------------------------------------------
theApp.EvtMax = 1000000
EventSelector = Service( "EventSelector" )
EventSelector.InputCollection        = "McEventJ3.root"
#--------------------------------------------------------------
# Private Application Configuration options
#--------------------------------------------------------------
# Load "user algorithm"
#top algorithms to be run, and the libraries that house them

# Must find MC jets
include("JetRec/Cone4TruthJet_jobOptions.py")

theApp.Dlls  += [ "TruthExamples", "GeneratorFilters"]
###theApp.TopAlg = ["DumpMC"]
#
# Put your filter here
theApp.TopAlg += ["QCDBkgFilter"]
# Properties here
#

#--------------------------------------------------------------
# Output options
#--------------------------------------------------------------
Stream1 = Algorithm( "Stream1" )
# Pool Output
theApp.OutStream     +=["Stream1"]
theApp.OutStreamType ="AthenaOutputStream"
Stream1.EvtConversionSvc     ="AthenaPoolCnvSvc"
Stream1.ItemList += ['2101#*',"133273#*" ]
Stream1.OutputFile = "filterJ3.root"
Stream1.AcceptAlgs = [ "QCDBkgFilter" ]

#--------------------------------------------------------------
# Set output level threshold (2=DEBUG, 3=INFO, 4=WARNING, 5=ERROR, 6=FATAL )
#--------------------------------------------------------------
MessageSvc = Service( "MessageSvc" )
MessageSvc.OutputLevel = 3
MessageSvc.defaultLimit = 9999999  # all messages
#==============================================================
#
# End of job options file
#
###############################################################

