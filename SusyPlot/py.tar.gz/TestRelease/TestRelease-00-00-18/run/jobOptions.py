#example of personal topOptions
#
# to use it  
# athena >! athena.log
#  ( myTopOptions.py is defaulted through jobOptions.py soft link)
# 
# see RecExCommon/RecExCommon_flags.py for more available flags
#

# readG3 and AllAlgs needs be set before the include, since several
# secondary flags are configured according to that one
#
# readG3=True # true if read g3 data
# AllAlgs = False # if false, all algorithms are switched off by defaults 
# doiPatRec = False

# From Hong Ma
DetDescrVersion = "Rome-Initial" 
LArCondCnvDbServer = "db1.usatlas.bnl.gov"

# Hacks for 10.0.4
doMuonbox=False
doStaco=False
doxKalman=False

include ("RecExCommon/RecExCommon_flags.py")
PoolRDOInput=["RDO.pool.root"]

# Flags that are defined in python are best set here
# switch off ID and muons
# DetFlags.ID_setOff()
# DetFlags.Muon_setOff()
# switch off xkalman
# InDetFlags.doxKalman=False


# number of event to process
EvtMax=100000

# include my own algorithm(s)
# include my own algorithm
# UserAlgs=[ "MyPackage/MyAlgorithm_jobOptions.py" ] 

# no jet
# doJetRec=False

# For ESD/AOD Production
doWriteAOD = True

# main jobOption
include ("RecExCommon/RecExCommon_topOptions.py")

# user property modifiers should be at the end to overridde all defaults
# TrackParticleTruthMaker.Enable=False 

# very very temporary
# InDetPrepRawDataTruthMaker=Algorithm("InDetPrepRawDataTruthMaker")
# InDetPrepRawDataTruthMaker.Enable=False

# From Hong Ma
NovaCnvSvc  = Service("NovaCnvSvc")
NovaCnvSvc.Host = "db1.usatlas.bnl.gov"
theApp.EvtMax = 100000
RDBAccessSvc = Service( "RDBAccessSvc" )
RDBAccessSvc.Technology = "mysql"
RDBAccessSvc.HostName   = "dbdevel1.usatlas.bnl.gov"
RDBAccessSvc.SchemaName = "ATLASDD"
