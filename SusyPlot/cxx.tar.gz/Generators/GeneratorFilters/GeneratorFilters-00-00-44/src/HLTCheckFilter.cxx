// -------------------------------------------------------------
// File: GeneratorFilters/HLTCheckFilter.cxx
// Description:
//  Applies the generator level filter for electron and jet candidates for DC1
// Must be called after something (e.g. HLTDC1Filter) has created a FilterFlags object and placed it in Storegate
// several instances of this algorithm can be created to return the decisions on the set of Filters in the FilterFlags class
// AuthorList:
//         
// Ian Hinchliffe  May 2002
//
// Header for this module:-

#include "GeneratorFilters/HLTCheckFilter.h"

// Framework Related Headers:-

#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/ISvcLocator.h"
#include "GaudiKernel/DataSvc.h"

#include "GaudiKernel/IIncidentSvc.h"
#include "GaudiKernel/Incident.h"
#include "GeneratorFilters/FilterFlags.h"

//---------------------------------------------------------------------------
HLTCheckFilter::HLTCheckFilter(const std::string& name, 
  ISvcLocator* pSvcLocator) : Algorithm(name, pSvcLocator)
//---------------------------------------------------------------------------
{

}

//---------------------------------------------------------------------------
HLTCheckFilter::~HLTCheckFilter(){

} 
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
StatusCode HLTCheckFilter::initialize(){
//---------------------------------------------------------------------------

  // Inform the user what the mode and conditions are:
  MsgStream log(messageService(), name());

  // make sure that storegate there
  StatusCode sc = service("StoreGateSvc", m_sgSvc);
  if (sc.isFailure()) {
    log << MSG::ERROR << "Could not find StoreGateSvc" << endreq;
    return sc;
  }   
  declareProperty("FilterKey", m_FilterKey="DC1");
  declareProperty("Filternmame", m_FilterName="Cluster");


  return StatusCode::SUCCESS;}

//---------------------------------------------------------------------------
StatusCode HLTCheckFilter::execute() {
//---------------------------------------------------------------------------

  // retrieve the  FilterFlags object from Transient Store (Storegate)

  MsgStream log(messageService(), name());
  
  log << MSG::DEBUG << "HLTCheckFilter::execute()" << endreq;
  if (!(m_sgSvc->retrieve(m_collptr,  m_FilterKey)).isSuccess()) {
    log << MSG::ERROR << "Could not find DataObject" << endreq;
    return( StatusCode::FAILURE);
  }
  // look for the key in question
  for (int i=0; i<m_collptr->length(); ++i){
    if(m_collptr->names()[i]==m_FilterName)  {//found the right filter
      if(m_collptr->values()[i]== true){ // it passed
	return StatusCode::SUCCESS;
      }
      else {
	setFilterPassed(false);
	return StatusCode::SUCCESS;
      }
    }
  }
  log << MSG::ERROR << "The filter " << m_FilterName   << " Does not exist" << endreq;
  return StatusCode::FAILURE;
}

//---------------------------------------------------------------------------
StatusCode HLTCheckFilter::finalize() {
//---------------------------------------------------------------------------
    return StatusCode::SUCCESS;

}

