
/*
* The base class McObj provides the common handling of the four-vector
* and of the sorting. We never need to modify these, so we do not
* declare them virtual. We make the four-vector protected so we can
* access it from the derived classes.
*
* The derived classes McGam, McLep, McJet, and McTau handle the special
* features for each type.
*/

#include "GeneratorFilters/McObj.h"

////////// Base class McObj //////////

McObj::McObj(){ //initialized to zero
}

void McObj::SetP(const double& px,const double& py, const double& pz,
  const double& e){
  m_p.setPx(px);
  m_p.setPy(py);
  m_p.setPz(pz);
  m_p.setE(e);
}

void McObj::SetXYZM(const double& px,const double& py, const double& pz,
  const double& m){
  m_p.setPx(px);
  m_p.setPy(py);
  m_p.setPz(pz);
  m_p.setE(sqrt(m*m+px*px+py*py+pz*pz));
  }






