// -------------------------------------------------------------------------------------------------------------------
// 
// File:         GeneratorFilters/BSignalFilter.cxx
//
// Description:  Finds all B-chains, applies cuts specified in jobOptionsFile
//               and writes all events that passed into an nTuple.
//
// Author: Malte Muller   <maltemlr@yahoo.co.uk>
// August 2002      Malte Muller 
// Sept   2002      M.Smizanska: minor updates in fill Ntuple  
// Dec    2003      M.Smizanska: filtering out events with B-hadrons
//                               left undecayed either in Pythia or in EvtGen.
//                               This is used as a method of selecting only wanted
//                               exclusive channels into persistent output. See PythiaB manual.                   
// Feb	  2004	    J. Catmore   LVL1/LVL2 cut facility added.
// -------------------------------------------------------------------------------------------------------------------


#include <cmath>
#include <string>
#include <vector>

// Header for this module
#include "GeneratorFilters/BSignalFilter.h"

// Framework Related Headers
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"
#include "GaudiKernel/SmartDataPtr.h"
#include "GaudiKernel/DataSvc.h"
#include "GaudiKernel/PropertyMgr.h"
#include "GaudiKernel/ISvcLocator.h"
#include "GaudiKernel/IDataProviderSvc.h"
#include "GaudiKernel/ObjectList.h"

// nTuple support
#include "GaudiKernel/INTupleSvc.h"

// HepMC-structures
#include "HepMC/GenEvent.h"
#include "HepMC/GenParticle.h"
#include "HepMC/GenVertex.h"

#include "CLHEP/HepPDT/ParticleDataTable.hh"
#include "CLHEP/HepPDT/ParticleData.hh"

BSignalFilter::BSignalFilter(const std::string& name, ISvcLocator* pSvcLocator) :
	GenFilter(name, pSvcLocator)
{
	// Declare the algorithm's properties
        declareProperty("LVL1MuonCutOn",	     localLVL1MuonCutOn = false);
	declareProperty("LVL2MuonCutOn",	     localLVL2MuonCutOn = false);
	declareProperty("LVL2ElectronCutOn",	     localLVL2ElectronCutOn = false);
	declareProperty("LVL1MuonCutPT",	     localLVL1MuonCutPT = 0.0);
	declareProperty("LVL1MuonCutEta",	     localLVL1MuonCutEta = 102.5);
	declareProperty("LVL2MuonCutPT",	     localLVL2MuonCutPT = 0.0);
	declareProperty("LVL2MuonCutEta",            localLVL2MuonCutEta = 102.5);
	declareProperty("LVL2ElectronCutPT",	     localLVL2ElectronCutPT = 0.0);
	declareProperty("LVL2ElectronCutEta",        localLVL2ElectronCutEta = 102.5);
	declareProperty("Cuts_Final_e_switch",       m_cuts_f_e_on    = false );
	declareProperty("Cuts_Final_e_pT",           m_cuts_f_e_pT    = 500. );
	declareProperty("Cuts_Final_e_eta",          m_cuts_f_e_eta   = 2.5 );
	declareProperty("Cuts_Final_mu_switch",      m_cuts_f_mu_on   = false );
	declareProperty("Cuts_Final_mu_pT",          m_cuts_f_mu_pT   = 3000. );
	declareProperty("Cuts_Final_mu_eta",         m_cuts_f_mu_eta  = 2.5 );
	declareProperty("Cuts_Final_hadrons_switch", m_cuts_f_had_on  = false );
	declareProperty("Cuts_Final_hadrons_pT",     m_cuts_f_had_pT  = 500. );
	declareProperty("Cuts_Final_hadrons_eta",    m_cuts_f_had_eta = 2.5 );
	declareProperty("Cuts_Final_gamma_switch",   m_cuts_f_gam_on  = false );
	declareProperty("Cuts_Final_gamma_pT",       m_cuts_f_gam_pT  = 2000. );
	declareProperty("Cuts_Final_gamma_eta",      m_cuts_f_gam_eta = 2.5 );
	declareProperty("Cuts_Final_K0_switch",      m_cuts_f_K0_on  = false );
	declareProperty("Cuts_Final_K0_pT",          m_cuts_f_K0_pT  = 1000. );
	declareProperty("Cuts_Final_K0_eta",         m_cuts_f_K0_eta = 2.5 );
	declareProperty("SignaltoNtup",              m_Ntuples);
	
	// initialize pointer to nTuple
	m_nTuple = 0;
	
	// initialise event counter
	m_EventCnt = 0;
	
};





StatusCode BSignalFilter::filterInitialize()
{
	// start massageService
	MsgStream log(messageService(), name());
	log << MSG::DEBUG << ">>> BSignalFilter::FilterInitialize" << endreq;
	
	return StatusCode::SUCCESS;
};





StatusCode BSignalFilter::filterEvent() {

	// start massageService
	MsgStream log(messageService(), name());
	log << MSG::INFO << ">>> BSignalFilter::FilterEvent" << endreq;

	// Begin Iterating Over McEventCollection
	McEventCollection::const_iterator it;
	for( it=m_cCollptr->begin(); it!=m_cCollptr->end(); it++ )   {
		
		m_EventCnt++;
		m_tempStore.reset();
		// cout << endl
		//	 << " **************** Event no." << m_EventCnt << endl
		//	 << endl;
		
		// Iterate over MC particles
		
		const HepMC::GenEvent* genEvt = (*it);
		HepMC::GenEvent::particle_const_iterator pitr;
		const HepMC::GenParticle* p;
		
		// TEMPORARY FIX: reject whole event if B comes from anything else than parton system fragmentation,
		//                since this probably means that there is a major slip in this MCEventCollection.
		bool rejectEvent = false, motherIsPSF;
                
                // Check HepMC for particles activating LVL1 trigger, if that is what user wishes
		
                bool LVL1Result, LVL1Passed;
		int LVL1MuonBarcode;
		LVL1Passed = false;
		LVL1Result = false;
		if(localLVL1MuonCutOn) {
		        
			for( pitr=genEvt->particles_begin(); pitr!=genEvt->particles_end(); ++pitr )   {
				p = *pitr;
				LVL1Result = LVL1Trigger( p );
				if (LVL1Result) {
					LVL1Passed = true;
					LVL1MuonBarcode = p->barcode();      // Remember the muon for LVL2 testing
					break;
				}
					
			}
		}
		
		// Check HepMC for particles activating LVL2 trigger, if that is what user wishes
		
                bool LVL2Result, LVL2Passed;
		LVL2Passed = false;
		LVL2Result = false;
		
		if(LVL1Passed && (localLVL2MuonCutOn || localLVL2ElectronCutOn)) {
		        
			for( pitr=genEvt->particles_begin(); pitr!=genEvt->particles_end(); ++pitr )   {
				p = *pitr;
				LVL2Result = LVL2Trigger( p );
				if (LVL2Result) {
					if (p->barcode() != LVL1MuonBarcode) // Check the particle triggering LVL2 isn't the muon
						LVL2Passed = true;	     // that triggered LVL1
				}
			}
		}
		
		// flag event as passing LVL1 if it has passed
		if (localLVL1MuonCutOn && LVL1Passed) {
			log << MSG::DEBUG << "LVL1 Trigger activated for event " << m_EventCnt << endreq;
			++LVL1Counter;
		}
		
		// flag event as passing LVL2 if it has passed
		if ((localLVL2MuonCutOn || localLVL2ElectronCutOn) && LVL2Passed) {
			log << MSG::DEBUG << "LVL2 Trigger activated for event " << m_EventCnt << endreq;
			++LVL2Counter;
		}
				
		// if user hasn't requested triggers then set everything to true so nothing is thrown away	
                if (!localLVL1MuonCutOn) {
			LVL1Passed = true;
			LVL2Passed = true;
		}
		if ((!localLVL2MuonCutOn) && (!localLVL2ElectronCutOn))
			LVL2Passed = true;							
					

                if (LVL1Passed && LVL2Passed) {        

		for( pitr=genEvt->particles_begin(); pitr!=genEvt->particles_end(); ++pitr )   {
			
			p = *pitr;
			
			int testID = p->pdg_id();
			
			bool motherIsB = false, newBChain = true;
			
			if( isBMeson(testID) || isBBaryon(testID) )   {
				
				HepMC::GenVertex::particle_iterator firstParent, lastParent, thisParent;
				firstParent = p->production_vertex()->particles_begin(HepMC::parents);
			    lastParent  = p->production_vertex()->particles_end(HepMC::parents);
          
			// Reject whole event is any of B-hadrons in the event is not decayed	
          if(p->status() == 1 || p->status() == 899 ) { rejectEvent = true; };
              
				motherIsPSF = false;
				for(thisParent = firstParent; thisParent != lastParent++; ++thisParent)   {
					int parentID = (*thisParent)->pdg_id();
					
					if( isBMeson(parentID) || isBBaryon(parentID) )   { motherIsB = true; };
					
					// codes 91, 92, 93 are parton system fragmentations
					if( (parentID>=91) && (parentID<=93) )            { motherIsPSF = true; };
				};
				if( motherIsB )   { newBChain = false; }   // since chain is not new
					else if( !motherIsPSF )   { rejectEvent = true; };   // reject event if any B-mother is neither B nor PSF
			}
			else   { newBChain = false; };   // since particle is not b
			
			// new B-signal found, output message and find whole decay tree
			if( newBChain )   {
				
				log << MSG::DEBUG 
			   		 << "*** BSignalFilter.cxx: B-signal found ***" << std::endl
					 << "     ( Event " << m_EventCnt << ", chain " << (m_tempStore.chains()+1) << " )" << std::endl
				   	 << "------------------------------------" << std::endl
					 << std::endl
        	       	 << "B-hadron id " << testID << " , status " << (p->status()) << std::endl
					 << endreq;
				
				m_tempStore.newChain();
				m_tempStore.addParticle(p,0);
				
				findAllChildren(p,"",false);
			};  // End newBChain
			
		}; // end particle iteration
		}; // end of LVL1/LVL2 selection
    
 // For rejected events setFilterPassed =false will prevent the event
 // to being written to permanent store output if it is required in jobOptions   

		// Reject event if triggers not activated. If not requested by user these flags will be set to true so there will be
		// no erroneous rejection 
                if ((!LVL1Passed) || (!LVL2Passed)) {
			rejected++;
			rejectEvent = true;
		}
    
		std::cout << std::endl;
		if( rejectEvent )   {
      setFilterPassed(false);
			rejectedAll++;
			log << MSG::INFO << "Event rejected by Filter" << endreq;
		}
		else   { writeToNTuple(); };
		std::cout << std::endl;
		
	};  // end event iteration

	// End of execution for each event
	return StatusCode::SUCCESS;		 
}












void BSignalFilter::findAllChildren(const HepMC::GenParticle* mother,
	std::string treeIDStr, bool fromFinalB)
{
	MsgStream log(messageService(), name());
	
	if ( !(mother->end_vertex()) && (mother->status() != 2) )   {           // i.e. this is a finalState
		if( fromFinalB ) m_tempStore.addCutResult( finalStateCutsPassed( mother ) );
		return;
	}
	else {
		if ( !(mother->end_vertex()) )   {           // i.e. something is wrong in HepMC
			m_tempStore.addCutResult( false );
			log << MSG::ERROR
				<< "Inconsistent entry in HepMC (status 2 particle not decayed), chain rejected!" << endreq;    
			return;
		};
	};
	
	HepMC::GenVertex::particle_iterator firstChild, thisChild, lastChild;
	const HepMC::GenParticle* child;
	
	firstChild = mother->end_vertex()->particles_begin(HepMC::children);
	lastChild = mother->end_vertex()->particles_end(HepMC::children);
	
	int childCnt = 0;
	std::string childIDStr;
	if( !( treeIDStr=="" ) ) treeIDStr = treeIDStr + ".";
	int currentNumber = m_tempStore.particles();
	
	// to find out whether particle is child of final (non-excited) B, used for cuts
	int pID = mother->pdg_id();
	if( (!fromFinalB) && (isBMeson(pID)||isBBaryon(pID)) ) {
		fromFinalB = true;
		int pID;
		for( thisChild = firstChild; thisChild != lastChild++; ++thisChild)   {
			pID = (*thisChild)->pdg_id();
			if( isBMeson(pID) || isBBaryon(pID) )   fromFinalB = false;
		};
	};

	// main loop: iterate over all children, call method recursively.
	
	for( thisChild = firstChild; thisChild != lastChild++; ++thisChild)   {
		
		childCnt++;
		childIDStr = treeIDStr + longToStr( childCnt );
		
		child = *thisChild;
		
		printChild( child, childIDStr, fromFinalB );
		m_tempStore.addParticle( child, currentNumber );
		findAllChildren( child, childIDStr, fromFinalB );
	};
	
	return;
};


bool BSignalFilter::LVL1Trigger(const HepMC::GenParticle* child) const
{
	bool cut = false;
	int pID = child->pdg_id();
	double myPT  = child->momentum().perp();
	double myEta = child->momentum().pseudoRapidity();

	if ( (abs(pID) == 13)     && localLVL1MuonCutOn )
		cut  =  Trigger_Test( myPT, localLVL1MuonCutPT,  myEta, localLVL1MuonCutEta);
		
	return cut;
	
};

bool BSignalFilter::LVL2Trigger(const HepMC::GenParticle* child) const
{
	bool cut = false;
	
	int pID = child->pdg_id();
	double myPT  = child->momentum().perp();
	double myEta = child->momentum().pseudoRapidity();

	if ( (abs(pID) == 11)     && localLVL2ElectronCutOn )
		cut  =  fSC_Test( myPT, localLVL2ElectronCutPT,  myEta, localLVL2ElectronCutEta);
	if ( (abs(pID) == 13)     && localLVL2MuonCutOn )
		cut  =  Trigger_Test( myPT, localLVL2MuonCutPT,  myEta, localLVL2MuonCutEta);
	
	return cut;
	
};


bool BSignalFilter::finalStateCutsPassed(const HepMC::GenParticle* child) const
{
	bool cut=false;
	
	int pID = child->pdg_id();
	double myPT  = child->momentum().perp();
	double myEta = child->momentum().pseudoRapidity();
	
	//cout << "Testing cut for id " << pID << endl
	//	 << " ,  pT = " << myPT << endl
	//	 << " , eta = " << myEta << endl;
	
	if ( (abs(pID) == 11)     && m_cuts_f_e_on )
		cut  =  fSC_Test( myPT, m_cuts_f_e_pT,   myEta, m_cuts_f_e_eta);
		
	if ( (abs(pID) == 13)     && m_cuts_f_mu_on )
		cut  =  fSC_Test( myPT, m_cuts_f_mu_pT,  myEta, m_cuts_f_mu_eta);
		
	if ( isChargedHadron(pID) && m_cuts_f_had_on )
		cut  =  fSC_Test( myPT, m_cuts_f_had_pT, myEta, m_cuts_f_had_eta);
		
	if ( (pID == 22)          && m_cuts_f_gam_on )
		cut  =  fSC_Test( myPT, m_cuts_f_gam_pT, myEta, m_cuts_f_gam_eta);
		
	if ( (abs(pID) == 311)    && m_cuts_f_K0_on )
		cut  =  fSC_Test( myPT, m_cuts_f_K0_pT,  myEta, m_cuts_f_K0_eta);
	
	return (!cut);
};


bool BSignalFilter::Trigger_Test(const double myPT, const double testPT,
	const double myEta, const double testEta) const
{
	bool trigger = false;
	if ( (myPT >= testPT) && (fabs(myEta) <= testEta) )
		trigger = true;
		
	return trigger;
};
	

bool BSignalFilter::fSC_Test(const double myPT, const double testPT,
	const double myEta, const double testEta) const
{
	MsgStream log(messageService(), name());
	
	bool cut=false;
	if ( (myPT < testPT) || (fabs(myEta) > testEta) )   cut = true;
	
	/*
	std::string cutStr = "passed";
	if (cut) cutStr = "failed";
	
	cout << "Testing PT    " << myPT  << "  >  " << testPT  << endl
		 << "        Eta   " << myEta << "  <  " << testEta << endl
		 << "        Result: " << cutStr << endl
		 << endl;
	*/
	
	return cut;
};




void BSignalFilter::printChild(const HepMC::GenParticle* child,
	const std::string treeIDStr, const bool fromFinalB) const
{
	MsgStream log(messageService(), name());
	
	// find id
	int pID = child->pdg_id();
	
	// find name
// 	HepMC::ParticleData* pData = m_particleTable.find( abs(pID) );
	const HepPDT::ParticleData* pData = m_particleTable->particle(HepPDT::ParticleID(abs(pID)));
 	std::string pName = "unknown particle";
	if (pData)   { 
		if (pID<0) { pName="anti - "; }
			else { pName=""; };
		pName += pData->name();
	};
		
	log << MSG::DEBUG << "    " << treeIDStr << "   " << "child id " << pID << " (" << pName
	                 << ") ,  status " << (child->status()) << endreq;
		 
	return;
};


bool BSignalFilter::isBMeson(const int pID) const
{	
	// PdgID of B-meson is of form ...xxx05xx
	
	std::string idStr = longToStr( abs(pID) );
	char digit3 = idStr[ idStr.length() - 3 ];
	char digit4;
	if( idStr.length() < 4 ) { digit4 = '0'; }
		else { digit4 = idStr[ idStr.length() - 4 ]; };
	
	//cout << pID << " : "  << digit4 << "," << digit3 << endl;
	
	if( (digit4=='0') && (digit3=='5') ) { return true; }
		else { return false; };
};


bool BSignalFilter::isBBaryon(const int pID) const
{	
	// PdgID of B-baryon is of form ...xxx5xxx
	
	std::string idStr = longToStr( abs(pID) );
	char digit4 = idStr[ idStr.length() - 4 ];
	
	//cout << pID << " : " << digit4 << endl;
	
	if( (digit4=='5') ) { return true; }
		else { return false; };
};


bool BSignalFilter::isChargedHadron(const int pID) const
{
// 	HepMC::ParticleData* pData = m_particleTable->find( abs(pID) );
	const HepPDT::ParticleData* pData = m_particleTable->particle(HepPDT::ParticleID( abs(pID) ));
	double pCharge = 0;
	if (pData) { pCharge = pData->charge(); };
	
	// charge nonzero and id>100 => charged hadron
	
	if ( (pCharge!=0) && (abs(pID)>=100) ) { return true; }
		else { return false; };
};


void BSignalFilter::initNTuple()
{
	// this creates n-Tuple for output of decay chain
	
	MsgStream log(messageService(), name());
	log << MSG::DEBUG << "Initialising B-Event nTuple" << endreq;
	
	StatusCode sc;
	NTuplePtr myNT( ntupleSvc(), "FILE1/100" );
	
	if( !myNT ) {
		myNT = ntupleSvc()->book( "FILE1/100", CLID_ColumnWiseTuple, "B-chain particle nTuple" );
		if( myNT ) {
			
			sc = myNT->addItem("particles",       m_nTuple_nParticles, 0, 99);   // seems like a reasonable upper bound
			
			sc = myNT->addItem("event_number",    m_nTuple_nParticles, m_nTuple_eventCnt);
			sc = myNT->addItem("chain_number",    m_nTuple_nParticles, m_nTuple_chainCnt);
			sc = myNT->addItem("particle_number", m_nTuple_nParticles, m_nTuple_particleCnt);
			sc = myNT->addItem("id",              m_nTuple_nParticles, m_nTuple_id);
			sc = myNT->addItem("status",          m_nTuple_nParticles, m_nTuple_status);
			sc = myNT->addItem("child_of",        m_nTuple_nParticles, m_nTuple_parent);
			
			sc = myNT->addItem("px",              m_nTuple_nParticles, m_nTuple_px);
			sc = myNT->addItem("py",              m_nTuple_nParticles, m_nTuple_py);
			sc = myNT->addItem("pz",              m_nTuple_nParticles, m_nTuple_pz);
			sc = myNT->addItem("pe",              m_nTuple_nParticles, m_nTuple_pE);
			sc = myNT->addItem("pt",              m_nTuple_nParticles, m_nTuple_pT);
			sc = myNT->addItem("mass",            m_nTuple_nParticles, m_nTuple_mass);
			
			sc = myNT->addItem("phi",             m_nTuple_nParticles, m_nTuple_phi);
			sc = myNT->addItem("rapidity",        m_nTuple_nParticles, m_nTuple_rapidity);
			sc = myNT->addItem("pseudorapidity",  m_nTuple_nParticles, m_nTuple_pseudoRapidity);

			m_nTuple = myNT;
		}
		else {
			log << MSG::ERROR << " ERROR booking nTuple" << endreq;
		};
	};
	
	return;
};


void BSignalFilter::writeToNTuple()
{
	// this writes current chains from tempStore into nTuple
	
	MsgStream log(messageService(), name());
	StatusCode sc;
	
	// putting all tempStore chains into nTuple for users defined number of accepted evnts
	
	if(m_EventCnt<=m_Ntuples)
      {
	for( long chainCnt = 0; chainCnt < m_tempStore.chains(); chainCnt++ )   {
		
		if( m_tempStore.passedCuts(chainCnt) )   {
		
			log << MSG::DEBUG << "*** Event " << m_EventCnt << ", chain " << (chainCnt+1)
				<< " :   ACCEPTED   (passed all cuts) ***" << endreq;
			
			if( m_nTuple == 0 ) initNTuple();   // initialise upon first use
			
			m_nTuple_nParticles = m_tempStore.particles( chainCnt );
			
			for( int particleCnt = 0; particleCnt < m_nTuple_nParticles; particleCnt++ )   {
			
				m_nTuple_eventCnt[particleCnt]       = m_EventCnt;
				m_nTuple_chainCnt[particleCnt]       = chainCnt + 1;
				m_nTuple_particleCnt[particleCnt]    = particleCnt + 1;
				m_nTuple_id[particleCnt]             = (long)m_tempStore.value( chainCnt, particleCnt, "id" );
				m_nTuple_status[particleCnt]         = (long)m_tempStore.value( chainCnt, particleCnt, "status" );
				m_nTuple_parent[particleCnt]         = (long)m_tempStore.value( chainCnt, particleCnt, "parent" );
				
				m_nTuple_px[particleCnt]             = m_tempStore.value( chainCnt, particleCnt, "px" );
				m_nTuple_py[particleCnt]             = m_tempStore.value( chainCnt, particleCnt, "py" );
				m_nTuple_pz[particleCnt]             = m_tempStore.value( chainCnt, particleCnt, "pz" );
				m_nTuple_pE[particleCnt]             = m_tempStore.value( chainCnt, particleCnt, "pE" );
				m_nTuple_pT[particleCnt]             = m_tempStore.value( chainCnt, particleCnt, "pT" );
				m_nTuple_mass[particleCnt]           = m_tempStore.value( chainCnt, particleCnt, "mass" );
	
				m_nTuple_phi[particleCnt]            = m_tempStore.value( chainCnt, particleCnt, "phi" );
				m_nTuple_rapidity[particleCnt]       = m_tempStore.value( chainCnt, particleCnt, "rapidity" );
				m_nTuple_pseudoRapidity[particleCnt] = m_tempStore.value( chainCnt, particleCnt, "pseudoRapidity" );
			};
	
			log << MSG::DEBUG << "About to writeRecord to nTuple ..." << endreq;
			sc = ntupleSvc()->writeRecord(m_nTuple);
			log << MSG::DEBUG << "... writeRecord complete" << endreq;
		}
		else   {
			log << MSG::DEBUG << "*** Event " << m_EventCnt << ", chain " << (chainCnt+1)
				<< " :   REJECTED   (did not pass all cuts) ***" << endreq;
		};
	}; // end of loop over the B-chains in this event
	}; // end of if(m_EventCnt<=m_Ntuples)
	return;
};


StatusCode BSignalFilter::filterFinalize()
{
	MsgStream log(messageService(), name());
        double total = m_EventCnt;
	log << MSG::INFO << "I===============================================================================================" << endreq;
	log << MSG::INFO << "I                                    BSignalFilter Summary Report                               " << endreq;
	log << MSG::INFO << "I===============================================================================================" << endreq;
        if (localLVL1MuonCutOn) {
		log << MSG::INFO << "I  LVl1 muon trigger report:" << endreq;
		log << MSG::INFO << "I        pT cut " << '\t' << '\t' << '\t' << '\t' << '\t' << '\t' << '\t' << '\t' << "I" << '\t' << localLVL1MuonCutPT << " MeV " << endreq;
		log << MSG::INFO << "I        Pseudo-rapidity cut" << '\t' << '\t' << '\t' << '\t' << '\t' << '\t' << '\t' << "I" << '\t' << localLVL1MuonCutEta << endreq;
		log << MSG::INFO << "I        No of events containing at least " << '\t' << '\t' << '\t' << '\t' << '\t' << "I" << endreq;
		log << MSG::INFO << "I        one particle satisfying these cuts " << '\t' << '\t' << '\t' << '\t' << '\t' << "I" << '\t' << LVL1Counter << endreq;
		if (localLVL2MuonCutOn) {
	 		log << MSG::INFO << "I  LVl2 muon trigger report:" << endreq;
			log << MSG::INFO << "I        Muon pT cut " << '\t' << '\t' << '\t' << '\t' << '\t' << '\t' << '\t' << '\t' << "I" << '\t' << localLVL2MuonCutPT << " MeV " << endreq;
			log << MSG::INFO << "I        Muon pseudo-rapidity cut " << '\t' << '\t' << '\t' << '\t' << '\t'  << '\t' << "I" << '\t' << localLVL2MuonCutEta << endreq;
		}
		if (localLVL2ElectronCutOn) {
	 		log << MSG::INFO << "I  LVl2 electron trigger report:" << endreq;
			log << MSG::INFO << "I        Electron pT cut " << '\t' << '\t' << '\t' << '\t' << '\t' << '\t' << '\t' <<
			"I" << '\t' << localLVL2ElectronCutPT << " MeV " << endreq;
			log << MSG::INFO << "I        Electron pseudo-rapidity cut " << '\t' << '\t' << '\t' << '\t' << '\t' << "I"
			<< '\t' << localLVL2ElectronCutEta << endreq;
		}
		if (localLVL2MuonCutOn || localLVL2ElectronCutOn) {
			log << MSG::INFO << "I        No of events containing at least one muon satisfying LVL1 cut" << '\t' << "I" << endreq;
			log << MSG::INFO << "I        and at least one separate particle passing these LVL2 cuts " << '\t' << '\t' << "I" <<
			'\t' << LVL2Counter << endreq;
		}
        }
        log << MSG::INFO << "I  Total no of input events " << '\t'<< '\t'<< '\t'<< '\t'<< '\t'<< '\t'<< '\t' << "I" << '\t' << total << endreq; 
	log << MSG::INFO << "I  No of events rejected by trigger " << '\t' << '\t'<< '\t'<< '\t'<< '\t'<< '\t'<< '\t' << "I" << '\t' << rejected << endreq; 
	log << MSG::INFO << "I  No of events rejected in total " << '\t' << '\t'<< '\t'<< '\t'<< '\t'<< '\t'<< '\t' << "I" << '\t' << rejectedAll << endreq; 
	if (localLVL1MuonCutOn && (!localLVL2MuonCutOn && !localLVL2ElectronCutOn))
		log << MSG::INFO << "I  To obtain correct cross section, multiply BX in PythiaB report by " << '\t' << '\t' << "I" << '\t' <<LVL1Counter / total << endreq;
	if (localLVL1MuonCutOn && (localLVL2MuonCutOn || localLVL2ElectronCutOn))
		log << MSG::INFO << "I  To obtain correct cross section, multiply BX in PythiaB report by " << '\t' << '\t' << "I" << '\t' 
		<< LVL2Counter/(total) << endreq;
	if (!localLVL1MuonCutOn)
		log << MSG::INFO << "I  No trigger requests made" << endreq;
	log << MSG::INFO << "I============================================End of report=======================================" << endreq;
			 




	
	return StatusCode::SUCCESS;
}


std::string BSignalFilter::longToStr( const long n ) const {
	
	if (0==n) return "0";
	
	std::string str = "";
	for ( long m = n; m!=0; m/=10 )
		str = char( '0' + abs(m%10) ) + str;
	if ( n<0 )
		str = "-" + str;
	return str;
};






tempStore::tempStore()
{
	this->reset();
};


void tempStore::reset()
{
	m_Chains.clear();
	return;
};


void tempStore::newChain()
{
	tS_chain newChain;
	newChain.passedCuts = true;      // should be done in a constructor...
	m_Chains.push_back( newChain );
	return;
};


void tempStore::addParticle( const HepMC::GenParticle* p, const int parent )
{
	tS_particle newParticle;

	newParticle.id             = p->pdg_id();
	newParticle.status         = p->status();
	newParticle.parent         = parent;
	newParticle.px             = p->momentum().x();
	newParticle.py             = p->momentum().y();
	newParticle.pz             = p->momentum().z();
	newParticle.pE             = p->momentum().e();
	newParticle.pT             = p->momentum().perp();
	newParticle.mass           = p->momentum().m();
	newParticle.phi            = p->momentum().phi();
	newParticle.rapidity       = p->momentum().rapidity();
	newParticle.pseudoRapidity = p->momentum().pseudoRapidity();
	
	m_Chains.back().vec.push_back( newParticle );
	
	return;
};


void tempStore::addCutResult( const bool newResult )
{
	m_Chains.back().passedCuts = ( m_Chains.back().passedCuts && newResult );
	return;
};


long tempStore::chains() const   { return m_Chains.size(); };
int tempStore::particles() const                     { return m_Chains[this->chains()-1].vec.size(); };
int tempStore::particles( const long chain ) const   { return m_Chains[chain].vec.size(); };


double tempStore::value( const long chain, const long particle,
	const std::string propertyStr ) const
{
	if( propertyStr == "id" )               return m_Chains[chain].vec[particle].id;
	if( propertyStr == "status" )           return m_Chains[chain].vec[particle].status;
	if( propertyStr == "parent" )           return m_Chains[chain].vec[particle].parent;
	if( propertyStr == "px" )               return m_Chains[chain].vec[particle].px;
	if( propertyStr == "py" )               return m_Chains[chain].vec[particle].py;
	if( propertyStr == "pz" )               return m_Chains[chain].vec[particle].pz;
	if( propertyStr == "pE" )               return m_Chains[chain].vec[particle].pE;
	if( propertyStr == "pT" )               return m_Chains[chain].vec[particle].pT;
	if( propertyStr == "mass" )             return m_Chains[chain].vec[particle].mass;
	if( propertyStr == "phi" )              return m_Chains[chain].vec[particle].phi;
	if( propertyStr == "rapidity" )         return m_Chains[chain].vec[particle].rapidity;
	if( propertyStr == "pseudoRapidity" )   return m_Chains[chain].vec[particle].pseudoRapidity;
		
	return 0;
};


bool tempStore::passedCuts( const long chain ) const
{
	return m_Chains[chain].passedCuts;
};
