 #ifndef _FILTERFLAGS_
 #define _FILTERFLAGS_
 //Class to contain the filter names and results than can be put into storegate
 //it just wraps a collection of strings and bools
// Authorlist
// Ian Hinchliffe May 2002
//
#include "GeneratorFilters/FilterFlags.h" 
   FilterFlags::FilterFlags(std::vector<std::string> list,  std::vector<bool> list_val ){
     m_tname=list;
     m_tpass=list_val;
   }
   FilterFlags::FilterFlags(std::string str , bool val ) {
     m_tname.push_back(str);
     m_tpass.push_back(val);
     }
   int FilterFlags::length() const {return  m_tname.size();}
   std::vector<std::string>  FilterFlags::names() const { return m_tname;}
   std::vector<bool> FilterFlags::values() const {return  m_tpass;}
  
 //using the macros below we can assign an identifier (and a version) 
 //to the type FilterFlags
 //This is required and checked at compile time when you try to record/retrieve

 //class version is not currently used
 
 #endif

