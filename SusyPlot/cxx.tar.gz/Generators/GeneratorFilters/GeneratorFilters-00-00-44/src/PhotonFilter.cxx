// -------------------------------------------------------------
// File: GeneratorFilters/PhotonFilter.cxx
// Description:
//   Allows the user to search for photons
// will pass if there are the specified number of  photons  with p_t and eta in the specified range
// default is p_t>10 GeV and  eta<2.5  and two photons
//
// AuthorList:
//         
// Ian Hinchliffe  May 2004
//

// Header for this module:-

#include "GeneratorFilters/PhotonFilter.h"

// Framework Related Headers:-
#include "GaudiKernel/MsgStream.h"


// Other classes used by this class:-
#include <math.h>

using HepMC::GenVertex;
using HepMC::GenParticle;

//--------------------------------------------------------------------------
PhotonFilter::PhotonFilter(const std::string& name, 
			   ISvcLocator* pSvcLocator): GenFilter(name,pSvcLocator) {
  //----------------------------    
  declareProperty("Ptcut",m_Ptmin = 10000.);  
  declareProperty("Etacut",m_EtaRange = 2.50); 
  declareProperty("NPhotons",m_NPhotons = 2); 
}

//--------------------------------------------------------------------------
PhotonFilter::~PhotonFilter(){
//--------------------------------------------------------------------------

}

//---------------------------------------------------------------------------
StatusCode PhotonFilter::filterInitialize() {
//---------------------------------------------------------------------------

  return StatusCode::SUCCESS;
}

//---------------------------------------------------------------------------
StatusCode PhotonFilter::filterFinalize() {
//---------------------------------------------------------------------------
  return StatusCode::SUCCESS;
}


//---------------------------------------------------------------------------
StatusCode PhotonFilter::filterEvent() {
  //---------------------------------------------------------------------------

// Loop over all events in McEventCollection
  int NPhotons=0;
  McEventCollection::const_iterator itr;
  for (itr = m_cCollptr->begin(); itr!=m_cCollptr->end(); ++itr) {
    // Loop over all particles in the event
    const HepMC::GenEvent* genEvt = (*itr);
    for(HepMC::GenEvent::particle_const_iterator pitr=genEvt->particles_begin();
	pitr!=genEvt->particles_end(); ++pitr ){
      if( ((*pitr)->pdg_id() == 22) ){
	if( (*pitr)->status()==1 &&
	    ((*pitr)->momentum().perp() >=m_Ptmin) && 
	    fabs((*pitr)->momentum().pseudoRapidity()) <=m_EtaRange){ 
	  NPhotons++;
	}
      }
    }	
  }
  if(NPhotons >= m_NPhotons)  {
    return StatusCode::SUCCESS;
  }
  setFilterPassed(false);
  return StatusCode::SUCCESS;
}
