
// -------------------------------------------------------------
// File: GeneratorModules/GenModule.cxx
// Description:
//    This class is the base class used to specify the behavior of all
//    event generator filters and is meant to capture the common behavior
//    of these filters. 
//
// AuthorList:
//         I Hinchliffe December 2001
//

// Header for this module:-

#include <fstream>

#include "GeneratorFilters/GenFilter.h"

// Framework Related Headers:-

#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/ISvcLocator.h"
#include "GaudiKernel/DataSvc.h"


#include "GaudiKernel/IIncidentSvc.h"
#include "GaudiKernel/Incident.h"
#include "PartPropSvc/PartPropSvc.h"

// Other Packages used by this class:-

#include "CLHEP/HepPDT/TableBuilder.hh"


//---------------------------------------------------------------------------
GenFilter::GenFilter(const std::string& name, 
  ISvcLocator* pSvcLocator) : Algorithm(name, pSvcLocator)
//---------------------------------------------------------------------------
{

  HepPDT::ParticleDataTable m_particleTable("PDG Table");
  declareProperty("TotalPassed",m_nNeeded = -1);
}

//---------------------------------------------------------------------------
GenFilter::~GenFilter(){

} 
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
StatusCode GenFilter::initialize(){
//---------------------------------------------------------------------------

  // Inform the user what the mode and conditions are:
  MsgStream log(messageService(), name());

  // Particle properties stuff
  IPartPropSvc* p_PartPropSvc;
  static const bool CREATEIFNOTTHERE(true);
  StatusCode PartPropStatus = service("PartPropSvc", p_PartPropSvc, CREATEIFNOTTHERE);
  if(!PartPropStatus.isSuccess() ||0==p_PartPropSvc){
    log<< MSG::ERROR << "Could not initialize Particle Properties service" << endreq;
    return PartPropStatus;
  }
  

  m_particleTable=p_PartPropSvc->PDT();

  // make sure that storegate there
  StatusCode sc = service("StoreGateSvc", m_sgSvc);
  if (sc.isFailure()) {
    log << MSG::ERROR << "Could not find StoreGateSvc" << endreq;
    return sc;
  }

  // Initialize the filter itself
  m_nPass=0;
  m_nFail=0;
  StatusCode status = this->filterInitialize();
  return status;
}

//---------------------------------------------------------------------------
StatusCode GenFilter::execute() {
//---------------------------------------------------------------------------

  StatusCode status;

  MsgStream log(messageService(), name());

  log << MSG::DEBUG << "GenFilter::execute()" << endreq;

  // retrieve event from Transient Store (Storegate)

  std::string   key = "GEN_EVENT";
  if ( m_sgSvc->retrieve(m_cCollptr, key).isFailure() ) {
    log << MSG::ERROR << "Could not retrieve McEventCollection"
	<< endreq;
    return StatusCode::FAILURE;
  }

     // Call the code that filters an event
     status = this->filterEvent();
     // now deal with the pass/fail
     //
     if(filterPassed()){
       m_nPass++;
     }
     else{
       m_nFail++;
     }
     if(m_nPass>=m_nNeeded && m_nNeeded>0)status=StatusCode::FAILURE;
     // Bale out once we have enough events
  return status;
}

//---------------------------------------------------------------------------
StatusCode GenFilter::finalize() {
//---------------------------------------------------------------------------

  MsgStream log(messageService(), name());

  log << MSG::INFO << "GenFilter::finalize()" << endreq;
  log << MSG::INFO <<" Events passed = " << m_nPass << "    Events Failed = "<< m_nFail << endreq;

  StatusCode status = this->filterFinalize();

  return status;
}

//---------------------------------------------------------------------------
StatusCode GenFilter::filterInitialize() { 
//---------------------------------------------------------------------------
        return StatusCode::SUCCESS;
}

//---------------------------------------------------------------------------
StatusCode GenFilter::filterEvent() { 
//---------------------------------------------------------------------------
        return StatusCode::SUCCESS;
}

//---------------------------------------------------------------------------
StatusCode GenFilter::filterFinalize() { 
//---------------------------------------------------------------------------
        return StatusCode::SUCCESS;
}


