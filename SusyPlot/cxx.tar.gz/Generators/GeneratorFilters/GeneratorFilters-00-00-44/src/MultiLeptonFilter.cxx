// -------------------------------------------------------------
// File: GeneratorFilters/MultiLeptonFilter.cxx
// Description:
//   Allows the user to search for electrons or positrons
// will pass if there is an e mu or tau  with p_t and eta in the specified range
// default is p_t>10 GeV and unlimited eta.
//
// D. Costanzo private version. Added the option to count on the number
// of Leptons
//
// AuthorList:
// 
// Davide Costanzo, modified from Ian Hinchliffe LeptonFilter  
//

// Header for this module:-

#include "GeneratorFilters/MultiLeptonFilter.h"

// Framework Related Headers:-
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/AlgFactory.h"

// Other classes used by this class:-
#include <math.h>

using HepMC::GenVertex;
using HepMC::GenParticle;

//--------------------------------------------------------------------------
MultiLeptonFilter::MultiLeptonFilter(const std::string& name, 
      ISvcLocator* pSvcLocator): GenFilter(name,pSvcLocator) {
  //--------------------------------------------------------------------------    
  declareProperty("Ptcut",m_Ptmin = 10000.);  
  declareProperty("Etacut",m_EtaRange = 10.0); 
  declareProperty("NLeptons",m_NLeptons = 4); 
}

//--------------------------------------------------------------------------
 MultiLeptonFilter::~MultiLeptonFilter(){
//--------------------------------------------------------------------------

}

//---------------------------------------------------------------------------
StatusCode MultiLeptonFilter::filterInitialize() {
//---------------------------------------------------------------------------
  MsgStream log(messageService(), name());
 return StatusCode::SUCCESS;
}

//---------------------------------------------------------------------------
StatusCode MultiLeptonFilter::filterFinalize() {
//---------------------------------------------------------------------------
 return StatusCode::SUCCESS;
}


//---------------------------------------------------------------------------
StatusCode MultiLeptonFilter::filterEvent() {
//---------------------------------------------------------------------------

  MsgStream log(messageService(), name());

// Loop over all events in McEventCollection
  McEventCollection::const_iterator itr;
  int NLeptons = 0;
  for (itr = m_cCollptr->begin(); itr!=m_cCollptr->end(); ++itr) {
    // Loop over all particles in the event
    const HepMC::GenEvent* genEvt = (*itr);
    for(HepMC::GenEvent::particle_const_iterator pitr=genEvt->particles_begin();
	pitr!=genEvt->particles_end(); ++pitr )
      if( (*pitr)->status()==1 )
	// check stables only{
	{
	  if( ((*pitr)->pdg_id() == 11) || ((*pitr)->pdg_id() == -11) ){
	    if( ((*pitr)->momentum().perp() >=m_Ptmin) && 
		fabs((*pitr)->momentum().pseudoRapidity()) <=m_EtaRange){
	      NLeptons++;
	    }
	  }
	  
	  if( ((*pitr)->pdg_id() == 13) || ((*pitr)->pdg_id() == -13) ){
	    if( ((*pitr)->momentum().perp() >=m_Ptmin) && 
		fabs((*pitr)->momentum().pseudoRapidity()) <=m_EtaRange){
	      NLeptons++;
	    }
	  }
	}
//
// No Tau's!
//
  }
  log << MSG::INFO << "Found " << NLeptons << "Leptons" << endreq;
  if(NLeptons >= m_NLeptons)  {
    return StatusCode::SUCCESS;
  }
  // if we get here we have failed
  setFilterPassed(false);
  return StatusCode::SUCCESS;
}
