/***********************************************************************
File: GeneratorFilters/QCDBkgFilter.cxx

Description: Select QCD jet events that are (potential) backgrounds for
other physics. Selection criteria are 0 plus any of 1-5:
0       ptj0 > 75GeV, Meff > 300GeV
1       N >= 2 extra jets with pt > 50GeV, 0.1*Meff && ptjsum/Meff > 0.30
2       ptnu > 50GeV
3       ptmu > 10GeV && ETisol < 25GeV
4       ptj > 100GeV && 2.9 < etaj < 3.5
5       Nch <= 3 && Q <= 1 && ( pt(.05)/ptj > 0.8 && pt(.10)/ptj > 0.9 )
        && Mch < 2.5GeV && any of cuts 1-4

Author:
Frank Paige, June 2005
***********************************************************************/

#include "GeneratorFilters/QCDBkgFilter.h"
#include "GeneratorFilters/GenFilter.h"

#include "JetEvent/Jet.h"
#include "JetEvent/JetCollection.h"

#include "HepMC/GenParticle.h"
#include "HepMC/GenVertex.h"

#include "PartPropSvc/PartPropSvc.h"
#include "CLHEP/HepPDT/ParticleData.hh"
#include "CLHEP/Vector/LorentzVector.h"
#include "CLHEP/Units/SystemOfUnits.h"

#include "GaudiKernel/MsgStream.h"

#include <math.h>

using HepMC::GenVertex;
using HepMC::GenParticle;

//--------------------------------------------------------------------------
QCDBkgFilter::QCDBkgFilter(const std::string& name, 
      ISvcLocator* pSvcLocator): GenFilter(name,pSvcLocator) {

  declareProperty("JetCollectionName",m_JetCollectionName="Cone4TruthJets");

  declareProperty("ptj0Cut", m_ptj0Cut = 75*GeV );  
  declareProperty("meffCut", m_meffCut = 300*GeV); 
  declareProperty("ptjCut", m_ptjCut = 50*GeV );
  declareProperty("fracjCut", m_fracjCut = 0.1 );
  declareProperty("njsumCut", m_njsumCut = 4 );
  declareProperty("fracjsumCut", m_fracjsumCut = 0.30 );
  declareProperty("ptnuCut", m_ptnuCut = 50*GeV );
  declareProperty("fracnuCut", m_fracnuCut = 0.1 );
  declareProperty("ptmuCut", m_ptmuCut = 10*GeV );
  declareProperty("isolmuCut", m_isolmuCut = 25*GeV );
  declareProperty("ptThinJetCut", m_ptThinJetCut = 20*GeV );
  declareProperty("mThinJetCut", m_mThinJetCut = 2.5*GeV );
  declareProperty("frac05ThinJetCut", m_frac05ThinJetCut = 0.8 );
  declareProperty("frac10ThinJetCut", m_frac10ThinJetCut = 0.9 );
  declareProperty("crackEtaMin", m_crackEtaMin = 2.9 );
  declareProperty("crackEtaMax", m_crackEtaMax = 3.5 );
  declareProperty("crackPtCut", m_crackPtCut = 100*GeV );

}

//--------------------------------------------------------------------------
 QCDBkgFilter::~QCDBkgFilter()
{}

//---------------------------------------------------------------------------
StatusCode QCDBkgFilter::filterInitialize() {

  MsgStream mLog(msgSvc(), name());

  // Get the Particle Properties Service
  IPartPropSvc* p_PartPropSvc;
  static const bool CREATEIFNOTTHERE(true);
  StatusCode PartPropStatus = service("PartPropSvc", p_PartPropSvc, 
    CREATEIFNOTTHERE);
  if (!PartPropStatus.isSuccess() || 0 == p_PartPropSvc) {
    mLog << MSG::ERROR 
         << " Could not initialize Particle Properties Service" 
         << endreq;
    return PartPropStatus;
  }
  m_particleTable = p_PartPropSvc->PDT();

  return StatusCode::SUCCESS;
}

//---------------------------------------------------------------------------
StatusCode QCDBkgFilter::filterFinalize() {
  return StatusCode::SUCCESS;
}


//---------------------------------------------------------------------------
StatusCode QCDBkgFilter::filterEvent() {

  MsgStream mLog(msgSvc(), name());
  StatusCode sc = StatusCode::SUCCESS;


  // Get (truth) jet container
  // Must create this by calling Cone4TruthJet_jobOptions.py before
  // calling filter. Assume jets are sorted.
  const JetCollection* jetContainer;
  sc = m_sgSvc->retrieve(jetContainer, m_JetCollectionName);
  if(sc.isFailure()  ||  !jetContainer) {
    mLog << MSG::ERROR 
         << "no jet container found in TDS"
         << endreq; 
    return StatusCode::SUCCESS;
  }

  // Already have McEventCollection from GenFilter base class

  ////////////////////////////////
  // First make ptj0 and Meff cuts
  ////////////////////////////////

  double meff = 0;
  double ptj0 = 0;
  double pxnu = 0;
  double pynu = 0;
  double ptmu = 0;

  // Sum all jets
  meff = 0;
  JetCollection::const_iterator jitr;
  for(jitr = jetContainer->begin(); jitr != jetContainer->end(); ++jitr) {
    double ptj = (*jitr)->pt();
    if( ptj > ptj0 ) ptj0 = ptj;
    meff += ptj;
  }

  // Loop over events in McEventCollection, then particles
  // Sum neutrinos and muons
  McEventCollection::const_iterator itr;
  for (itr = m_cCollptr->begin(); itr!=m_cCollptr->end(); ++itr) {
    const HepMC::GenEvent* genEvt = (*itr);
    HepMC::GenEvent::particle_const_iterator pitr=genEvt->particles_begin();
    for(; pitr!=genEvt->particles_end(); ++pitr ) {
      if( (*pitr)->status() != 1 ) continue;
      int ida = abs( (*pitr)->pdg_id() );
      if( ida == 12 || ida == 14 || ida == 16 ) {
        pxnu += (*pitr)->momentum().px();
        pynu += (*pitr)->momentum().py();
      }
      if( ida == 13 ) {
        double pt = (*pitr)->momentum().perp();
        meff += pt;
        if( pt > ptmu ) ptmu = pt;
      }
    }
  }
  double ptnu = sqrt( pxnu*pxnu + pynu*pynu );
  meff += ptnu;

  mLog <<MSG::DEBUG <<"ptj0,meff = " <<ptj0 <<" " <<meff <<endreq;

  if( ptj0 < m_ptj0Cut || meff < m_meffCut ) {
    setFilterPassed(false);
    return StatusCode::SUCCESS;
  }

  /////////////////////////////////////////////////
  // Now make cuts to select interesting jet events
  /////////////////////////////////////////////////

  int ipass = 0;

  // Jet 3 and sum of all extra jets
  double ptj2 = 0;
  double ptjsum = 0;
  int njsum = 0;
  int njet = jetContainer->size();
  if( njet >= 3 ) {
    ptj2 = (*jetContainer)[2]->pt();
    njsum = 2;
    for(int i=2; i<njet; ++i) {
      double pt = (*jetContainer)[i]->pt();
      if( pt > m_ptjCut && pt > m_fracjCut*meff ) {
        ptjsum += pt;
        ++njsum;
      }
    }
  }
  if( njsum >= m_njsumCut && ptjsum > m_fracjsumCut*meff ) {
    ipass += 1;
    mLog <<MSG::DEBUG <<"QCDPASS 1 ptjsum = " <<ptjsum <<endreq;
  }

  // Neutrinos
  if( ptnu > m_ptnuCut && ptnu > m_fracnuCut*meff ) {
    ipass += 2;
    mLog <<MSG::DEBUG <<"QCDPASS 2 ptnu = " <<ptnu <<endreq;
  }

  // Isolated muons
  if( ptmu > m_ptmuCut ) {
    bool isolmu = false; 
    for (itr = m_cCollptr->begin(); itr!=m_cCollptr->end(); ++itr) {
      const HepMC::GenEvent* genEvt = (*itr);
      HepMC::GenEvent::particle_const_iterator pitr=genEvt->particles_begin();
      for(; pitr!=genEvt->particles_end(); ++pitr ) {
        if( (*pitr)->status() != 1 ) continue;
        if( abs((*pitr)->pdg_id()) != 13 ) continue;
        double pt = (*pitr)->momentum().perp();
        if( pt < m_ptmuCut ) continue;
        double etisol = 0;
        HepMC::GenEvent::particle_const_iterator pitr2 = 
        genEvt->particles_begin();
        for(; pitr2!=genEvt->particles_end(); ++pitr2 ) {
          if( (*pitr2)->status() != 1 ) continue;
          if( (*pitr2) == (*pitr) ) continue;
          if( (*pitr)->momentum().deltaR((*pitr2)->momentum()) < 0.3 ) {
            etisol += (*pitr2)->momentum().perp();
          }
        }
        if( etisol < m_isolmuCut ) {
          isolmu = true;
          mLog <<MSG::DEBUG <<"QCDPASS 4 muon pt,etisol = " 
               <<pt <<" " <<etisol <<endreq;
        } 
      }
    }
    if( isolmu ) ipass += 4;
  }

  bool crack = false;
  // Jets in crack region -- at least 3 jets
  for(jitr = jetContainer->begin(); jitr != jetContainer->end(); ++jitr) {
    double ptj = (*jitr)->pt();
    double etaa = fabs( (*jitr)->eta() );
    if( etaa < m_crackEtaMin || etaa > m_crackEtaMax ) continue;
    if( ptj2 > m_ptjCut && ptj > m_crackPtCut ) {
      crack = true;
      mLog <<MSG::DEBUG <<"QCDPASS 8 Crack pt,eta = " 
           <<ptj <<" " <<etaa <<endreq;
    }
  }
  if( crack ) ipass += 8;

  // Thin jets -- possible gamma/e/tau backgrounds
  // Or with any other cut

  int narrow = 0;
  for(jitr = jetContainer->begin(); jitr != jetContainer->end(); ++jitr) {
    double ptj = (*jitr)->pt();
    if( ptj < m_ptThinJetCut ) continue;
    double px05 = 0;
    double py05 = 0;
    double px10 = 0;
    double py10 = 0;
    int ncharge = 0;
    double charge = 0;
    HepLorentzVector sumch(0,0,0,0);
    for (itr = m_cCollptr->begin(); itr!=m_cCollptr->end(); ++itr) {
      const HepMC::GenEvent* genEvt = (*itr);
      HepMC::GenEvent::particle_const_iterator pitr=genEvt->particles_begin();
      for(; pitr!=genEvt->particles_end(); ++pitr ) {
        if( (*pitr)->status() != 1 ) continue;
        double dr = (*jitr)->hlv().deltaR( (*pitr)->momentum() );
        if( dr > 0.4 ) continue;
        double pt = (*pitr)->momentum().perp();
        double citr = 0;
        HepPDT::ParticleData* ap = 
        m_particleTable->particle( abs((*pitr)->pdg_id()) );
        if(ap) {
          citr = ap->charge();
          if((*pitr)->pdg_id() < 0 ) citr = -citr;
        }
        if( pt > 2*GeV && citr != 0 ) {
          ++ncharge;
          charge += citr;
          sumch += (*pitr)->momentum();
        }
        if( dr < 0.10 ) {
          px10 += (*pitr)->momentum().px();
          py10 += (*pitr)->momentum().py();
        }
        if( dr < 0.05 ) {
          px05 += (*pitr)->momentum().px();
          py05 += (*pitr)->momentum().py();
        }
      }
    }
    // Require 0 tracks, 1 track, or 3 tracks with charge 1 and mass cut
    double f05 = sqrt(px05*px05 + py05*py05) / ptj;
    double f10 = sqrt(px10*px10 + py10*py10) / ptj;
    if( ncharge <= 3 && fabs(charge) <= 1 && sumch.m() < m_mThinJetCut ) {
      if( (f05 > m_frac05ThinJetCut && f10 > m_frac10ThinJetCut) ) {
        ++narrow;
        mLog <<MSG::DEBUG <<"QCDPASS 16 ThinJet = " 
             <<ncharge <<" " <<charge <<" " <<ptj <<" " <<sumch.m() <<" " 
             <<f05 <<" " <<f10 <<endreq;
      }
    }
  }
  if( (narrow == 1 && ipass != 0) || narrow > 1 ) ipass += 16;

  // Return if any cut passed
  if( ipass != 0 ) {
    mLog <<MSG::INFO <<"ipass = " <<ipass <<endreq;
    return StatusCode::SUCCESS;
  }

  // All interesting jet cuts failed
  setFilterPassed(false);
  return StatusCode::SUCCESS;

}
