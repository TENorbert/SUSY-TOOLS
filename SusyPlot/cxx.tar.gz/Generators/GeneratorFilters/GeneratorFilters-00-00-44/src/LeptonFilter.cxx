// -------------------------------------------------------------
// File: GeneratorFilters/LeptonFilter.cxx
// Description:
//   Allows the user to search for electrons or positrons
// will pass if there is an e mu or tau  with p_t and eta in the specified range
// default is p_t>10 GeV and unlimited eta.
//
// AuthorList:
//         
// Ian Hinchliffe  Dec 2001
//

// Header for this module:-

#include "GeneratorFilters/LeptonFilter.h"

// Framework Related Headers:-
#include "GaudiKernel/MsgStream.h"


// Other classes used by this class:-
#include <math.h>

using HepMC::GenVertex;
using HepMC::GenParticle;

//--------------------------------------------------------------------------
LeptonFilter::LeptonFilter(const std::string& name, 
      ISvcLocator* pSvcLocator): GenFilter(name,pSvcLocator) {
  //--------------------------------------------------------------------------    
  declareProperty("Ptcut",m_Ptmin = 10000.);  
  declareProperty("Etacut",m_EtaRange = 10.0); 
}

//--------------------------------------------------------------------------
 LeptonFilter::~LeptonFilter(){
//--------------------------------------------------------------------------

}

//---------------------------------------------------------------------------
StatusCode LeptonFilter::filterInitialize() {
//---------------------------------------------------------------------------

 return StatusCode::SUCCESS;
}

//---------------------------------------------------------------------------
StatusCode LeptonFilter::filterFinalize() {
//---------------------------------------------------------------------------
 return StatusCode::SUCCESS;
}


//---------------------------------------------------------------------------
StatusCode LeptonFilter::filterEvent() {
//---------------------------------------------------------------------------

  MsgStream log(messageService(), name());
// Loop over all events in McEventCollection
  McEventCollection::const_iterator itr;
  for (itr = m_cCollptr->begin(); itr!=m_cCollptr->end(); ++itr) {
    // Loop over all particles in the event 
    const HepMC::GenEvent* genEvt = (*itr);
    for(HepMC::GenEvent::particle_const_iterator pitr=genEvt->particles_begin();
	pitr!=genEvt->particles_end(); ++pitr ){    
      //electrons must be stable 
      if( (*pitr)->status()==1 && ((*pitr)->pdg_id() == 11) || ((*pitr)->pdg_id() == -11) ){
	log << MSG::DEBUG << "Found electron: PT,ETA " << (*pitr)->momentum().perp() << (*pitr)->momentum().pseudoRapidity()<< endreq;
	if(  (*pitr)->status()==1 &&((*pitr)->momentum().perp() >=m_Ptmin) && 
	    fabs((*pitr)->momentum().pseudoRapidity()) <=m_EtaRange){
	  
	  return StatusCode::SUCCESS;
	}
      }
      // muons must be stable
      if(  (*pitr)->status()==1 && ((*pitr)->pdg_id() == 13) ||
	   ((*pitr)->pdg_id() == -13) ){
	  log << MSG::DEBUG << "Found Muon: PT,ETA=" << (*pitr)->momentum().perp()<< (*pitr)->momentum().pseudoRapidity()<< endreq;
	if( ((*pitr)->momentum().perp() >=m_Ptmin) && 
	    fabs((*pitr)->momentum().pseudoRapidity()) <=m_EtaRange){
	  return StatusCode::SUCCESS;
	}
      }
 
    }	
  }
  // if we get here we have failed
  setFilterPassed(false);
  return StatusCode::SUCCESS;
}
