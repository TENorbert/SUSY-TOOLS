// -------------------------------------------------------------
// File: GeneratorFilters/ParticleFilter.cxx
// Description:
//   Allows the user to search for particles with specified kinematics.
// it will pass  if there is an particle  with p_t and eta or E in the specified range
// default is p_t>10 GeV and unlimited eta.
//
// AuthorList:
//         
// Ian Hinchliffe  May 2004
//

// Header for this module:-

#include "GeneratorFilters/ParticleFilter.h"

// Framework Related Headers:-
#include "GaudiKernel/MsgStream.h"


// Other classes used by this class:-
#include <math.h>

using HepMC::GenVertex;
using HepMC::GenParticle;

//--------------------------------------------------------------------------
ParticleFilter::ParticleFilter(const std::string& name, 
      ISvcLocator* pSvcLocator): GenFilter(name,pSvcLocator) {
  //----------------------------    
  declareProperty("Ptcut",m_Ptmin = 10000.);  
  declareProperty("Etacut",m_EtaRange = 10.0); 
  declareProperty("Energycut",m_EnergyRange = 1000000.0); // 1TeV
  declareProperty("PDG",m_PDGID = 11); //pion
}

//--------------------------------------------------------------------------
 ParticleFilter::~ParticleFilter(){
//--------------------------------------------------------------------------

}

//---------------------------------------------------------------------------
StatusCode ParticleFilter::filterInitialize() {
//---------------------------------------------------------------------------

 return StatusCode::SUCCESS;
}

//---------------------------------------------------------------------------
StatusCode ParticleFilter::filterFinalize() {
//---------------------------------------------------------------------------
 return StatusCode::SUCCESS;
}


//---------------------------------------------------------------------------
StatusCode ParticleFilter::filterEvent() {
//---------------------------------------------------------------------------

// Loop over all events in McEventCollection
  McEventCollection::const_iterator itr;
  for (itr = m_cCollptr->begin(); itr!=m_cCollptr->end(); ++itr) {
    // Loop over all particles in the event
    const HepMC::GenEvent* genEvt = (*itr);
    for(HepMC::GenEvent::particle_const_iterator pitr=genEvt->particles_begin();
	pitr!=genEvt->particles_end(); ++pitr ){
      if( ((*pitr)->pdg_id() == m_PDGID) || ((*pitr)->pdg_id() == -m_PDGID) ){
	if( (*pitr)->status()==1 &&
	   ((*pitr)->momentum().perp() >=m_Ptmin) && 
	    fabs((*pitr)->momentum().pseudoRapidity()) <=m_EtaRange
	    && ((*pitr)->momentum().e() <=m_EnergyRange) ){
	  return StatusCode::SUCCESS;
	}
      }
    }	
  }
  setFilterPassed(false);
  return StatusCode::SUCCESS;
}
