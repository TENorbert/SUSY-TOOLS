//====================================================================
//  GeneratorFilters_entries.cxx
//--------------------------------------------------------------------
//
//  Package    : Generators/GeneratorFilters
//
//  Description: Declaration of the components (factory entries)
//               specified by this component library.
//
//====================================================================
#include "GeneratorFilters/ElectronFilter.h"
#include "GeneratorFilters/LeptonFilter.h"
#include "GeneratorFilters/ZtoLeptonFilter.h"
#include "GeneratorFilters/MultiLeptonFilter.h"
#include "GeneratorFilters/BSignalFilter.h"
#include "GeneratorFilters/HLTCheckFilter.h"
#include "GeneratorFilters/ATauFilter.h"
#include "GeneratorFilters/JetFilter.h"
#include "GeneratorFilters/ParticleFilter.h"
#include "GeneratorFilters/PhotonFilter.h"
#include "GeneratorFilters/QCDBkgFilter.h"

#include "GaudiKernel/DeclareFactoryEntries.h"

DECLARE_ALGORITHM_FACTORY(ElectronFilter);
DECLARE_ALGORITHM_FACTORY(LeptonFilter);
DECLARE_ALGORITHM_FACTORY(ZtoLeptonFilter);
DECLARE_ALGORITHM_FACTORY(HLTCheckFilter);
DECLARE_ALGORITHM_FACTORY(MultiLeptonFilter);
DECLARE_ALGORITHM_FACTORY(BSignalFilter);
DECLARE_ALGORITHM_FACTORY(ATauFilter);
DECLARE_ALGORITHM_FACTORY(JetFilter);
DECLARE_ALGORITHM_FACTORY(ParticleFilter);
DECLARE_ALGORITHM_FACTORY(PhotonFilter);
DECLARE_ALGORITHM_FACTORY(QCDBkgFilter);

DECLARE_FACTORY_ENTRIES(GeneratorFilters) {
    DECLARE_ALGORITHM( LeptonFilter );
    DECLARE_ALGORITHM( ZtoLeptonFilter );  
    DECLARE_ALGORITHM( HLTCheckFilter );
    DECLARE_ALGORITHM( BSignalFilter );
    DECLARE_ALGORITHM( MultiLeptonFilter );
    DECLARE_ALGORITHM( ATauFilter );
    DECLARE_ALGORITHM( JetFilter );
    DECLARE_ALGORITHM( ParticleFilter );
    DECLARE_ALGORITHM( PhotonFilter );
    DECLARE_ALGORITHM( QCDBkgFilter );
}
