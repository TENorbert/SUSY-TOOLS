// -------------------------------------------------------------
// File: GeneratorFilters/ZtoLeptonFilter.cxx
// Description:
//   Allows the user to search for Z decaying to leptons
// will pass if there is  a Z decaying to leptons and
// with p_t and eta in the specified range
// default is p_t>0 GeV and unlimited eta.
//
// AuthorList:
//         
// Ian Hinchliffe  Jan 2002
//

// Header for this module:-

#include "GeneratorFilters/ZtoLeptonFilter.h"

// Framework Related Headers:-
#include "GaudiKernel/MsgStream.h"


// Other classes used by this class:-
#include <math.h>

using HepMC::GenVertex;
using HepMC::GenParticle;

//--------------------------------------------------------------------------
ZtoLeptonFilter::ZtoLeptonFilter(const std::string& name, 
      ISvcLocator* pSvcLocator): GenFilter(name,pSvcLocator) {
  //--------------------------------------------------------------------------    
  declareProperty("Ptcut",m_Ptmin = .0);  
  declareProperty("Etacut",m_EtaRange = 10.0); 
}

//--------------------------------------------------------------------------
 ZtoLeptonFilter::~ZtoLeptonFilter(){
//--------------------------------------------------------------------------

}

//---------------------------------------------------------------------------
StatusCode ZtoLeptonFilter::filterInitialize() {
//---------------------------------------------------------------------------

 MsgStream log(messageService(), name());   
 log << MSG:: INFO << " ZtoLeponFilter INITIALISING.  \n"  << endreq;   
 return StatusCode::SUCCESS;
}

//---------------------------------------------------------------------------
StatusCode ZtoLeptonFilter::filterFinalize() {
//---------------------------------------------------------------------------
 return StatusCode::SUCCESS;
}


//---------------------------------------------------------------------------
StatusCode ZtoLeptonFilter::filterEvent() {
//---------------------------------------------------------------------------

// Loop over all events in McEventCollection 
  MsgStream log(messageService(), name());
  log << MSG:: INFO << " ZtoLeptonFilter filtering.  \n"  << endreq;  
  McEventCollection::const_iterator itr;
  for (itr = m_cCollptr->begin(); itr!=m_cCollptr->end(); ++itr) {
    // Loop over all particles in the event
    const HepMC::GenEvent* genEvt = (*itr);
    for(HepMC::GenEvent::particle_const_iterator pitr=genEvt->particles_begin();
	pitr!=genEvt->particles_end(); ++pitr ){
      if( ((*pitr)->pdg_id()) == 23 ){
	// Z children
	HepMC::GenVertex::particle_iterator firstChild =
	  (*pitr)->end_vertex()->particles_begin(HepMC::children);
	HepMC::GenVertex::particle_iterator endChild =
	  (*pitr)->end_vertex()->particles_end(HepMC::children);
	HepMC::GenVertex::particle_iterator thisChild = firstChild;
	for(; thisChild != endChild; ++thisChild){
	  if( abs((*thisChild)->pdg_id()) == 11 ||  abs((*thisChild)->pdg_id()) == 13 ||  abs((*thisChild)->pdg_id()) == 15  ){ 
	    //found Z to leptons
	    return StatusCode::SUCCESS;
	  }
	}
      }	
    }
  }
  // if we get here we have failed
  setFilterPassed(false);
  return StatusCode::SUCCESS;
}
