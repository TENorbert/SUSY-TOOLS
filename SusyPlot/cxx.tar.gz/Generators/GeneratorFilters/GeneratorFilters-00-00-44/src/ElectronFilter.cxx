// -------------------------------------------------------------
// File: GeneratorFilters/ElectronFilter.cxx
// Description:
//   Allows the user to search for electrons or positrons
// will pass if there is an electron or positron with p_t and eta in the specified range
// default os p_t>10 GeV and unlimited eta.
//
// AuthorList:
//         
// Ian Hinchliffe  Dec 2001
//

// Header for this module:-

#include "GeneratorFilters/ElectronFilter.h"

// Framework Related Headers:-
#include "GaudiKernel/MsgStream.h"


// Other classes used by this class:-
#include <math.h>

using HepMC::GenVertex;
using HepMC::GenParticle;

//--------------------------------------------------------------------------
ElectronFilter::ElectronFilter(const std::string& name, 
      ISvcLocator* pSvcLocator): GenFilter(name,pSvcLocator) {
  //----------------------------    
  declareProperty("Ptcut",m_Ptmin = 10000.);  
  declareProperty("Etacut",m_EtaRange = 10.0); 
}

//--------------------------------------------------------------------------
 ElectronFilter::~ElectronFilter(){
//--------------------------------------------------------------------------

}

//---------------------------------------------------------------------------
StatusCode ElectronFilter::filterInitialize() {
//---------------------------------------------------------------------------

 return StatusCode::SUCCESS;
}

//---------------------------------------------------------------------------
StatusCode ElectronFilter::filterFinalize() {
//---------------------------------------------------------------------------
 return StatusCode::SUCCESS;
}


//---------------------------------------------------------------------------
StatusCode ElectronFilter::filterEvent() {
//---------------------------------------------------------------------------

// Loop over all events in McEventCollection
  McEventCollection::const_iterator itr;
  for (itr = m_cCollptr->begin(); itr!=m_cCollptr->end(); ++itr) {
    // Loop over all particles in the event
    const HepMC::GenEvent* genEvt = (*itr);
    for(HepMC::GenEvent::particle_const_iterator pitr=genEvt->particles_begin();
	pitr!=genEvt->particles_end(); ++pitr ){
      if( ((*pitr)->pdg_id() == 11) || ((*pitr)->pdg_id() == -11) ){
	if( (*pitr)->status()==1 &&
	   ((*pitr)->momentum().perp() >=m_Ptmin) && 
	    fabs((*pitr)->momentum().pseudoRapidity()) <=m_EtaRange){
	  return StatusCode::SUCCESS;
	}
      }
    }	
  }
  setFilterPassed(false);
  return StatusCode::SUCCESS;
}
