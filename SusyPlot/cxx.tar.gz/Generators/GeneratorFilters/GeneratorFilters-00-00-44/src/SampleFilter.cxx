// -------------------------------------------------------------
// File: GeneratorFilters/SampleFilter.cxx
// Description:
//    This class is the base class used to specify the behavior of all
//    event generator filters and is meant to capture the common behavior
//    of these filters. 
//
// AuthorList:
//         I Hinchliffe December 2001
//

// Header for this module:-

#include <fstream>

#include "GeneratorFilters/SampleFilter.h"

// Framework Related Headers:-

#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/ISvcLocator.h"
#include "GaudiKernel/DataSvc.h"

#include "StoreGate/StoreGateSvc.h"

#include "GaudiKernel/IIncidentSvc.h"
#include "GaudiKernel/Incident.h"

// Other Packages used by this class:-

#include "CLHEP/HepPDT/TableBuilder.hh"
#include "GeneratorObjects/McEventCollection.h"

//---------------------------------------------------------------------------
SampleFilter::SampleFilter(const std::string& name, 
  ISvcLocator* pSvcLocator) : Algorithm(name, pSvcLocator)
//---------------------------------------------------------------------------
{

  HepPDT::ParticleDataTable m_particleTable("PDG Table");

}

//---------------------------------------------------------------------------
SampleFilter::~SampleFilter(){

} 
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
StatusCode SampleFilter::initialize(){
  //---------------------------------------------------------------------------

  // Inform the user what the mode and conditions are:
  MsgStream log(messageService(), name());

  
  // This is temporary....
//   HepMC::IO_PDG_ParticleDataTable pdg_io("PDGTABLE");
//   m_particleTable = *pdg_io.read_particle_data_table();
//   m_particleTable.make_antiparticles_from_particles();
  {
    // Construct table builder
    HepPDT::TableBuilder  tb(m_particleTable);
    // read the input - put as many here as you want
    const char pdgfile[] = "PDGTABLE";
    std::ifstream pdfile(pdgfile);
    if (!pdfile) std::cout << "error opening PDG file " << std::endl;
    if( !addPDGParticles( pdfile, tb ) ) { std::cout << "error reading PDG file " << std::endl; }
  }   // the tb destructor fills m_particleTable

  // make sure that storegate there
  StatusCode sc = service("StoreGateSvc", m_sgSvc);
  if (sc.isFailure()) {
    log << MSG::ERROR << "Could not find StoreGateSvc" << endreq;
    return sc;  
  }
  return sc;
}

//---------------------------------------------------------------------------
StatusCode SampleFilter::execute() {
//---------------------------------------------------------------------------

  MsgStream log(messageService(), name());

  log << MSG::DEBUG << "SampleFilter::execute()" << endreq;

  // retrieve event from Transient Store (Storegate)


  std::string	key = "GEN_EVENT";
  const McEventCollection* mcCollptr;
  if ( m_sgSvc->retrieve(mcCollptr, key).isFailure() ) {
    log << MSG::ERROR << "Could not retrieve McEventCollection"
	<< endreq;
    return StatusCode::FAILURE;
  }
  
  McEventCollection::const_iterator itr;
  GenEvent::particle_const_iterator ptcle;
  int nelectron=0;
 
  // loop over events
  for (itr = mcCollptr->begin(); itr!=mcCollptr->end(); ++itr) {
    // loop over all particles in event
    for (ptcle= (*itr)->particles_begin(); ptcle!=(*itr)->particles_end(); ++ptcle) {
      // e mu or tau      
      if (((*ptcle)->pdg_id() == 11) | ((*ptcle)->pdg_id() == 13) | ((*ptcle)->pdg_id() == 15)
	  // you must read the manual of the generator that you are using to see what you will get here. 
	  // you might want to check on the status
	  // for example (*ptcle)->status() == 1 will be true of the particle
	  // is a final state (ie. not a documentary or other 
	  //generator specific crap)
){
       nelectron++;}
}

    (*itr)->print();
  }	
  if(nelectron != 0) return StatusCode::SUCCESS;
  return StatusCode::FAILURE;
}

//---------------------------------------------------------------------------
StatusCode SampleFilter::finalize() {
//---------------------------------------------------------------------------

  return StatusCode::SUCCESS; 

}

