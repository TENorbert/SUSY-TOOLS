#include "SUSYPhysUtils/SusyRedundTool.h"
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/IToolSvc.h"
#include "SUSYPhysUtils/SusyGlobalObject.h"

#include <math.h>
#include <string>

/////////////////////////
// Constructor/destructor
/////////////////////////

SusyRedundTool::SusyRedundTool( const std::string& type,
                                const std::string& name,
                                const IInterface* parent )
  :  SusyObjectTool( type, name, parent)  
{
  // declare the interface for this tool
  declareInterface<ISusyObjectTool> (this); 

}

SusyRedundTool::~SusyRedundTool() {}

////////////////////
// Initialize method
////////////////////

StatusCode SusyRedundTool::initialize() {
  SusyObjectTool::initialize();
  IToolSvc* toolSvc;
  MsgStream mLog(msgSvc(), name());
  mLog << MSG::INFO << "Initializing SusyRedundTool " << name() << endreq;
  StatusCode sc = service("ToolSvc",toolSvc);
  if (StatusCode::SUCCESS != sc) {
    mLog << MSG::ERROR << " Can't get ToolSvc" << endreq;
  }
  if (StatusCode::FAILURE == service("StoreGateSvc", m_pSG) ) {
     mLog << MSG::ERROR << "Could not find StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  }
 return StatusCode::SUCCESS;
}

///////////////////////////////////////////////////////////////////////
// Called by the SusyPlot algorithm to read collections from the store, 
// remove redundancy and export consistent set
///////////////////////////////////////////////////////////////////////

StatusCode SusyRedundTool::takeAction(){
  
  MsgStream log(msgSvc(), name());

  // copy the bag so we can use it for output
  m_output=susy::createNewBag(m_inputCollection);

  // now open all the contents that we need.

  StatusCode sc;
  const IParticleContainer* myJets(0);
  if(m_inputCollection[susy::jet]!= "" && !m_pSG->contains<IParticleContainer>(m_output[susy::jet]))
    sc=Get(susy::jet,myJets);

  const IParticleContainer* myTaus(0);
  if(m_inputCollection[susy::tau]!= "" && !m_pSG->contains<IParticleContainer>(m_output[susy::tau]))
    sc=Get(susy::tau,myTaus);

  const IParticleContainer* myMuons(0);
  if(m_inputCollection[susy::muon]!= "" && !m_pSG->contains<IParticleContainer>(m_output[susy::muon]))  
    sc=Get(susy::muon,myMuons);

  const IParticleContainer* myElectrons(0);
  if(m_inputCollection[susy::electron]!= "" && !m_pSG->contains<IParticleContainer>(m_output[susy::electron]))
    sc=Get(susy::electron,myElectrons);
  
  const IParticleContainer* myPhotons(0);
  if(m_inputCollection[susy::photon]!= "" && !m_pSG->contains<IParticleContainer>(m_output[susy::photon]))
    sc=Get(susy::photon,myPhotons);

  //////////////////////////////////////////////////
  // Reconstructed objects
  // Copy each container, removing overlaps as we go
  //////////////////////////////////////////////////
    
  IParticleContainer* outMuons = new IParticleContainer(SG::VIEW_ELEMENTS);
  if(myMuons) {
    for (IParticleContainer::const_iterator thismuon= myMuons->begin(); 
    thismuon !=myMuons->end(); ++thismuon){
      outMuons->push_back(*thismuon);
    }
    std::string outputKey= m_output[susy::muon];
    if(StatusCode::FAILURE == m_pSG->record(outMuons,outputKey) ){
      log << MSG::ERROR 
          << "Unable to record Susy Muon Container in StoreGate as "
          << outputKey
          << endreq;
     } else {
       log << MSG::DEBUG 
           << "User container of muons recorded in StoreGate." 
           << endreq;
    }
  } else delete outMuons;

  IParticleContainer* outElectrons = new IParticleContainer(SG::VIEW_ELEMENTS);   
  if(myElectrons) {
    for (IParticleContainer::const_iterator thiselectron= myElectrons->begin(); thiselectron !=myElectrons->end(); ++thiselectron){
      outElectrons->push_back(*thiselectron);
    }
    std::string  outputKey=m_output[susy::electron];
    if(StatusCode::FAILURE == m_pSG->record(outElectrons,outputKey) ){
      log << MSG::ERROR 
          << "Unable to record Susy Electron Container in StoreGate as "
          << outputKey
          << endreq;
     } else {
      log << MSG::DEBUG 
          << "User container of electrons recorded in StoreGate." 
          << endreq;
    }
  } else delete outElectrons;
   
  IParticleContainer* outPhotons  = new IParticleContainer(SG::VIEW_ELEMENTS);
  if(myPhotons) {
    for (IParticleContainer::const_iterator thisphoton= myPhotons->begin(); 
    thisphoton !=myPhotons->end(); ++thisphoton){
      outPhotons->push_back(*thisphoton);
    }
    std::string outputKey=m_output[susy::photon];
    if(StatusCode::FAILURE == m_pSG->record(outPhotons,outputKey) ){
      log << MSG::ERROR 
          << "Unable to record Susy Photon Container in StoreGate as "
          << outputKey
          << endreq;
    } else {
      log << MSG::DEBUG 
          << "User container of Photons recorded in StoreGate." 
          << endreq;
    }
  } else delete outPhotons;

  IParticleContainer* outTaus  = new IParticleContainer(SG::VIEW_ELEMENTS);
  if(myTaus) {
    for (IParticleContainer::const_iterator thistau= myTaus->begin(); 
    thistau !=myTaus->end(); ++thistau){
      bool pass=true;
      // not an electron
      if( this->Matches( (*thistau), myElectrons, 0.2) ) pass=false;
      if(pass)outTaus->push_back(*thistau);
    }
    std::string outputKey= m_output[susy::tau];
    if(StatusCode::FAILURE == m_pSG->record(outTaus,outputKey) ){
      log << MSG::ERROR 
          << "Unable to record Susy Tau Container in StoreGate as "
          << outputKey
          << endreq;
    } else {
      log << MSG::DEBUG 
          << "User container of taus recorded in StoreGate." 
          << endreq;
    }
  } else delete outTaus;
   
  IParticleContainer* outJets  = new IParticleContainer(SG::VIEW_ELEMENTS);
  if(myJets) {
    for (IParticleContainer::const_iterator thisjet= myJets->begin(); 
    thisjet !=myJets->end(); ++thisjet){
      bool pass=true;
      if( this->Matches( (*thisjet), myElectrons, 0.2) ) pass=false;
      if( this->Matches( (*thisjet), myTaus, 0.2) ) pass=false;
      if( this->Matches( (*thisjet), myPhotons, 0.2) ) pass=false;
      if(pass)outJets->push_back(*thisjet);
    }
    std::string outputKey= m_output[susy::jet];
    if(StatusCode::FAILURE == m_pSG->record(outJets,outputKey) ){
      log << MSG::ERROR 
          << "Unable to record Susy JetContainer in StoreGate as "
          << outputKey
          << endreq;
    } else {
      log << MSG::DEBUG 
          << "User container of jets recorded in StoreGate." 
          << endreq;
    }
  } else delete outJets;

  /////////////////////////////////
  // Now do Monte Carlo objects
  // Remove any accidental overlaps
  /////////////////////////////////


  const IParticleContainer* myMCJets(0);
  if(m_inputCollection[susy::jetmc]!= "" && !m_pSG->contains<IParticleContainer>(m_output[susy::jetmc]))
    sc=Get(susy::jetmc,myMCJets);

  const IParticleContainer* myMCTaus(0);
  if(m_inputCollection[susy::taumc]!= "" && !m_pSG->contains<IParticleContainer>(m_output[susy::taumc]))
    sc=Get(susy::taumc,myMCTaus);

  const IParticleContainer* myMCMuons(0);
  if(m_inputCollection[susy::muonmc]!= "" && !m_pSG->contains<IParticleContainer>(m_output[susy::muonmc]))  
    sc=Get(susy::muonmc,myMCMuons);

  const IParticleContainer* myMCElectrons(0);
  if(m_inputCollection[susy::electronmc]!= "" && !m_pSG->contains<IParticleContainer>(m_output[susy::electronmc]))
    sc=Get(susy::electronmc,myMCElectrons);
  
  const IParticleContainer* myMCPhotons(0);
  if(m_inputCollection[susy::photonmc]!= "" && !m_pSG->contains<IParticleContainer>(m_output[susy::photonmc]))
    sc=Get(susy::photon,myMCPhotons);


  CopyMcCollection(susy::electronmc);
  CopyMcCollection(susy::muonmc);
  CopyMcCollection(susy::photonmc);

  IParticleContainer* outMCTaus  = new IParticleContainer(SG::VIEW_ELEMENTS);
  if(myMCTaus) {
    for (IParticleContainer::const_iterator thistau= myMCTaus->begin(); 
    thistau !=myMCTaus->end(); ++thistau){
      bool pass=true;
      if( this->Matches( (*thistau), myMCElectrons, 0.2) ) pass=false;
      if(pass)outMCTaus->push_back(*thistau);
    }
    std::string outputKey= m_output[susy::taumc];
    if(StatusCode::FAILURE == m_pSG->record(outMCTaus,outputKey) ){
      log << MSG::ERROR 
          << "Unable to record Susy MC tauContainer in StoreGate as "
          << outputKey
          << endreq;
     } else {
       log << MSG::DEBUG 
           << "User container of MC taus recorded in StoreGate." 
           << endreq;
    }
  } else delete outMCTaus;
   
  IParticleContainer* outMCJets  = new IParticleContainer(SG::VIEW_ELEMENTS);
  if(myMCJets) {
    for (IParticleContainer::const_iterator thisjet= myMCJets->begin(); 
    thisjet !=myMCJets->end(); ++thisjet){
      bool pass=true;
      if( this->Matches( (*thisjet), myMCElectrons, 0.2) ) pass=false;
      if( this->Matches( (*thisjet), myMCTaus, 0.2) ) pass=false;
      if( this->Matches( (*thisjet), myMCPhotons, 0.2) ) pass=false;
      if(pass)outMCJets->push_back(*thisjet);
    }
    std::string outputKey= m_output[susy::jetmc];
    if(StatusCode::FAILURE == m_pSG->record(outMCJets,outputKey) ){
      log << MSG::ERROR 
          << "Unable to record Susy MC JetContainer in StoreGate as "
          << outputKey
          << endreq;
    } else {
      log << MSG::DEBUG 
          << "User container of MC jets recorded in StoreGate." 
          << endreq;
    }
  } else delete outMCJets;

  ////////////////////////
  // Global reco and MC
  // These are just copies
  ////////////////////////

  const SusyGlobalObject* myEtmiss(0);
  if(m_inputCollection[susy::global]!= "" && 
  !m_pSG->contains<SusyGlobalObject>(m_output[susy::global])) {
    sc=m_pSG->retrieve(myEtmiss,  m_inputCollection[susy::global]);
    if( sc.isFailure()  || !myEtmiss ) {
      log << MSG::WARNING
          << "No Global object found in TDS"
          << endreq; 
       return StatusCode::FAILURE;
    }
  }
  if(myEtmiss) {
    SusyGlobalObject* myEtmissout = new SusyGlobalObject(*myEtmiss);
    sc=m_pSG->record(myEtmissout, m_output[susy::global]);
  }

  const SusyGlobalObject* myEtmissmc(0);
  log << MSG::DEBUG << "Global names = "
      << m_inputCollection[susy::globalmc] <<" "
      << m_output[susy::globalmc]
      << endreq;
  if(m_inputCollection[susy::globalmc]!= "" && 
  !m_pSG->contains<SusyGlobalObject>(m_output[susy::globalmc])) {
    sc=m_pSG->retrieve(myEtmissmc,  m_inputCollection[susy::globalmc]);
    log << MSG::DEBUG << "myEtmissmc = " << myEtmissmc << endreq;
    if( sc.isFailure()  || !myEtmissmc ) {
      log << MSG::WARNING
          << "No Global MC object found in TDS"
          << endreq; 
      return StatusCode::FAILURE;
    }  
  }
  if(myEtmissmc) {
    SusyGlobalObject* myEtmissmcout = new SusyGlobalObject(*myEtmissmc);
    sc=m_pSG->record(myEtmissmcout,  m_output[susy::globalmc]);
  }
   
  return StatusCode::SUCCESS;
}


/////////////////////////
// SusyRedundTool methods
/////////////////////////

bool SusyRedundTool::Matches(IParticle* part, const IParticleContainer* cont,
 double r){

  if( !cont ) return false;
  if( cont->size() == 0 ) return false;
 
  int index = -1;
  double deltaRMatch;
  int pdgId = 0;
  bool findAMatch = m_pAnalysisTools->matchR(part, cont,
                                               index, deltaRMatch,pdgId);
  if( findAMatch ) {
    return (deltaRMatch < r);
  }

  return false;

}

// Used to copy the Mc collection and give them a different name
// so the same tag as the data collections is used

StatusCode SusyRedundTool::CopyMcCollection(const susy::SusyTypes myType) {
  
  MsgStream log(msgSvc(), name());
  const IParticleContainer* myMcColl(0);

  if(m_inputCollection[myType]!= "" && 
  !m_pSG->contains<IParticleContainer>(m_output[myType])) {
    if(StatusCode::FAILURE == Get(myType,myMcColl)) {
      log << MSG::ERROR 
          << "Unable to retrieve Susy MC Container in StoreGate as "        
          << m_inputCollection[myType] << endreq;
      return StatusCode::FAILURE;
    };
     
    IParticleContainer* outMC  = new IParticleContainer(SG::VIEW_ELEMENTS); 
    for (IParticleContainer::const_iterator itobj= myMcColl->begin(); 
    itobj != myMcColl->end(); ++itobj)
      outMC->push_back(*itobj);
    
    if(StatusCode::FAILURE == m_pSG->record(outMC,m_output[myType]) ){
      log << MSG::ERROR 
          << "Unable to record IParticleContainer in StoreGate as "    
          << m_output[myType] << endreq;
    } else
      log << MSG::DEBUG 
          << "User IParticleContainer recorded in StoreGate with key" 
          << m_output[myType] << endreq;
  }  
  return StatusCode::SUCCESS;
}

      
     
