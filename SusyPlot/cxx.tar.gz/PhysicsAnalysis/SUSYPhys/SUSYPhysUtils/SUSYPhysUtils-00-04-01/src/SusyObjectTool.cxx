#include "SUSYPhysUtils/SusyObjectTool.h"
#include "SUSYPhysUtils/SusyGlobalObject.h"
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/Algorithm.h"
//
SusyObjectTool::SusyObjectTool(  const std::string& type,
				 const std::string& name,
				 const IInterface* parent )
  :  AlgTool( type, name, parent),
     m_pAnalysisTools(0)
{
  const Algorithm* theAlg = dynamic_cast< const Algorithm* >(parent);
  m_foldername= theAlg->name(); 
  m_HistSvc=theAlg->histoSvc();
  m_ntupleSvc=theAlg->ntupleSvc();

  declareProperty("PrefixName", m_prefix = "");

}


SusyObjectTool::~SusyObjectTool() {}

StatusCode SusyObjectTool::initialize() { 
 MsgStream log(msgSvc(), name());
  log << MSG::INFO << "Initialize storegate " << name() << endreq;
  // Get a SG pointer:
  if (StatusCode::FAILURE == service("StoreGateSvc", m_pSG) ) {
     log << MSG::ERROR << "Could not find StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  } 
  // create the tool service
  IToolSvc* myTools;
  StatusCode sc=service("ToolSvc",myTools);
  if ( sc.isFailure() ) {
    log << MSG::FATAL	<< "Tool Service not found"	<< endreq;
    return StatusCode::FAILURE;
  }
  // retrieve the IAnalysisTools
  IAlgTool *tmp_analysisTools(0);
  StatusCode sCode = myTools->retrieveTool("AnalysisTools",tmp_analysisTools);
  if ( sCode.isFailure() ){    // tool not found
    log << MSG::FATAL << "Cannot find IAnalysiTools " << endreq;
    return StatusCode::FAILURE;
  } else {
    log << MSG::INFO << "found IAnalysisTools" << endreq;
  }
  m_pAnalysisTools=dynamic_cast<IAnalysisTools *>(tmp_analysisTools);

  return StatusCode::SUCCESS;
}

StatusCode SusyObjectTool::finalize() {
  return StatusCode::SUCCESS;
}

void  SusyObjectTool::Set(const SusyBag localbag) {
  m_inputCollection =localbag;
}

void  SusyObjectTool::SetOrg(const SusyBag orgbag) {
  m_inputOrg =orgbag;
}

StatusCode  SusyObjectTool::Get(const susy::SusyTypes myType, const IParticleContainer* &susyContainer){
 MsgStream log(msgSvc(), name());
 bool keyOK=false;
 bool keyOrgOK=false;

 if(m_inputCollection.count(myType) == 1) {
   log << MSG::DEBUG << "Retrieving collection: " << m_inputCollection[myType] << endreq;
   StatusCode sc=m_pSG->retrieve( susyContainer, m_inputCollection[myType]);
   if( sc.isFailure() ) {
     keyOK = false;
     log << MSG::WARNING << "No Susy container found in TDS with Key: "  << m_inputCollection[myType] << endreq; 
     log << MSG::WARNING << "Will try original key" << endreq;
   } else {
     keyOK = true;
   }
 }
 if (!keyOK) {
   if (m_inputOrg.count(myType) == 1) {
     keyOK = false;
     log << MSG::INFO << "Retrieving ORIGINAL collection: " << m_inputOrg[myType] << endreq;
     StatusCode sc=m_pSG->retrieve( susyContainer, m_inputOrg[myType]);
     if( sc.isFailure() ) {
       keyOrgOK = false;
     } else {
       keyOrgOK = true;
     }   
   }
 }
 if (!(keyOK || keyOrgOK)) {
   log << MSG::FATAL << "Key " << myType <<  " does not exist"  << endreq; 
   return StatusCode::FAILURE;
 }  
 return StatusCode::SUCCESS;  
}

StatusCode  SusyObjectTool::GetGlobal(const susy::SusyTypes myType, const SusyGlobalObject* &susyGlobal){
 MsgStream log(msgSvc(), name());
 bool keyOK=false;
 bool keyOrgOK=false;

 if(m_inputCollection.count(myType) == 1) {
   log << MSG::DEBUG << "Retrieving collection: " << m_inputCollection[myType] << endreq;
   StatusCode sc=m_pSG->retrieve( susyGlobal, m_inputCollection[myType]);
   if( sc.isFailure() ) {
     keyOK = false;
     log << MSG::WARNING << "No Susy container found in TDS with Key: "  << m_inputCollection[myType] << endreq; 
     log << MSG::WARNING << "Will try original key" << endreq;
   } else {
     keyOK = true;
   }
 }
 if (!keyOK) {
   if (m_inputOrg.count(myType) == 1) {
     keyOK = false;
     log << MSG::INFO << "Retrieving ORIGINAL collection: " << m_inputOrg[myType] << endreq;
     StatusCode sc=m_pSG->retrieve( susyGlobal, m_inputOrg[myType]);
     if( sc.isFailure() ) {
       keyOrgOK = false;
     } else {
       keyOrgOK = true;
     }
   }
 }
 if (!(keyOK || keyOrgOK)) {
   log << MSG::FATAL << "Key " << myType <<  " does not exist"  << endreq; 
   return StatusCode::FAILURE;
 }  
 return StatusCode::SUCCESS;  

}
