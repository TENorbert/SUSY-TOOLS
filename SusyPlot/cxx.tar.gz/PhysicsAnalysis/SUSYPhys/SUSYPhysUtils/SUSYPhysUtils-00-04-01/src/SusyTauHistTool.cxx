#include "SUSYPhysUtils/SusyTauHistTool.h"
#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/MsgStream.h"
#include "CLHEP/Matrix/Vector.h"


#include "Particle/TrackParticleContainer.h"
#include "Particle/TrackParticle.h"
#include "ParticleEvent/TauJet.h"
#include "ParticleEvent/TauJetContainer.h"

#include <math.h>
#include <string>

//////////////////////////////////////////////////////////////////////
SusyTauHistTool::SusyTauHistTool( const std::string& type,
                                  const std::string& name,
                                  const IInterface* parent )
  : SusyObjectTool( type, name, parent)
{
  // declare the interface for this tool
  declareInterface<ISusyObjectTool> (this); 

  declareProperty("PrefixName", m_prefix = "");
}

SusyTauHistTool::~SusyTauHistTool() {}

//////////////////////////////////////////////////////////////////////
StatusCode SusyTauHistTool::initialize() {
  SusyObjectTool::initialize();
  MsgStream log(msgSvc(), name());

  log << MSG::INFO << "Booking Histos in folder " << m_foldername << endreq;

  m_h_taun =  m_HistSvc->book(m_foldername,m_prefix+"tau_n",
    "N Tau",20,0.,20.);
  m_h_taupt1 =  m_HistSvc->book(m_foldername,m_prefix+"tau_pt1",
    "pt (leading Tau)",50,0.,250.);
  m_h_tauptall =  m_HistSvc->book(m_foldername,m_prefix+"tau_ptall",
    "pt (e)",50,0.,250.);
  m_h_tauetaall =  m_HistSvc->book(m_foldername,m_prefix+"tau_eta ",
    "eta",50,-5.,5.);
  m_h_tauMllos = m_HistSvc->book(m_foldername,m_prefix+"tau_eMllos",
    "E/p Sig",50,0.,200.);
  m_h_tauMllss = m_HistSvc->book(m_foldername,m_prefix+"tau_eMllss",
    "E/p Sig",50,0.,200.);

  return StatusCode::SUCCESS;
}


//////////////////////////////////////////////////////////////////////
StatusCode SusyTauHistTool::takeAction() {  
  MsgStream log(msgSvc(), name());
  const IParticleContainer* myTaus(0);

  StatusCode sc=Get(susy::tau,myTaus);
  if(sc == StatusCode::FAILURE){
    return StatusCode::SUCCESS;
  }

  // There is no need to retrieve the track container; the element link 
  // does so automatically.

  m_h_taun->fill((float)myTaus->size(),1.);
  if (myTaus->size() >0) {
    m_h_taupt1->fill((*(myTaus->begin()))->pt()/GeV,1.);
  }
  if (myTaus->size() >1) {
    double m12 = ((*myTaus)[0]->hlv()+(*myTaus)[1]->hlv()).m();
    // hasCharge is always 0 for taus. FIX ME
    if((*myTaus)[0]->charge()*(*myTaus)[1]->charge() < 0) {
      m_h_tauMllos->fill(m12/GeV,1.);
    } else {
      m_h_tauMllss->fill(m12/GeV,1.);
    }
  }

  for(IParticleContainer::const_iterator thisE= myTaus->begin(); 
  thisE !=myTaus->end(); ++thisE){
    m_h_tauptall->fill((*thisE)->pt()/GeV,1.);
    m_h_tauetaall->fill((*thisE)->eta(),1.);

    // Get retrieves an IParticleContainer, so we have to dynamic_cast
    // to use Tau methods:
    TauJet* tau = dynamic_cast< TauJet* >(*thisE);
  }

  return StatusCode::SUCCESS;
}

