/***********************************************************************
Filename : SusyGlobalHistTool.cxx
Author   : Dan Tovey
Created  : October 2004

Tool to make histograms of Global quantities.
***********************************************************************/

#include "SUSYPhysUtils/SusyGlobalHistTool.h"
#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/MsgStream.h"
#include <math.h>
#include <string>

// To access ParticleJet methods
#include "SUSYPhysUtils/SusyGlobalObject.h"

//////////////////////////////////////////////////////////////////////
SusyGlobalHistTool::SusyGlobalHistTool( const std::string& type,
                                  const std::string& name,
                                  const IInterface* parent )
  : SusyObjectTool( type, name, parent)  
{
  // declare the interface for this tool
  declareInterface<ISusyObjectTool> (this); 

  declareProperty("PrefixName", m_prefix = "");
}


SusyGlobalHistTool::~SusyGlobalHistTool() {}


//////////////////////////////////////////////////////////////////////
// Initialize method. 

StatusCode SusyGlobalHistTool::initialize() {

  SusyObjectTool::initialize();

  MsgStream mLog(msgSvc(), name());
  mLog <<MSG::INFO <<"Initializing histograms in " <<m_foldername <<endreq;

  /// Book histograms with optional folder name
  /// WARNING: A histogram which is declared but not book will produce
  /// a segmentation violation with no useful traceback from athena.py.

  m_h_exmiss = m_HistSvc->book(m_foldername,m_prefix+"h_exmiss","ExMiss",100,-1000.0,1000.0);
  m_h_eymiss = m_HistSvc->book(m_foldername,m_prefix+"h_eymiss","EyMiss",100,-1000.0,1000.0);
  m_h_etmiss = m_HistSvc->book(m_foldername,m_prefix+"h_etmiss","EtMiss",50,0.,1000.0);
  m_h_etsum = m_HistSvc->book(m_foldername,m_prefix+"h_etsum","EtSum",50,0.,2000.0);

  m_h_exmissMC = m_HistSvc->book(m_foldername,m_prefix+"h_exmissMC","ExMiss",100,-1000.0,1000.0);
  m_h_eymissMC = m_HistSvc->book(m_foldername,m_prefix+"h_eymissMC","EyMiss",100,-1000.0,1000.0);
  m_h_etmissMC = m_HistSvc->book(m_foldername,m_prefix+"h_etmissMC","EtMiss",50,0.,1000.0);
  m_h_etsumMC = m_HistSvc->book(m_foldername,m_prefix+"h_etsumMC","EtSum",50,0.,2000.0);


  m_h_dexmiss = m_HistSvc->book(m_foldername,m_prefix+"h_dexmiss","ExMiss-ExMissMC",60,-300.0,300.0);
  m_h_deymiss = m_HistSvc->book(m_foldername,m_prefix+"h_deymiss","EyMiss-EyMissMC",60,-300.0,300.0);
  m_h_detmiss = m_HistSvc->book(m_foldername,m_prefix+"h_detmiss","EtMiss-EtMissMC",60,-300.0,300.0);
  m_h_detsum = m_HistSvc->book(m_foldername,m_prefix+"h_detsum","EtSum-EtSumMC",60,-300.0,300.0);

  m_h_detmiss2D = m_HistSvc->book(m_foldername,m_prefix+"h_detmiss2D","EtMiss",10,0.0,50.0,60,-300.0,300.0);

  mLog <<MSG::INFO <<"Initializing done" <<endreq;

  return StatusCode::SUCCESS;
}


//////////////////////////////////////////////////////////////////////
// Called by the algorithm to read collections from the store and   
// makes some plots.

StatusCode SusyGlobalHistTool::takeAction() {  

  MsgStream mLog(msgSvc(), name());
  StatusCode sc;

  const SusyGlobalObject* myEtmiss;
  sc=m_pSG->retrieve(myEtmiss,  m_inputCollection[susy::global]);
  if( sc.isFailure()  ||  !myEtmiss ) 
    {
      mLog << MSG::WARNING
	   << "No Global object found in TDS"
	   << endreq; 
      return StatusCode::FAILURE;
    }  

  const SusyGlobalObject* myEtmissMC;
  sc=m_pSG->retrieve(myEtmissMC,  m_inputCollection[susy::globalmc]);
  if( sc.isFailure()  ||  !myEtmissMC ) 
    {
      mLog << MSG::WARNING
	   << "No truth Global object found in TDS"
	   << endreq; 
      return StatusCode::FAILURE;
    }  

  m_h_exmiss->fill(((myEtmiss)->pxmiss())/GeV,1.);
  m_h_eymiss->fill(((myEtmiss)->pymiss())/GeV,1.);
  m_h_etmiss->fill(((myEtmiss)->etmiss())/GeV,1.);
  m_h_etsum->fill(((myEtmiss)->etsum())/GeV,1.);

  m_h_exmissMC->fill(((myEtmissMC)->pxmiss())/GeV,1.);
  m_h_eymissMC->fill(((myEtmissMC)->pymiss())/GeV,1.);
  m_h_etmissMC->fill(((myEtmissMC)->etmiss())/GeV,1.);
  m_h_etsumMC->fill(((myEtmissMC)->etsum())/GeV,1.);

  m_h_dexmiss->fill((((myEtmiss)->pxmiss())-((myEtmissMC)->pxmiss()))/GeV,1.);
  m_h_deymiss->fill((((myEtmiss)->pymiss())-((myEtmissMC)->pymiss()))/GeV,1.);
  m_h_detmiss->fill((((myEtmiss)->etmiss())-((myEtmissMC)->etmiss()))/GeV,1.);
  m_h_detsum->fill((((myEtmiss)->etsum())-((myEtmissMC)->etsum()))/GeV,1.);
 
  double etimc = ((myEtmissMC)->etsum())/GeV;
 
  (m_h_detmiss2D)->fill(pow(etimc,0.5),(((myEtmiss)->etmiss())-((myEtmissMC)->etmiss()))/GeV,1.);

  return StatusCode::SUCCESS;
}

