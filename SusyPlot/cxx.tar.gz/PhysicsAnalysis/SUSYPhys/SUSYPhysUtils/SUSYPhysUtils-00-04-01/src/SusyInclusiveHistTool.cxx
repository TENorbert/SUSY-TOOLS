/***********************************************************************
Filename : SusyInclusiveHistTool.cxx
Author   : Frank Paige
Created  : September 2004

Tool to make histograms of jet kinematics.
***********************************************************************/

#include "SUSYPhysUtils/SusyInclusiveHistTool.h"
#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/MsgStream.h"
#include <math.h>
#include <string>

// To access ParticleJet methods
#include "ParticleEvent/ParticleJet.h"
#include "ParticleEvent/ParticleJetContainer.h"

#include "SUSYPhysUtils/SusyGlobalObject.h"

//////////////////////////////////////////////////////////////////////
SusyInclusiveHistTool::SusyInclusiveHistTool( const std::string& type,
                                  const std::string& name,
                                  const IInterface* parent )
  : SusyObjectTool( type, name, parent)  
{
  // declare the interface for this tool
  declareInterface<ISusyObjectTool> (this);

  declareProperty("GlobalObjectName", m_inputKey = "SusyGlobal");
  declareProperty("PrefixName", m_prefix = "");

  declareProperty("NJetCut", m_njet_cut = 4);
  declareProperty("JetEt1Cut", m_jetpt1_cut = 100.0*GeV);
  declareProperty("JetEt2Cut", m_jetpt2_cut = 100.0*GeV);
  declareProperty("JetEt3Cut", m_jetpt3_cut = 50.0*GeV);
  declareProperty("JetEt4Cut", m_jetpt4_cut = 50.0*GeV);
  declareProperty("EtMissCut", m_etmiss_cut = 100.0*GeV);
  declareProperty("EtMissFracCut", m_etmissfrac_cut = 0.25);
  declareProperty("MeffCut", m_meff_cut = 400.0*GeV);
  declareProperty("JetEtCut", m_jetpt_cut = 15.0*GeV);
}


SusyInclusiveHistTool::~SusyInclusiveHistTool() {}


//////////////////////////////////////////////////////////////////////
// Initialize method. 

StatusCode SusyInclusiveHistTool::initialize() {

  SusyObjectTool::initialize();

  MsgStream mLog(msgSvc(), name());
  mLog <<MSG::INFO <<"Initializing histograms in " <<m_foldername <<endreq;

  /// Book jet histograms with optional folder name
  /// WARNING: A histogram which is declared but not book will produce
  /// a segmentation violation with no useful traceback from athena.py.

  m_h_meff = m_HistSvc->book(m_foldername,m_prefix+"h_meff","Meff",20,0.,4000.*GeV);

  mLog <<MSG::INFO <<"Initializing done" <<endreq;

  return StatusCode::SUCCESS;
}


//////////////////////////////////////////////////////////////////////
// Called by the algorithm to read collections from the store and   
// makes some plots.

StatusCode SusyInclusiveHistTool::takeAction() {  

  MsgStream mLog(msgSvc(), name());
  StatusCode sc;

  const SusyGlobalObject* myEtmiss;
  sc=m_pSG->retrieve(myEtmiss, m_inputCollection[susy::global] );
  if( sc.isFailure()  ||  !myEtmiss ) 
    {
      mLog << MSG::WARNING
	   << "No missing Global object found in TDS"
	   << endreq; 
      return StatusCode::FAILURE;
    }  

  const IParticleContainer* myJets(0);
  sc=Get(susy::jet,myJets);
  if(sc == StatusCode::FAILURE){
    return StatusCode::FAILURE;
  }
  IParticleContainer::const_iterator jetItr  = (*myJets).begin();
  IParticleContainer::const_iterator jetItrE = (*myJets).end();

  /// counters
  int njet =  0;

  double meffjet = 0.0;

  for(; jetItr != jetItrE; ++jetItr) 
    {
      double ptj = (*jetItr)->pt();
      if(ptj > m_jetpt_cut) 
	{
	  ++njet;
	  meffjet += ptj;
	}
    }

  if ((njet >= m_njet_cut) 
      && ((*myJets)[0]->pt() >= m_jetpt1_cut)
      && ((*myJets)[1]->pt() >= m_jetpt2_cut)
      && ((*myJets)[2]->pt() >= m_jetpt3_cut)
      && ((*myJets)[3]->pt() >= m_jetpt4_cut)
      && ((myEtmiss)->etmiss() >= (m_etmissfrac_cut*meffjet))
      && ((myEtmiss)->etmiss() >= m_etmiss_cut)
      && (meffjet >= m_meff_cut))
    {
      m_h_meff->fill(meffjet+((myEtmiss)->etmiss()),1.);
    }

  return StatusCode::SUCCESS;
}

