#include "GaudiKernel/DeclareFactoryEntries.h"
#include "SUSYPhysUtils/SusySimpleHistTool.h"
#include "SUSYPhysUtils/SusyGlobalHistTool.h"
#include "SUSYPhysUtils/SusyInclusiveHistTool.h"
#include "SUSYPhysUtils/SusyMuonTruthHistTool.h"
#include "SUSYPhysUtils/SusyMuonHistTool.h"
#include "SUSYPhysUtils/SusySimpleSelTool.h"
#include "SUSYPhysUtils/SusyRedundTool.h"
#include "SUSYPhysUtils/SusyInclusiveSelTool.h"
#include "SUSYPhysUtils/SusyJetHistTool.h"
#include "SUSYPhysUtils/SusyTauHistTool.h"
#include "SUSYPhysUtils/SusyElectronHistTool.h"
DECLARE_TOOL_FACTORY( SusySimpleHistTool );
DECLARE_TOOL_FACTORY( SusyGlobalHistTool );
DECLARE_TOOL_FACTORY( SusyInclusiveHistTool );
DECLARE_TOOL_FACTORY( SusySimpleSelTool );
DECLARE_TOOL_FACTORY( SusyRedundTool );
DECLARE_TOOL_FACTORY( SusyInclusiveSelTool );
DECLARE_TOOL_FACTORY( SusyMuonHistTool );
DECLARE_TOOL_FACTORY( SusyMuonTruthHistTool );
DECLARE_TOOL_FACTORY( SusyElectronHistTool );
DECLARE_TOOL_FACTORY( SusyJetHistTool );
DECLARE_TOOL_FACTORY( SusyTauHistTool );

DECLARE_FACTORY_ENTRIES( SUSYPhysUtils  )
{
    DECLARE_TOOL( SusySimpleHistTool );
    DECLARE_TOOL( SusyGlobalHistTool );
    DECLARE_TOOL( SusyInclusiveHistTool );
    DECLARE_TOOL( SusyMuonHistTool );
    DECLARE_TOOL( SusyMuonTruthHistTool );
    DECLARE_TOOL( SusyElectronHistTool );
    DECLARE_TOOL( SusySimpleSelTool );
    DECLARE_TOOL( SusyRedundTool );
    DECLARE_TOOL( SusyInclusiveSelTool );  
    DECLARE_TOOL( SusyJetHistTool );
    DECLARE_TOOL( SusyTauHistTool );
};
