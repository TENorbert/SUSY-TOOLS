#include "SUSYPhysUtils/SusyGlobalObject.h"
#include "SUSYPhysUtils/SusySimpleSelTool.h"


SusySimpleSelTool::SusySimpleSelTool(  const std::string& type,
					 const std::string& name,
					 const IInterface* parent )
  :  SusyObjectTool( type, name, parent)  
{
  declareInterface<ISusyObjectTool> (this);
  // Here the properties which are specife to this hist 
  declareProperty("EtMissCut",  m_ETcut= 50.*GeV); 
  declareProperty("Jet4EtCut",  m_Jet4Etcut= 50.*GeV); 
  declareProperty("Jet2EtCut",  m_Jet2Etcut= 100.*GeV); 
}


SusySimpleSelTool::~SusySimpleSelTool() {}

// Initialize method. 
StatusCode SusySimpleSelTool::initialize() {
  SusyObjectTool::initialize();
  return StatusCode::SUCCESS;
}


// Called by the algorithm to read collections store make a selection and return pass/fail 

StatusCode SusySimpleSelTool::takeAction() {
  MsgStream mLog(msgSvc(), name());
  StatusCode sc;

  const SusyGlobalObject* myEtmiss(0);
  mLog << MSG::INFO << "Applying selection " << name()  << endreq;
  sc=m_pSG->retrieve(myEtmiss, m_inputCollection[susy::global] );
  if( sc.isFailure()  ||  !myEtmiss ) 
    {
      mLog << MSG::WARNING
	   << "No missing Global object found in TDS"
	   << endreq; 
      return StatusCode::FAILURE;
    } 
  if((myEtmiss)->etmiss() < m_ETcut) return StatusCode::FAILURE;
//
// Now apply jet selection
  const IParticleContainer* myJets(0);
  sc=Get(susy::jet,myJets);
  if(myJets->size() < 4) return StatusCode::FAILURE;
  int njet2pt(0);
  int njet4pt(0);
  for (IParticleContainer::const_iterator ij = myJets->begin(); ij != myJets->end(); ++ij) {
    if( (*ij)->pt() > m_Jet4Etcut ) njet4pt++;
    if( (*ij)->pt() > m_Jet2Etcut ) njet2pt++;
  }
  if(njet4pt < 4 || njet2pt < 2) return StatusCode::FAILURE;
  return StatusCode::SUCCESS;
}

