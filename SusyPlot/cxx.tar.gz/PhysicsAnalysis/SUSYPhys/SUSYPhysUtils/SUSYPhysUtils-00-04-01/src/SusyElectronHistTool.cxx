// Simple SUSY electron plot
// Ian Hinchliffe 
// Sept 2004

#include "SUSYPhysUtils/SusyElectronHistTool.h"
#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/MsgStream.h"
#include "CLHEP/Vector/LorentzVector.h"
#include <math.h>
#include <string>
SusyElectronHistTool::SusyElectronHistTool(  const std::string& type,
					 const std::string& name,
					 const IInterface* parent )
  :  SusyObjectTool( type, name, parent)  
{
  // declare the interface for this tool
  declareInterface<ISusyObjectTool> (this); 
  // Here the properties which are specife to this hist 
}


SusyElectronHistTool::~SusyElectronHistTool() {}

// Initialize method. 
StatusCode SusyElectronHistTool::initialize() {
  SusyObjectTool::initialize();
  MsgStream log(msgSvc(), name());
  log << MSG::INFO << "Booking Histos in folder " << m_foldername << endreq;
  m_h_electronn =  m_HistSvc->book(m_foldername,"electron_n","N electron",20,0.,20.);
  m_h_electronpt1 =  m_HistSvc->book(m_foldername,"electron_1_pt ","pt (leading electron)",50,0.,400.);
  m_h_electronetaall =  m_HistSvc->book(m_foldername,"electron_eta ","eta",50,-5.,5.);
  m_h_electronpairos= m_HistSvc->book(m_foldername,"OS_dielectrons","Mass",25,0.,200.); 
   m_h_electronpairss = m_HistSvc->book(m_foldername,"SS_dielectrons","Mass",25,0.,200.);


  return StatusCode::SUCCESS;
}


// Called by the algorithm to read collections from the store and   makes some plots.


StatusCode SusyElectronHistTool::takeAction() {  
  MsgStream log(msgSvc(), name());
  const IParticleContainer* myElectrons(0);
  StatusCode sc=Get(susy::electron,myElectrons);
  if(sc == StatusCode::FAILURE){
    return StatusCode::FAILURE;
  }
  m_h_electronn->fill((float)myElectrons->size(),1.);
  
  if (myElectrons->size() >0) m_h_electronpt1->fill((*(myElectrons->begin()))->pt()/GeV,1.);
  
  for (IParticleContainer::const_iterator thiselectron= myElectrons->begin(); thiselectron !=myElectrons->end(); ++thiselectron){
    m_h_electronetaall->fill((*thiselectron)->eta(),1.);
  }
  if(myElectrons->size() >1){
    for (IParticleContainer::const_iterator thiselectron= myElectrons->begin(); thiselectron !=myElectrons->end(); ++thiselectron){
      for (IParticleContainer::const_iterator thiselectron1= thiselectron+1; thiselectron1 !=myElectrons->end(); ++thiselectron1){
	double pair= ((*thiselectron)->hlv()+ (*thiselectron1)->hlv()).m();
	if((*thiselectron)->charge()*(*thiselectron1)->charge() >0.5){
	  m_h_electronpairss->fill(pair/GeV,1.);
	}
	else {
	  m_h_electronpairos->fill(pair/GeV,1.);
	}
      }       
    }
  }
  
   return StatusCode::SUCCESS;
}

