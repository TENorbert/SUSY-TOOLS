#include "SUSYPhysUtils/SusySimpleHistTool.h"
#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/MsgStream.h"
#include <math.h>
#include <string>
SusySimpleHistTool::SusySimpleHistTool(  const std::string& type,
					 const std::string& name,
					 const IInterface* parent )
  :  SusyObjectTool( type, name, parent)  
{
  // declare the interface for this tool
  declareInterface<ISusyObjectTool> (this); 
  // Here the properties which are specife to this hist 
}


SusySimpleHistTool::~SusySimpleHistTool() {}

// Initialize method. 
StatusCode SusySimpleHistTool::initialize() {
  SusyObjectTool::initialize();
  MsgStream log(msgSvc(), name());
  log << MSG::INFO << "Booking Histos in folder " << m_foldername << endreq;
  m_h_jetn =  m_HistSvc->book(m_foldername,"jet_n","N jet",20,0.,20.);
  m_h_jetpt1 =  m_HistSvc->book(m_foldername,"jet_1_pt ","pt (leading jet)",50,0.,1000.);
  m_h_jetetaall =  m_HistSvc->book(m_foldername,"jet_eta ","eta",50,-5.,5.);
  return StatusCode::SUCCESS;
}


// Called by the algorithm to read collections from the store and   makes some plots.


StatusCode SusySimpleHistTool::takeAction() {  
  MsgStream log(msgSvc(), name());
  const IParticleContainer* myJets(0);
  StatusCode sc=Get(susy::jet,myJets);
  if(sc == StatusCode::FAILURE){
    return StatusCode::FAILURE;
  }
  m_h_jetn->fill((float)myJets->size(),1.);

  if (myJets->size() >0) m_h_jetpt1->fill((*(myJets->begin()))->pt()/GeV,1.);

  for (IParticleContainer::const_iterator thisjet= myJets->begin(); thisjet !=myJets->end(); ++thisjet){
    m_h_jetetaall->fill((*thisjet)->eta(),1.);
  }

   return StatusCode::SUCCESS;
}

