#include "SUSYPhysUtils/SusyInclusiveSelTool.h"

SusyInclusiveSelTool::SusyInclusiveSelTool(  const std::string& type,
					 const std::string& name,
					 const IInterface* parent )
  :  SusyObjectTool( type, name, parent)  
{
  // Here the properties which are specife to this hist 
  declareProperty("nelectron",m_nelectron=0);
  declareProperty("nmuon",m_nmuon=0);
}


SusyInclusiveSelTool::~SusyInclusiveSelTool() {}

// Initialize method. 
StatusCode SusyInclusiveSelTool::initialize() {
  return StatusCode::SUCCESS;
}


// Called by the algorithm to read collections store make a selection and return pass/fail 

StatusCode SusyInclusiveSelTool::takeAction() {

  MsgStream log(msgSvc(), name());

  const IParticleContainer* myElectrons(0);
  StatusCode sc=Get(susy::electron,myElectrons);
  if(sc == StatusCode::FAILURE){
    return StatusCode::FAILURE;
  }

  const IParticleContainer* myMuons(0);
  sc=Get(susy::muon,myMuons);
  if(sc == StatusCode::FAILURE){
    return StatusCode::FAILURE;
  }

  if ((myElectrons->size() == m_nelectron) && (myMuons->size() == m_nmuon))
    {
      return StatusCode::SUCCESS;
    }
  else
    {
      return StatusCode::FAILURE;;
    } 
}

