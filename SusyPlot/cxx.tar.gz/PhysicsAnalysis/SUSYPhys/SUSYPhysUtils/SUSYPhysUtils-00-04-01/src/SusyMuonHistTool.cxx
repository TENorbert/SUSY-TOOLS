// Simple muon plots
// Ian Hinchliffe/Davide Costanzo
// Sept2004

#include "SUSYPhysUtils/SusyMuonHistTool.h"
#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/MsgStream.h"
#include "CLHEP/Vector/LorentzVector.h"
#include <math.h>
#include <string>
SusyMuonHistTool::SusyMuonHistTool(  const std::string& type,
					 const std::string& name,
					 const IInterface* parent )
  :  SusyObjectTool( type, name, parent)  
{
  // declare the interface for this tool
  declareInterface<ISusyObjectTool> (this); 
  // Here the properties which are specife to this hist 
}


SusyMuonHistTool::~SusyMuonHistTool() {}

// Initialize method. 
StatusCode SusyMuonHistTool::initialize() {
  SusyObjectTool::initialize();
  MsgStream log(msgSvc(), name());
  log << MSG::INFO << "Booking Histos in folder " << m_foldername << endreq;
  m_h_muonn =  m_HistSvc->book(m_foldername,"muon_n","N muon",20,0.,20.);
  m_h_muonpt1 =  m_HistSvc->book(m_foldername,"muon_1_pt ","pt (leading muon)",50,0.,400.);
  m_h_muonetaall =  m_HistSvc->book(m_foldername,"muon_eta ","eta",50,-5.,5.);
  m_h_muonpairos= m_HistSvc->book(m_foldername,"OS_dimuons","Mass",25,0.,200.); 
   m_h_muonpairss = m_HistSvc->book(m_foldername,"SS_dimuons","Mass",25,0.,200.);


  return StatusCode::SUCCESS;
}


// Called by the algorithm to read collections from the store and   makes some plots.


StatusCode SusyMuonHistTool::takeAction() {  
  MsgStream log(msgSvc(), name());
  const IParticleContainer* myMuons(0);
  StatusCode sc=Get(susy::muon,myMuons);
  if(sc == StatusCode::FAILURE){
    return StatusCode::FAILURE;
  }
  m_h_muonn->fill((float)myMuons->size(),1.);
  
  if (myMuons->size() >0) m_h_muonpt1->fill((*(myMuons->begin()))->pt()/GeV,1.);
  
  for (IParticleContainer::const_iterator thismuon= myMuons->begin(); thismuon !=myMuons->end(); ++thismuon){
    m_h_muonetaall->fill((*thismuon)->eta(),1.);
  }
  if(myMuons->size() >1){
    for (IParticleContainer::const_iterator thismuon= myMuons->begin(); thismuon !=myMuons->end(); ++thismuon){
      for (IParticleContainer::const_iterator thismuon1= thismuon+1; thismuon1 !=myMuons->end(); ++thismuon1){
	double pair= ((*thismuon)->hlv()+ (*thismuon1)->hlv()).m();
	if((*thismuon)->charge()*(*thismuon1)->charge() >0.5){
	  m_h_muonpairss->fill(pair/GeV,1.);
	}
	else {
	  m_h_muonpairos->fill(pair/GeV,1.);
	}
      }       
    }
  }
  
   return StatusCode::SUCCESS;
}

