/***********************************************************************
Filename : SusyMuonTruthHistTool.cxx
Author   : Frank Paige
Created  : September 2004

Tool to make histograms of Muon kinematics.
***********************************************************************/

#include "SUSYPhysUtils/SusyMuonTruthHistTool.h"

#include "Particle/TrackParticleContainer.h"
#include "Particle/TrackParticle.h"
#include "ParticleEvent/Muon.h"
#include "TrkParameters/MeasuredTrackParameters.h"
#include "TrkEventUtils/ErrorMatrix.h"
#include "TrkEventUtils/ParamDefs.h"

#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "CLHEP/Matrix/Vector.h"
#include "GaudiKernel/MsgStream.h"
#include <math.h>
#include <string>

//////////////////////////////////////////////////////////////////////
SusyMuonTruthHistTool::SusyMuonTruthHistTool( const std::string& type,
                                              const std::string& name,
                                              const IInterface* parent )
  : SusyObjectTool( type, name, parent)
{
  declareInterface<ISusyObjectTool> (this);

  declareProperty("PrefixName", m_prefix = "");
  declareProperty("MuonEtCut", m_etMuonStandardCut = 10.0*GeV);
  declareProperty("MuonMatchCone", m_maxDeltaRMatchCut = 0.1);
}

SusyMuonTruthHistTool::~SusyMuonTruthHistTool()
{}

//////////////////////////////////////////////////////////////////////
StatusCode SusyMuonTruthHistTool::initialize() 
{
  SusyObjectTool::initialize();

  MsgStream mLog(msgSvc(), name());

  mLog << MSG::INFO << "in initialize()" << endreq;

  StatusCode sc = StatusCode::SUCCESS;

  /// Book Muon histograms with optional folder name
  /// WARNING: A histogram which is declared but not book will produce
  /// a segmentation violation with no useful traceback from athena.py.

  m_h_mcmuonn = m_HistSvc->book(m_foldername,m_prefix+"mcmu_n",
    "N Muon",20,0.,20.);
  m_h_mcmuonet = m_HistSvc->book(m_foldername,m_prefix+"mcmu_et",
    "ET Muon",100,0.,250.);
  m_h_mcmuoneta = m_HistSvc->book(m_foldername,m_prefix+"mcmu_eta",
    "eta Muon10",100,0.,5.);
  m_h_mcmuonrmatch = m_HistSvc->book(m_foldername,m_prefix+"mcmu_rmatch",
    "R match",100,0,1.);
  m_h_mcmuonetres = m_HistSvc->book(m_foldername,m_prefix+"mcmu_etres",
    "ETres",100,0.,2.);
  m_h_mcmuonmllos = m_HistSvc->book(m_foldername,m_prefix+"mcmu_mllos",
    "Mll",50,0.,200.);
  m_h_mcemumllos = m_HistSvc->book(m_foldername,m_prefix+"mcemu_mllos",
    "Mll",50,0.,200.);

  return sc;
}

//////////////////////////////////////////////////////////////////////
StatusCode SusyMuonTruthHistTool::takeAction() 
{

  MsgStream mLog(msgSvc(), name());

  StatusCode sc = StatusCode::SUCCESS;

  // Get reconstructed Muons

  const IParticleContainer* myMuons(0);
  sc=Get(susy::muon, myMuons);
  if(sc == StatusCode::FAILURE || !myMuons){
    return StatusCode::FAILURE;
  }
  IParticleContainer::const_iterator MuonItr  = (*myMuons).begin();
  IParticleContainer::const_iterator MuonItrE = (*myMuons).end();

  // Get truth Muons

  const IParticleContainer* myMuonsMc(0);
  sc=Get(susy::muonmc, myMuonsMc);
  if(sc == StatusCode::FAILURE || !myMuonsMc){
    return StatusCode::FAILURE;
  }
  IParticleContainer::const_iterator MuonMcItr  = (*myMuonsMc).begin();
  IParticleContainer::const_iterator MuonMcItrE = (*myMuonsMc).end();

  const IParticleContainer* myElectronsMc(0);
  sc=Get(susy::electronmc, myElectronsMc);
  if(sc == StatusCode::FAILURE || !myElectronsMc){
    return StatusCode::FAILURE;
  }

  mLog <<MSG::DEBUG 
       <<"Input sizes = " <<myMuons->size() <<" " <<myMuonsMc->size()
       <<endreq;

  // Kinematic plots for MC Muons

  if( myMuonsMc->size() > 1 ){
    double m12 = ((*myMuonsMc)[0]->hlv()+(*myMuonsMc)[1]->hlv()).m();
    if((*myMuonsMc)[0]->charge() * (*myMuonsMc)[1]->charge() < 0) {
      m_h_mcmuonmllos->fill(m12/GeV,1.);
    }
  }

  if( myMuonsMc->size()>0 && myElectronsMc->size()>0 ){
    double m12 = ((*myMuonsMc)[0]->hlv()+(*myElectronsMc)[0]->hlv()).m();
    if((*myMuonsMc)[0]->charge() * (*myElectronsMc)[0]->charge() < 0) {
      m_h_mcemumllos->fill(m12/GeV,1.);
    }
  }

  int nMuon15 = 0;
  for(; MuonMcItr != MuonMcItrE; ++MuonMcItr) {
    double ptj = (*MuonMcItr)->pt();
    if(ptj > 15*GeV) ++nMuon15;
    m_h_mcmuonet->fill( ptj/GeV,1.);
    double etaj = (*MuonMcItr)->hlv().pseudoRapidity();
   
    double etaaj = fabs(etaj);
    if(ptj > 10*GeV) m_h_mcmuoneta->fill(etaaj,1.);
  }
  m_h_mcmuonn->fill( (double)nMuon15, 1.);

  mLog <<MSG::DEBUG <<"Done mc plots" <<endreq;

  // Iterate over reconstructed Muons

  for(; MuonItr != MuonItrE; ++MuonItr) {
    double ej = (*MuonItr)->e();
    double ptj = (*MuonItr)->pt();
    mLog << MSG::DEBUG << "ej,ptj = " <<ej <<" " <<ptj <<endreq;
    if( ptj < 10*GeV ) continue;

    // find a match to this Muon in the MC truth container
    // the index and deltaR are returned
    int index = -1;
    double deltaRMatch = 0.999;
    int pdgId = (*MuonItr)->pdgId();
    bool findAMatch = m_pAnalysisTools->matchR((*MuonItr), myMuonsMc,
                                               index, deltaRMatch,pdgId);
    if ( !findAMatch ) continue;
    deltaRMatch = (deltaRMatch > 0.999) ? 0.999 : deltaRMatch;
    if(ptj > 10*GeV) m_h_mcmuonrmatch->fill(deltaRMatch,1.);

    // Resolution plots for Muons with good match
    // Also E/p significance    

    if( deltaRMatch<m_maxDeltaRMatchCut ) {
      const IParticle*  MuonMCMatch = (*myMuonsMc)[index]; 
      double ptjmc = MuonMCMatch->pt();
      double res = ptj/ptjmc;
      mLog << MSG::DEBUG << "res = " <<res <<endreq;
      m_h_mcmuonetres->fill(res,1.);

    } // end deltaRMatch cut
  }

  mLog <<MSG::DEBUG <<"Done res plots" <<endreq;

  return sc;
}
