/***********************************************************************
Filename : MyTauTruthHistTool.cxx
Author   : Frank Paige
Created  : September 2004

Tool to make histograms of tau kinematics.
***********************************************************************/


#include "SUSYPhysUser/MyTauTruthHistTool.h"
#include "ParticleEvent/TruthParticle.h"
#include "ParticleEvent/TruthParticleContainer.h"
#include "ParticleEvent/ParticleJetContainer.h"
#include "ParticleEvent/ParticleJet.h"
#include "ParticleEvent/TauJet.h"
#include "ParticleEvent/TauJetContainer.h"

#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/MsgStream.h"
#include "HepMC/GenParticle.h"
#include "HepMC/GenVertex.h"
#include "EventInfo/EventInfo.h"
#include "EventInfo/EventID.h"
#include "CLHEP/Vector/LorentzVector.h"

#include <math.h>
#include <string>

//////////////////////////////////////////////////////////////////////
MyTauTruthHistTool::MyTauTruthHistTool( const std::string& type,
                                            const std::string& name,
                                            const IInterface* parent )
  : SusyObjectTool( type, name, parent)
{
  declareInterface<ISusyObjectTool> (this);

  declareProperty("PrefixName", m_prefix = "");
  // Also have ET cuts in SusyTauCreator
  declareProperty("TauEtCut", m_ettauStandardCut = 0*GeV);
  declareProperty("TauMatchCone", m_maxDeltaRMatchCut = 0.1);
  declareProperty("JetInputKey", m_jetInputKey = "Cone4TowerParticleJets");
  declareProperty("SpclInputKey", m_spclInputKey = "SpclMC");
}

MyTauTruthHistTool::~MyTauTruthHistTool()
{}

//////////////////////////////////////////////////////////////////////
StatusCode MyTauTruthHistTool::initialize() 
{
  SusyObjectTool::initialize();

  MsgStream mLog(msgSvc(), name());

  mLog << MSG::INFO << "in initialize()" << endreq;

  StatusCode sc = StatusCode::SUCCESS;

  /// Book Tau histograms with optional folder name
  /// WARNING: A histogram which is declared but not book will produce
  /// a segmentation violation with no useful traceback from athena.py.

  m_h_mctau_n = m_HistSvc->book(m_foldername,m_prefix+"mctau_n",
    "N tau",20,0.,20.);
  m_h_mctau_et = m_HistSvc->book(m_foldername,m_prefix+"mctau_et",
    "ET tau",50,0.,250.);
  m_h_mctau_etvis = m_HistSvc->book(m_foldername,m_prefix+"mctau_etvis",
    "ET vis",50,0.,250.);
  m_h_mctau_etvisplus = m_HistSvc->book(m_foldername,m_prefix+"mctau_etvisplus",
    "ET tau",50,0.,250.);
  m_h_mctau_etvisminus = m_HistSvc->book(m_foldername,m_prefix+"mctau_etvisminus",
    "ET tau",50,0.,250.);
  m_h_mctau_mvis = m_HistSvc->book(m_foldername,m_prefix+"mctau_mvis",
    "M vis",50,0.,2.5);
  m_h_mctau_visfrac = m_HistSvc->book(m_foldername,m_prefix+"mctau_visfrac",
    "Vis Frac",50,0.,1.);
  m_h_mctau_eta = m_HistSvc->book(m_foldername,m_prefix+"mctau_eta",
    "eta tau",50,-5.,5.);
  m_h_mctau_rmatch = m_HistSvc->book(m_foldername,m_prefix+"mctau_rmatch",
    "R match",100,0,1.);
  m_h_mctau_rmatch50 = m_HistSvc->book(m_foldername,m_prefix+"mctau_rmatch50",
    "R match",100,0,1.);
  m_h_mctau_rmatch100 = m_HistSvc->book(m_foldername,m_prefix+"mctau_rmatch100",
    "R match",100,0,1.);
  m_h_mctau_etres = m_HistSvc->book(m_foldername,m_prefix+"mctau_etres",
    "ETres",100,0.,2.);
  m_h_mctau_etresTrue = m_HistSvc->book(m_foldername,m_prefix+"mctau_etresTrue",
    "ETres",100,0.,2.);
  m_h_mctau_pcheck = m_HistSvc->book(m_foldername,m_prefix+"mctau_pcheck",
    "E check",100,0.,0.1);
  m_h_mctau_rjet = m_HistSvc->book(m_foldername,m_prefix+"mctau_rjet",
    "R jet",100,0.,1.);
  m_h_mctau_badlike = m_HistSvc->book(m_foldername,m_prefix+"mctau_badlike",
    "bad like",80,-20.,20.);
  m_h_mctau_badn = m_HistSvc->book(m_foldername,m_prefix+"mctau_badn",
    "bad n",10,0.,10.);
  m_h_mctau_badrat = m_HistSvc->book(m_foldername,m_prefix+"mctau_badrat",
    "bad rat",100,0.,2.);

  return sc;

}

//////////////////////////////////////////////////////////////////////
StatusCode MyTauTruthHistTool::takeAction() 
{

  MsgStream mLog(msgSvc(), name());

  StatusCode sc = StatusCode::SUCCESS;

  // Get reconstructed Taus

  const IParticleContainer* myTaus(0);
  sc=Get(susy::tau, myTaus);
  if(sc == StatusCode::FAILURE || !myTaus){
    return StatusCode::FAILURE;
  }
  IParticleContainer::const_iterator TauItr  = (*myTaus).begin();
  IParticleContainer::const_iterator TauItrE = (*myTaus).end();

  // Get truth Taus

  const IParticleContainer* myTausMc(0);
  sc=Get(susy::taumc, myTausMc);
  if(sc == StatusCode::FAILURE || !myTausMc){
    return StatusCode::FAILURE;
  }
  IParticleContainer::const_iterator TauMcItr  = (*myTausMc).begin();
  IParticleContainer::const_iterator TauMcItrE = (*myTausMc).end();

  // Get all jets
  const ParticleJetContainer* jetTES(0);
  sc=m_pSG->retrieve( jetTES, m_jetInputKey);
  if( sc.isFailure()  ||  !jetTES ) {
    mLog << MSG::WARNING
         << "No AOD ParticleJet container found in TDS"
         << endreq;
    return StatusCode::SUCCESS;
  }

  // Get all specials
  const TruthParticleContainer* spclTES;
  sc=m_pSG->retrieve( spclTES, m_spclInputKey);
  if( sc.isFailure()  ||  !spclTES ) {
     mLog << MSG::WARNING
          << "No AOD SpclMC container found in TDS"
          << endreq; 
     return StatusCode::SUCCESS;
  }  

  const EventInfo* eventInfo;
  sc=m_pSG->retrieve( eventInfo );
  if( sc.isFailure()  ||  !eventInfo ) {
     mLog << MSG::WARNING
          << "No EventInfo found in TDS"
          << endreq; 
     return StatusCode::SUCCESS;
  }  

  mLog <<MSG::DEBUG 
       <<"Input sizes = " <<myTaus->size() <<" " <<myTausMc->size()
       <<endreq;

  //////////////////////////////
  // Kinematic plots for MC Taus
  //////////////////////////////

  int nTau = 0;
  for(; TauMcItr != TauMcItrE; ++TauMcItr) {
    const TruthParticle* tp = dynamic_cast< const TruthParticle* >(*TauMcItr);
    if( tp==0 ) continue;
    double ej = (*TauMcItr)->e();
    double ptj = (*TauMcItr)->pt();

    const HepMC::GenParticle* tpgen = tp->getGenParticle();
    if( !tpgen ) continue;
    HepMC::GenVertex* tpvtx = tpgen->end_vertex();
    if( !tpvtx ) continue;

    // Compute visible decay of tau. Exclude leptonic decays
    HepLorentzVector pvis(0,0,0,0);
    int neutrinos = 0;
    HepLorentzVector pcheck = -(*TauMcItr)->hlv();
    HepMC::GenVertex::particle_iterator ipd = 
      tpvtx->particles_begin(HepMC::descendants);
    HepMC::GenVertex::particle_iterator ipdE = 
      tpvtx->particles_end(HepMC::descendants);
    for( ; ipd != ipdE; ++ipd ) {
      if( (*ipd)->status() != 1 || (*ipd)->barcode() > 100000 ) continue;
      pcheck += (*ipd)->momentum();
      int id = abs( (*ipd)->pdg_id() );
      if( id==12 || id==14 ) ++neutrinos;
      if( id!=12 && id!=14 && id!=16 ) {
        pvis += (*ipd)->momentum();
      }
    }
    double ptvis = pvis.perp();
    double mvis = pvis.m();
    m_h_mctau_et->fill(ptj/GeV,1.);
    m_h_mctau_etvis->fill(ptvis/GeV,1.);
    if((*TauMcItr)->charge()>0) m_h_mctau_etvisplus->fill(ptvis/GeV,1.);
    if((*TauMcItr)->charge()<0) m_h_mctau_etvisminus->fill(ptvis/GeV,1.);
    m_h_mctau_mvis->fill(mvis/GeV,1.);
    m_h_mctau_visfrac->fill(ptvis/ptj,1.);

    // Check tau decays!!
    double check = ( fabs(pcheck.e()) + fabs(pcheck.px()) +
                     fabs(pcheck.py()) + fabs(pcheck.pz()) ) / ej;
    if( check > 0.0999 ) check = 0.0999;
    m_h_mctau_pcheck->fill(check,1.);
    if( check > 3 ) {
      int run = eventInfo->event_ID()->run_number();
      int evt = eventInfo->event_ID()->event_number();
      mLog <<MSG::DEBUG <<"BADTAU run,event,barcode = "
           <<run <<" " <<evt <<" " <<tpgen->barcode()
           <<endreq;
    } 

    if(ptvis > m_ettauStandardCut) ++nTau;
    double etaj = (*TauMcItr)->hlv().pseudoRapidity();
    double etaaj = fabs(etaj);
    if(ptvis > m_ettauStandardCut) m_h_mctau_eta->fill(etaj,1.);

    mLog <<MSG::DEBUG
         <<"TAUMC pt,eta,phi,ptvis = " <<ptj <<" " <<(*TauMcItr)->eta() <<" "
         <<(*TauMcItr)->phi() <<" " <<ptvis <<endreq;

    // Check whether MC tau makes a jet
    if( ptvis > m_ettauStandardCut ) {
      int index = -1;
      double deltar = 0.999;
      int pdgId = 0;
      bool ok = m_pAnalysisTools->matchR((*TauMcItr), jetTES,
                                  index, deltar,pdgId);
      if ( !ok ) deltar = 0.999;
      deltar = (deltar > 0.999) ? 0.999 : deltar;
      m_h_mctau_rjet->fill(deltar,1.);
    }

  }
  m_h_mctau_n->fill( (double)nTau, 1.);

  mLog <<MSG::DEBUG <<"Done mc plots" <<endreq;

  //////////////////////////////////
  // Iterate over reconstructed Taus
  //////////////////////////////////

  for(; TauItr != TauItrE; ++TauItr) {
    double ej = (*TauItr)->e();
    double ptj = (*TauItr)->pt();
    double etaaj = fabs((*TauItr)->eta());
    const TauJet* thistau = dynamic_cast< const TauJet* >(*TauItr);
    if( !thistau ) {
      mLog <<MSG::ERROR
           <<"Dynamic_cast failed for " <<*TauItr <<" " <<thistau
           <<endreq;
    }

    mLog <<MSG::DEBUG
         <<"TAUREC pt,eta,phi = " <<ptj <<" " <<(*TauItr)->eta() <<" "
         <<(*TauItr)->phi() <<endreq;

    // find a match to this Tau in the MC truth container
    // the index and deltaR are returned
    int index = -1;
    double deltar = 9.999;
    int pdgId = (*TauItr)->pdgId();
    if( abs(pdgId) != 15 ) {
      mLog <<MSG::ERROR <<"Bad tau id = " <<pdgId <<endreq;
    }

    bool ok = m_pAnalysisTools->matchR((*TauItr), myTausMc,
                                index, deltar,pdgId);
    if ( !ok ) deltar = 0.999;
    deltar = (deltar > 0.999) ? 0.999 : deltar;
    if(ptj > m_ettauStandardCut) m_h_mctau_rmatch->fill(deltar,1.);
    if(ptj > 50*GeV) m_h_mctau_rmatch50->fill(deltar,1.);
    if(ptj > 100*GeV) m_h_mctau_rmatch100->fill(deltar,1.);

    // Resolution plots for Taus with good match
    if( ok && deltar < m_maxDeltaRMatchCut ) {
      const IParticle*  TauMCMatch = (*myTausMc)[index]; 
      const TruthParticle* tp = dynamic_cast<const TruthParticle*>(TauMCMatch);
      if( !tp ) continue;
      const HepMC::GenParticle* tpgen = tp->getGenParticle();
      if( !tpgen ) continue;
      HepMC::GenVertex* tpvtx = tpgen->end_vertex();
      if( !tpvtx ) continue;
      double ptvis = 0;
      int neutrinos = 0;
      HepMC::GenVertex::particle_iterator ipd = 
      tpvtx->particles_begin(HepMC::descendants);
      HepMC::GenVertex::particle_iterator ipdE = 
      tpvtx->particles_end(HepMC::descendants);
      for( ; ipd != ipdE; ++ipd ) {
        if( (*ipd)->status() != 1 || (*ipd)->barcode() > 100000 ) continue;
        int id = abs( (*ipd)->pdg_id() );
        if( id==12 || id ==14 ) ++neutrinos;
        if( id!=12 && id!=14 && id!=16 ) {
          ptvis += (*ipd)->momentum().perp();
        }
      }
      double ptjmc = TauMCMatch->pt();
      double ejmc = TauMCMatch->e();
      double res2 = ptj/ptjmc;
      m_h_mctau_etresTrue->fill(res2,1.);
      if( neutrinos == 0 ) {
        double res = ptj/ptvis;
        m_h_mctau_etres->fill(res,1.);
      }
    } else {
      // Properties of bad taus
      mLog <<MSG::DEBUG
           <<"Bad tau like,n = " <<thistau->likelihood() <<" " 
           <<thistau->numTrack() 
           <<endreq;
      m_h_mctau_badlike->fill( thistau->likelihood(),1.);
      m_h_mctau_badn->fill( (double)thistau->numTrack(),1.);
      HepLorentzVector ptrk(0,0,0,0);
      for(int i=0; i<thistau->numTrack(); ++i) {
        ptrk += thistau->track(i)->hlv();
      }
      double rat = thistau->etHad()/ptrk.perp();
      m_h_mctau_badrat->fill(rat,1.);
    }
  }

  mLog <<MSG::DEBUG <<"Done res plots" <<endreq;

  return sc;
}
