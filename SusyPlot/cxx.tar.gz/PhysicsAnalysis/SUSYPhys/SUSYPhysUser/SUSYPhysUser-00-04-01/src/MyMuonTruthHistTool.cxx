/***********************************************************************
Filename : MyMuonTruthHistTool.cxx
Author   : Frank Paige
Created  : September 2004

Tool to make histograms of Muon kinematics.
***********************************************************************/

#include "SUSYPhysUser/MyMuonTruthHistTool.h"

#include "Particle/TrackParticleContainer.h"
#include "Particle/TrackParticle.h"
#include "ParticleEvent/Muon.h"
#include "ParticleEvent/MuonContainer.h"
#include "TrkParameters/MeasuredTrackParameters.h"
#include "TrkEventUtils/ErrorMatrix.h"
#include "TrkEventUtils/ParamDefs.h"
#include "ParticleEvent/TruthParticle.h"
#include "ParticleEvent/TruthParticleContainer.h"
#include "HepMC/GenParticle.h"
#include "EventInfo/EventInfo.h"
#include "EventInfo/EventID.h"
#include "TrkTrack/FitQuality.h"

#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "CLHEP/Matrix/Vector.h"
#include "GaudiKernel/MsgStream.h"
#include <math.h>
#include <string>

//////////////////////////////////////////////////////////////////////
MyMuonTruthHistTool::MyMuonTruthHistTool( const std::string& type,
                                              const std::string& name,
                                              const IInterface* parent )
  : SusyObjectTool( type, name, parent)
{
  declareInterface<ISusyObjectTool> (this);

  declareProperty("PrefixName", m_prefix = "");
  declareProperty("MuonEtCut", m_etMuonStandardCut = 10.0*GeV);
  declareProperty("MuonMatchCone", m_maxDeltaRMatchCut = 0.1);
  declareProperty("SpclMcName", m_spclMcName = "SpclMC");
  declareProperty("MuonName", m_muonName = "MuonCollection");

}

MyMuonTruthHistTool::~MyMuonTruthHistTool()
{}

//////////////////////////////////////////////////////////////////////
StatusCode MyMuonTruthHistTool::initialize() 
{
  SusyObjectTool::initialize();

  MsgStream mLog(msgSvc(), name());

  mLog << MSG::INFO << "in initialize()" << endreq;

  StatusCode sc = StatusCode::SUCCESS;

  /// Book Muon histograms with optional folder name
  /// WARNING: A histogram which is declared but not book will produce
  /// a segmentation violation with no useful traceback from athena.py.

  m_h_mcmu_n = m_HistSvc->book(m_foldername,m_prefix+"mcmu_n",
    "N Muon",20,0.,20.);
  m_h_mcmu_pt = m_HistSvc->book(m_foldername,m_prefix+"mcmu_pt",
    "PT Muon",50,0.,250.);
  m_h_mcmu_ptplus = m_HistSvc->book(m_foldername,m_prefix+"mcmu_ptplus",
    "PT Muon",50,0.,250.);
  m_h_mcmu_ptminus = m_HistSvc->book(m_foldername,m_prefix+"mcmu_ptminus",
    "PT Muon",50,0.,250.);
  m_h_mcmu_eta = m_HistSvc->book(m_foldername,m_prefix+"mcmu_eta",
    "eta",50,0.,5.);
  m_h_mcmu_rmatch = m_HistSvc->book(m_foldername,m_prefix+"mcmu_rmatch",
    "R match",100,0,1.);
  m_h_mcmu_rmatch20 = m_HistSvc->book(m_foldername,m_prefix+"mcmu_rmatch20",
    "R match",100,0,1.);
  m_h_mcmu_rmatch50 = m_HistSvc->book(m_foldername,m_prefix+"mcmu_rmatch50",
    "R match",100,0,1.);
  m_h_mcmu_etres = m_HistSvc->book(m_foldername,m_prefix+"mcmu_etres",
    "ETres",100,0.,2.);
  m_h_mcmu_mllos = m_HistSvc->book(m_foldername,m_prefix+"mcmu_Mllos",
    "Mll",100,0.,200.);
  m_h_mcmu_mllosz = m_HistSvc->book(m_foldername,m_prefix+"mcmu_Mllosz",
    "Mll",100,0.,200.);
  m_h_mcemu_Mllos = m_HistSvc->book(m_foldername,m_prefix+"mcemu_Mllos",
    "Mll",100,0.,200.);
  m_h_mcmu_chi2 = m_HistSvc->book(m_foldername,m_prefix+"mcmu_chi2",
    "chi2",100,0.,25.);

  m_h_mcmu_ptbad = m_HistSvc->book(m_foldername,m_prefix+"mcmu_ptbad",
    "PT Muon",50,0.,250.);
  m_h_mcmu_etabad = m_HistSvc->book(m_foldername,m_prefix+"mcmu_etabad",
    "eta",50,0.,5.);
  m_h_mcmu_phibad = m_HistSvc->book(m_foldername,m_prefix+"mcmu_phibad",
    "phi",70,-3.5,3.5);
  m_h_mcmu_chi2bad = m_HistSvc->book(m_foldername,m_prefix+"mcmu_chi2bad",
    "chi2",50,0.,25.);
  m_h_mcmu_isolbad = m_HistSvc->book(m_foldername,m_prefix+"mcmu_isolbad",
    "ETisol",50,0.,25.);
  m_h_mcmu_idbad = m_HistSvc->book(m_foldername,m_prefix+"mcmu_idbad",
    "id",100,0.,100.);
  m_h_mcmu_ptrbad = m_HistSvc->book(m_foldername,m_prefix+"mcmu_ptfracbad",
    "pt/ptmu",100,0.,4.);
  m_h_mcmu_isolfracbad = m_HistSvc->book(m_foldername,m_prefix+"mcmu_isolfracbad",
    "ET isol frac",100,0.,2.);
  m_h_mcmu_isolcheckbad = m_HistSvc->book(m_foldername,m_prefix+"mcmu_isolcheckbad",
    "ET isol frac",100,0.,2.);

  m_h_mcmu_failr = m_HistSvc->book(m_foldername,m_prefix+"mcmu_failr",
    "R fail",100,0.,1.);
  m_h_mcmu_failchi2 = m_HistSvc->book(m_foldername,m_prefix+"mcmu_failchi2",
    "chi2 fail",100,0.,100.);
  m_h_mcmu_failisol = m_HistSvc->book(m_foldername,m_prefix+"mcmu_failisol",
    "Et fail",100,0.,100.);

  return sc;
}

//////////////////////////////////////////////////////////////////////
StatusCode MyMuonTruthHistTool::takeAction() 
{

  MsgStream mLog(msgSvc(), name());

  StatusCode sc = StatusCode::SUCCESS;

  ////////////////////////////////////////
  /// Special particles
  ////////////////////////////////////////

  const TruthParticleContainer* spclTES(0);
  sc=m_pSG->retrieve( spclTES, m_spclMcName);
  if( sc.isFailure()  ||  !spclTES ) {
    mLog << MSG::WARNING
         << "No AOD SpclMC container found in TDS"
         << endreq;
    return StatusCode::SUCCESS;
  }

  // Get reconstructed Muons

  const IParticleContainer* myMuons(0);
  sc=Get(susy::muon, myMuons);
  if(sc == StatusCode::FAILURE || !myMuons){
    return StatusCode::FAILURE;
  }
  IParticleContainer::const_iterator MuonItr  = (*myMuons).begin();
  IParticleContainer::const_iterator MuonItrE = (*myMuons).end();

  const MuonContainer* muonTES;
  sc=m_pSG->retrieve( muonTES, m_muonName);
  if( sc.isFailure()  ||  !muonTES ) {
     mLog << MSG::WARNING
          << "No AOD muon container found in TDS"
          << endreq;
     return StatusCode::SUCCESS;
  }

  // Get truth Muons

  const IParticleContainer* myMuonsMc(0);
  sc=Get(susy::muonmc, myMuonsMc);
  if(sc == StatusCode::FAILURE || !myMuonsMc){
    return StatusCode::FAILURE;
  }
  IParticleContainer::const_iterator MuonMcItr  = (*myMuonsMc).begin();
  IParticleContainer::const_iterator MuonMcItrB = (*myMuonsMc).begin();
  IParticleContainer::const_iterator MuonMcItrE = (*myMuonsMc).end();

  const IParticleContainer* myElectronsMc(0);
  sc=Get(susy::electronmc, myElectronsMc);
  if(sc == StatusCode::FAILURE || !myElectronsMc){
    return StatusCode::FAILURE;
  }

  mLog <<MSG::DEBUG 
       <<"Input sizes = " <<myMuons->size() <<" " <<myMuonsMc->size()
       <<endreq;

  // Get EventInfo
  const EventInfo* eventInfo;
  sc=m_pSG->retrieve( eventInfo );
  if( sc.isFailure()  ||  !eventInfo ) {
     mLog << MSG::WARNING
          << "No EventInfo found in TDS"
          << endreq; 
     return StatusCode::SUCCESS;
  }  

  // Kinematic plots for MC Muons

  if( myMuonsMc->size() > 1 ){
    double m12 = ((*myMuonsMc)[0]->hlv()+(*myMuonsMc)[1]->hlv()).m();
    if((*myMuonsMc)[0]->charge() * (*myMuonsMc)[1]->charge() < 0) {
      m_h_mcmu_mllos->fill(m12/GeV,1.);

      bool isz = false;
      for(TruthParticleContainer::const_iterator it = (*spclTES).begin();
      it != (*spclTES).end() ; ++it) {
        if((*it)->pdgId() == 23 && fabs((*it)->m()-m12)<10*MeV) isz=true;
      }
      if(isz) m_h_mcmu_mllosz->fill(m12/GeV,1.);

    }
  }

  if( myMuonsMc->size()>0 && myElectronsMc->size()>0 ){
    double m12 = ((*myMuonsMc)[0]->hlv()+(*myElectronsMc)[0]->hlv()).m();
    if((*myMuonsMc)[0]->charge() * (*myElectronsMc)[0]->charge() < 0) {
      m_h_mcemu_Mllos->fill(m12/GeV,1.);
    }
  }

  int nMuon15 = 0;
  for(; MuonMcItr != MuonMcItrE; ++MuonMcItr) {
    double ej = (*MuonMcItr)->e();
    double ptj = (*MuonMcItr)->pt();
    if(ptj > 15*GeV) ++nMuon15;
    m_h_mcmu_pt->fill(ptj/GeV,1.);
    if((*MuonMcItr)->charge()>0) m_h_mcmu_ptplus->fill(ptj/GeV,1.);
    if((*MuonMcItr)->charge()<0) m_h_mcmu_ptminus->fill(ptj/GeV,1.);

    double etaj = (*MuonMcItr)->hlv().pseudoRapidity();
    double etaaj = fabs(etaj);
    if(ptj > 10*GeV) m_h_mcmu_eta->fill(etaaj,1.);
  }
  m_h_mcmu_n->fill( (double)nMuon15, 1.);

  mLog <<MSG::DEBUG <<"Done mc plots" <<endreq;

  // Iterate over reconstructed Muons

  for(; MuonItr != MuonItrE; ++MuonItr) {
    double ej = (*MuonItr)->e();
    double ptj = (*MuonItr)->pt();
    double etaaj = fabs((*MuonItr)->eta());
    mLog << MSG::DEBUG << "ptj,etaaj = " <<ptj <<" " <<etaaj <<endreq;
    if( ptj < 10*GeV ) continue;

    // find a match to this Muon in the MC truth container
    // the index and deltaR are returned
    int index = -1;
    double deltar = 0.999;
    int pdgId = (*MuonItr)->pdgId();
    bool ok = m_pAnalysisTools->matchR((*MuonItr), myMuonsMc,
                                               index, deltar,pdgId);
    if ( !ok ) deltar = 0.999;
    deltar = (deltar > 0.999) ? 0.999 : deltar;
    mLog << MSG::DEBUG << "rmatch mumc = " <<deltar <<endreq;
    if(ptj > 10*GeV) m_h_mcmu_rmatch->fill(deltar,1.);
    if(ptj > 20*GeV) m_h_mcmu_rmatch20->fill(deltar,1.);
    if(ptj > 50*GeV) m_h_mcmu_rmatch50->fill(deltar,1.);

    // Resolution plots for Muons with good match
    // Also E/p significance    

    const Muon* muon = dynamic_cast< const Muon* >(*MuonItr);
    if( !muon ) {
      mLog <<MSG::ERROR <<"Dynamic cast failed" <<endreq;
      continue;
    }

    if( ok && deltar<m_maxDeltaRMatchCut ) {
      // Good muons
      mLog << MSG::DEBUG << "Good muon" <<endreq;
      const IParticle*  MuonMCMatch = (*myMuonsMc)[index]; 
      double ptjmc = MuonMCMatch->pt();
      double ejmc = MuonMCMatch->e();
      double res = ptj/ptjmc;
      mLog << MSG::DEBUG << "res = " <<res <<endreq;
      m_h_mcmu_etres->fill(res,1.);
      const Rec::TrackParticle* duh = 0;
      duh = muon->get_CombinedMuonTrackParticle();
      if( duh ) {
        double chi2 = duh->fitQuality()->chiSquared();
        int ndof =  duh->fitQuality()->numberDoF();
        if( ndof > 0 ) chi2 = chi2/ndof;
        m_h_mcmu_chi2->fill(chi2,1.);
      }
    } else {
      // Bad muons
      mLog << MSG::DEBUG << "Bad muon" <<endreq;
      m_h_mcmu_ptbad->fill(ptj/GeV,1.);
      m_h_mcmu_etabad->fill(etaaj,1.);
      m_h_mcmu_phibad->fill((*MuonItr)->phi(),1.);
      mLog << MSG::DEBUG << "Done bad muon kine plots" <<endreq;
      m_h_mcmu_isolbad->fill( (muon->getEtIsol())[4]/GeV ,1.);
      mLog << MSG::DEBUG << "Done bad muon isol plot" <<endreq;
      const Rec::TrackParticle* duh = 0;
      duh = muon->get_CombinedMuonTrackParticle();
      mLog << MSG::DEBUG <<"duh = " <<duh <<endreq;
      if( duh ) {
        double chi2 = duh->fitQuality()->chiSquared();
        int ndof =  duh->fitQuality()->numberDoF();
        if( ndof > 0 ) chi2 = chi2/ndof;
        mLog << MSG::DEBUG << "Bad muon chi2 = " <<chi2 <<endreq;
        m_h_mcmu_chi2bad->fill(chi2,1.);
      }
      // Match to MC?
      mLog <<MSG::DEBUG <<"Start match MC" <<endreq;
      int index = -1;
      double deltar = 0.999;
      int pdgId = 0;
      bool ok = m_pAnalysisTools->matchR((*MuonItr), spclTES,
                                          index, deltar,pdgId);
      mLog <<MSG::DEBUG <<"Match = " <<ok <<" " <<index <<endreq;
      if( !ok ) deltar = 0.999;
      if( ok && deltar<0.1 && index>-1 ) {
        const TruthParticle* MuonMatch = 
        dynamic_cast<const TruthParticle*>((*spclTES)[index]);
        mLog <<MSG::DEBUG <<"MuonMatch = " <<MuonMatch <<endreq;
        m_h_mcmu_idbad->fill( abs(MuonMatch->pdgId()) , 1.);
        m_h_mcmu_ptrbad->fill( MuonMatch->pt()/ptj, 1.);
        if(MuonMatch->getGenParticle()->status() == 1 &&
        abs(MuonMatch->pdgId())==13) {
          double rat = (MuonMatch->etIsol()>0) ? 
          (muon->getEtIsol())[4]/MuonMatch->etIsol() : 2.0;
          if( rat>1.9999 ) rat = 1.9999;
          m_h_mcmu_isolfracbad->fill(rat,1.);
        }

        // Recompute MC isolation
        TruthParticleContainer::const_iterator ip = spclTES->begin();
        TruthParticleContainer::const_iterator ipE = spclTES->end();
        double pisolx = 0;
        double pisoly = 0;
        for(; ip != ipE; ++ip) {
          if((*ip)->getGenParticle()->status() != 1 ) continue;
          if((*ip)->getGenParticle()->barcode() > 99999 ) continue;
          int ida = abs( (*ip)->pdgId() );
          if(ida == 12 || ida == 14 || ida == 16 || ida==1000022) continue;
          if(ida == 13) continue;
          if(muon->hlv().deltaR((*ip)->hlv()) > 0.45 ) continue;
          pisolx += (*ip)->px();
          pisoly += (*ip)->py();
          mLog <<MSG::DEBUG 
               <<"BADMUON isolation barcode = "          
               <<(*ip)->getGenParticle()->barcode()
               <<endreq;
        }
        double pisolt = sqrt( pisolx*pisolx + pisoly*pisoly );
        double ratchk = (pisolt>0) ? (muon->getEtIsol())[4]/pisolt : 2.0;
        if( ratchk > 1.999 ) ratchk = 1.999;
        m_h_mcmu_isolcheckbad->fill(ratchk,1.);

        mLog <<MSG::DEBUG <<"BADMUON event,pt,eta,isol,id = "
             << eventInfo->event_ID()->run_number() <<" "
             << eventInfo->event_ID()->event_number() <<"    "
             <<ptj <<" " <<MuonMatch->pt() <<"    "
             <<(*MuonItr)->eta() <<" " <<" " <<MuonMatch->eta() <<"    " 
             <<(muon->getEtIsol())[4] <<" " <<MuonMatch->etIsol() <<" "
             <<pisolt <<"    "
             <<MuonMatch->pdgId() <<" " 
             <<MuonMatch->getGenParticle()->status() <<" "
             <<MuonMatch->getGenParticle()->barcode()
             <<endreq;
      } else {
        mLog <<MSG::DEBUG 
             <<"BADMUON no match " 
             << eventInfo->event_ID()->run_number() <<" "
             << eventInfo->event_ID()->event_number() <<" "
             <<endreq;
      }
    } 
  }


  // What happens to low-pt failed muons

  for(MuonMcItr = MuonMcItrB; MuonMcItr != MuonMcItrE; ++MuonMcItr) {
    if( (*MuonMcItr)->pt() > 25*GeV ) continue;

    // First match to SUSY muons
    int index = -1;
    double deltar = 0.999;
    int pdgId = 0;
    bool ok = m_pAnalysisTools->matchR((*MuonMcItr),myMuons,
                                       index,deltar,pdgId);
    if( !ok ) deltar = 0.999;
    if( deltar < 0.1 ) continue;

    // Now match the rest to all muons
    index = -1;
    deltar = 0.999;
    pdgId = 0;
    ok = m_pAnalysisTools->matchR((*MuonMcItr),muonTES,index,deltar,pdgId);
    if( !ok ) deltar = 0.999;
    m_h_mcmu_failr->fill(deltar, 1.);
    if( deltar < 0.1 ) {
      const Muon*  MuonMatch = (*muonTES)[index];
      const Rec::TrackParticle* duh =
      MuonMatch->get_CombinedMuonTrackParticle();
      if( duh ) {
        double chi2 = duh->fitQuality()->chiSquared();
        int ndof =  duh->fitQuality()->numberDoF();
        if( ndof > 0 ) chi2 = chi2/ndof;
        m_h_mcmu_failchi2->fill(chi2,1.);
      }
      double etisol = (MuonMatch->getEtIsol())[4];
      etisol = etisol/cosh(MuonMatch->eta());
      m_h_mcmu_failisol->fill(etisol/GeV,1.);
    }
  }

  mLog <<MSG::DEBUG <<"Done res plots" <<endreq;

  return sc;
}
