/***********************************************************************
Filename : MyElectronTruthHistTool.cxx
Author   : Frank Paige
Created  : September 2004

Tool to make histograms of Electron kinematics.
***********************************************************************/

#include "SUSYPhysUser/MyElectronTruthHistTool.h"

#include "Particle/TrackParticleContainer.h"
#include "Particle/TrackParticle.h"
#include "ParticleEvent/ElectronParamDefs.h"
#include "ParticleEvent/Electron.h"
#include "ParticleEvent/ElectronContainer.h"
#include "ParticleEvent/Photon.h"
#include "ParticleEvent/PhotonContainer.h"
#include "ParticleEvent/ParticleJetContainer.h"
#include "ParticleEvent/ParticleJet.h"

#include "HepMC/GenParticle.h"

#include "TrkParameters/MeasuredTrackParameters.h"
#include "TrkEventUtils/ErrorMatrix.h"
#include "TrkEventUtils/ParamDefs.h"
#include "ParticleEvent/TruthParticle.h"
#include "ParticleEvent/TruthParticleContainer.h"
#include "EventInfo/EventInfo.h"
#include "EventInfo/EventID.h"

#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "CLHEP/Matrix/Vector.h"
#include "GaudiKernel/MsgStream.h"
#include <math.h>
#include <string>

//////////////////////////////////////////////////////////////////////
MyElectronTruthHistTool::MyElectronTruthHistTool( const std::string& type,
                                            const std::string& name,
                                            const IInterface* parent )
  : SusyObjectTool( type, name, parent)
{
  declareInterface<ISusyObjectTool> (this);

  declareProperty("PrefixName", m_prefix = "");
  declareProperty("ElectronEtCut", m_etElectronStandardCut = 15.0*GeV);
  declareProperty("ElectronMatchCone", m_maxDeltaRMatchCut = 0.1);
  declareProperty("SpclMcName", m_spclMcName = "SpclMC");
  declareProperty("electronKey",m_electronKey = "ElectronCollection");
  declareProperty("photonKey",m_photonKey = "PhotonCollection");
  declareProperty("trackKey",m_trackKey = "TrackParticleCandidate");
  declareProperty("trackKey",m_jetKey = "Cone4TowerParticleJets");

}

MyElectronTruthHistTool::~MyElectronTruthHistTool()
{}

//////////////////////////////////////////////////////////////////////
StatusCode MyElectronTruthHistTool::initialize() 
{
  SusyObjectTool::initialize();

  MsgStream mLog(msgSvc(), name());

  mLog << MSG::INFO << "in initialize()" << endreq;

  StatusCode sc = StatusCode::SUCCESS;

  /// Book Electron histograms with optional folder name
  /// WARNING: A histogram which is declared but not book will produce
  /// a segmentation violation with no useful traceback from athena.py.

  m_h_mce_n = m_HistSvc->book(m_foldername,m_prefix+"mce_n",
    "N Electron",20,0.,20.);
  m_h_mce_pt = m_HistSvc->book(m_foldername,m_prefix+"mce_pt",
    "ET Electron",50,0.,250.);
  m_h_mce_ptplus = m_HistSvc->book(m_foldername,m_prefix+"mce_ptplus",
    "ET Electron",50,0.,250.);
  m_h_mce_ptminus = m_HistSvc->book(m_foldername,m_prefix+"mce_ptminus",
    "ET Electron",50,0.,250.);
  m_h_mce_eta = m_HistSvc->book(m_foldername,m_prefix+"mce_eta",
    "eta Electron10",50,0.,5.);
  m_h_mce_eta20 = m_HistSvc->book(m_foldername,m_prefix+"mce_eta20",
    "eta Electron10",50,0.,5.);
  m_h_mce_eta50 = m_HistSvc->book(m_foldername,m_prefix+"mce_eta50",
    "eta Electron10",50,0.,5.);
  m_h_mce_rmatch = m_HistSvc->book(m_foldername,m_prefix+"mce_rmatch",
    "R match",100,0,1.);
  m_h_mce_rmatch20 = m_HistSvc->book(m_foldername,m_prefix+"mce_rmatch20",
    "R match",100,0,1.);
  m_h_mce_rmatch50 = m_HistSvc->book(m_foldername,m_prefix+"mce_rmatch50",
    "R match",100,0,1.);
  m_h_mce_rmatchTk = m_HistSvc->book(m_foldername,m_prefix+"mce_rmatchTk",
    "R match",100,0,1.);
  m_h_mce_etres = m_HistSvc->book(m_foldername,m_prefix+"mce_etres",
    "ETres",100,0.,2.);
  m_h_mce_mllos = m_HistSvc->book(m_foldername,m_prefix+"mce_Mllos",
    "Mll",100,0.,200.);
  m_h_mce_mllosz = m_HistSvc->book(m_foldername,m_prefix+"mce_Mllosz",
    "Mll",100,0.,200.);

  m_h_mce_goodemWeight = m_HistSvc->book(m_foldername,m_prefix+"mce_goodemWeight",
    "emWeight",200,0.98,1.);
  m_h_mce_goodepiNN = m_HistSvc->book(m_foldername,m_prefix+"mce_goodepiNN",
    "epi NN",100,0.8,1.);
  m_h_mce_goodeta = m_HistSvc->book(m_foldername,m_prefix+"mce_goodeta",
  "eta",50,-2.5,2.5);
  m_h_mce_goodEp = m_HistSvc->book(m_foldername,m_prefix+"mce_goodEp",
  "E/p",100,0.,2.0);
  m_h_mce_goodIsol = m_HistSvc->book(m_foldername,m_prefix+"mce_goodIsol",
  "ET(isol)",50,0.,10.);
  m_h_mce_goodetHad1 = m_HistSvc->book(m_foldername,m_prefix+"mce_goodetHad1",
  "ET(had1)",50,0.,10.);
  m_h_mce_goodEMbits = m_HistSvc->book(m_foldername,m_prefix+"mce_goodEMbits",
  "IsEM bits",20,0.,20.);

  m_h_mce_bademWeight = m_HistSvc->book(m_foldername,m_prefix+"mce_bademWeight",
    "emWeight",200,0.98,1.);
  m_h_mce_badepiNN = m_HistSvc->book(m_foldername,m_prefix+"mce_badepiNN",
    "epi NN",100,0.8,1.);
  m_h_mce_badeta = m_HistSvc->book(m_foldername,m_prefix+"mce_badeta",
  "eta",50,-2.5,2.5);
  m_h_mce_badEp = m_HistSvc->book(m_foldername,m_prefix+"mce_badEp",
  "E/p",100,0.,2.0);
  m_h_mce_badIsol = m_HistSvc->book(m_foldername,m_prefix+"mce_badIsol",
  "ET(isol)",50,0.,10.);
  m_h_mce_badetHad1 = m_HistSvc->book(m_foldername,m_prefix+"mce_badetHad1",
  "ET(had1)",50,0.,10.);
  m_h_mce_badEMbits = m_HistSvc->book(m_foldername,m_prefix+"mce_badEMbits",
  "IsEM bits",20,0.,20.);
  m_h_mce_badRtau = m_HistSvc->book(m_foldername,m_prefix+"mce_badRtau",
  "R(tau)",100,0.,1.);
  m_h_mce_badRelec = m_HistSvc->book(m_foldername,m_prefix+"mce_badRelec",
  "R(egam)",100,0.,1.);
  m_h_mce_badIsol2D = m_HistSvc->book(m_foldername,m_prefix+"mce_badIsol2D",
  "Et v Et",50,0.,50.,50,0.,50.);
  m_h_mce_badPtres = m_HistSvc->book(m_foldername,m_prefix+"mce_badPtres",
  "ET/ETMC",100,0.,2.);

  m_h_mce_goodEp200 = m_HistSvc->book(m_foldername,m_prefix+"mce_goodEp200",
  "E/p",100,0.,2.0);
  m_h_mce_goodetHad1200 = m_HistSvc->book(m_foldername,m_prefix+"mce_goodetHad1200",
  "ET(had1)",50,0.,50.);

  return sc;

}

//////////////////////////////////////////////////////////////////////
StatusCode MyElectronTruthHistTool::takeAction() {

  MsgStream mLog(msgSvc(), name());

  StatusCode sc = StatusCode::SUCCESS;

  ////////////////////////////////////////
  /// Special particles
  ////////////////////////////////////////

  const TruthParticleContainer* spclTES;
  sc=m_pSG->retrieve( spclTES, m_spclMcName);
  if( sc.isFailure()  ||  !spclTES ) {
    mLog << MSG::WARNING
         << "No AOD SpclMC container found in TDS"
         << endreq;
    return StatusCode::SUCCESS;
  }

  // Get reconstructed Electrons

  const IParticleContainer* myElectrons(0);
  sc=Get(susy::electron, myElectrons);
  if(sc == StatusCode::FAILURE || !myElectrons){
    return StatusCode::FAILURE;
  }
  IParticleContainer::const_iterator eItr  = (*myElectrons).begin();
  IParticleContainer::const_iterator eItrB = (*myElectrons).begin();
  IParticleContainer::const_iterator eItrE = (*myElectrons).end();

  // Get truth Electrons

  const IParticleContainer* myElectronsMc(0);
  sc=Get(susy::electronmc, myElectronsMc);
  if(sc == StatusCode::FAILURE || !myElectronsMc){
    return StatusCode::FAILURE;
  }
  IParticleContainer::const_iterator eMcItr  = (*myElectronsMc).begin();
  IParticleContainer::const_iterator eMcItrB = (*myElectronsMc).begin();
  IParticleContainer::const_iterator eMcItrE = (*myElectronsMc).end();

  mLog <<MSG::DEBUG
       <<"Input sizes = " <<myElectrons->size() <<" " <<myElectronsMc->size()
       <<endreq;

  // Kinematic plots for MC Electrons

  if( myElectronsMc->size() > 1 ){
    double m12 = ((*myElectronsMc)[0]->hlv()+(*myElectronsMc)[1]->hlv()).m();
    if((*myElectronsMc)[0]->charge() * (*myElectronsMc)[1]->charge() < 0) {
      m_h_mce_mllos->fill(m12/GeV,1.);

      bool isz = false;
      for(TruthParticleContainer::const_iterator it = (*spclTES).begin();
      it != (*spclTES).end() ; ++it) {
        if((*it)->pdgId() == 23 && fabs((*it)->m()-m12)<10*MeV) isz=true;
      }
      if(isz) m_h_mce_mllosz->fill(m12/GeV,1.);

    }
  }

  int nElectron15 = 0;
  for(; eMcItr != eMcItrE; ++eMcItr) {
    double ej = (*eMcItr)->e();
    double ptj = (*eMcItr)->pt();
    if(ptj > 15*GeV) ++nElectron15;
    m_h_mce_pt->fill( ptj/GeV,1.);
    if( (*eMcItr)->charge() > 0 ) m_h_mce_ptplus->fill( ptj/GeV,1.);
    if( (*eMcItr)->charge() < 0 ) m_h_mce_ptminus->fill( ptj/GeV,1.);
    double etaj = (*eMcItr)->hlv().pseudoRapidity();
    double etaaj = fabs(etaj);
    m_h_mce_eta->fill(etaaj,1.);
    if(ptj > 20*GeV) m_h_mce_eta20->fill(etaaj,1.);
    if(ptj > 50*GeV) m_h_mce_eta50->fill(etaaj,1.);
  }
  m_h_mce_n->fill( (double)nElectron15, 1.);


  ///////////////////////////////////////
  // Iterate over reconstructed Electrons
  ///////////////////////////////////////

  for(; eItr != eItrE; ++eItr) {
    double ej = (*eItr)->e();
    double ptj = (*eItr)->pt();
    double etaaj = fabs((*eItr)->eta());
    if( ptj < 10*GeV ) continue;

    // find a match to this Electron in the MC truth container
    // the index and deltaR are returned
    int index = -1;
    double deltar = 0.999;
    int pdgId = 0;
    bool ok = m_pAnalysisTools->matchR((*eItr), myElectronsMc,
                                       index, deltar,pdgId);
    if ( !ok ) deltar = 0.999;
    deltar = (deltar > 0.999) ? 0.999 : deltar;
    if(ptj>10*GeV) m_h_mce_rmatch->fill(deltar,1.);
    if(ptj>20*GeV) m_h_mce_rmatch20->fill(deltar,1.);
    if(ptj>50*GeV) m_h_mce_rmatch50->fill(deltar,1.);

    // R match to track at vertex
    const Electron* ei = dynamic_cast<const Electron*>(*eItr);
    if( ok && ei->hasTrack() ) {
      double rimc = fabs(ei->track()->phi()-(*myElectronsMc)[index]->phi());
      if(rimc>M_PI) rimc = 2*M_PI -rimc;
      double etaimc = ei->track()->eta()-(*myElectronsMc)[index]->eta();
      rimc = sqrt(rimc*rimc+etaimc*etaimc);
      if( rimc>0.0999 ) rimc = 0.999;
      m_h_mce_rmatchTk->fill(rimc,1.);
    }

    // Resolution plots for Electrons with good match

    const Electron* electron = dynamic_cast< const Electron* >(*eItr);
    if( !electron ) {
      mLog <<MSG::WARNING <<"electron dynamic_cast failed"
           <<endreq;
      continue;
    }

    if( ok && deltar < 0.1 ) {
      const IParticle*  ElectronMCMatch = (*myElectronsMc)[index]; 
      if( !ElectronMCMatch ) {
        mLog <<MSG::WARNING <<"ElectronMCMatch null pointer"
             <<endreq;
        continue;
      }
      double ptjmc = ElectronMCMatch->pt();
      double ejmc = ElectronMCMatch->e();
      double res = ptj/ptjmc;
      m_h_mce_etres->fill(res,1.);

    } // end deltar cut
  }


  ////////////////////////////////
  // Get more stuff from StoreGate
  ////////////////////////////////

  const ElectronContainer* electronTES;
  sc=m_pSG->retrieve( electronTES, m_electronKey);
  if( sc.isFailure()  ||  !electronTES ) {
     mLog << MSG::WARNING
          << "No AOD electron container found in TDS"
          << endreq;
     return StatusCode::SUCCESS;
  }

  const PhotonContainer* photonTES;
  sc=m_pSG->retrieve( photonTES, m_photonKey);
  if( sc.isFailure()  ||  !photonTES ) {
     mLog << MSG::WARNING
          << "No AOD photon container found in TDS"
          << endreq;
     return StatusCode::SUCCESS;
  }

  const Rec::TrackParticleContainer* trackTES;
  sc=m_pSG->retrieve( trackTES, m_trackKey);
  if( sc.isFailure()  ||  !trackTES ) {
     mLog << MSG::WARNING
          << "No AOD track container found in TDS"
          << endreq;
     return StatusCode::SUCCESS;
  }

  const ParticleJetContainer* jetTES;
  sc=m_pSG->retrieve( jetTES, m_jetKey);
  if( sc.isFailure()  ||  !jetTES ) {
     mLog << MSG::WARNING
          << "No AOD ParticleJet container found in TDS with name "
          << m_jetKey
          << endreq; 
     return StatusCode::SUCCESS;
  }  

  const EventInfo* eventInfo;
  sc=m_pSG->retrieve( eventInfo );
  if( sc.isFailure()  ||  !eventInfo ) {
     mLog << MSG::WARNING
          << "No EventInfo found in TDS"
          << endreq; 
     return StatusCode::SUCCESS;
  }  

  /////////////////////////////////
  // Compare good and bad electrons
  /////////////////////////////////

  for(eItr=eItrB; eItr!=eItrE; ++eItr) {
    const Electron* elec = dynamic_cast<const Electron*>( *eItr );
    if( !elec) {
      mLog <<MSG::WARNING <<"Electron cast failed" <<endreq;
      continue;
    }

    // Find MC match
    int index = -1;
    double deltar = 0.999;
    int pdgId = 0;
    bool ok = m_pAnalysisTools->matchR(*eItr, myElectronsMc,
                                        index, deltar, pdgId);
    if( !ok ) deltar = 0.999;
    if( deltar > 0.999 ) deltar = 0.999;

    double emWeight = elec->parameter(ElectronParameters::emWeight);
    double piWeight = elec->parameter(ElectronParameters::pionWeight);
    double epiNN = elec->parameter(ElectronParameters::epiNN);
    emWeight = (emWeight+piWeight>0) ? emWeight/(emWeight+piWeight) :
    emWeight;
    double eta = elec->eta();
    double eoverp = elec->parameter(ElectronParameters::EoverP);
    if( eoverp > 3.999 ) eoverp = 3.999;
    double etisol = elec->parameter(ElectronParameters::etcone);
    double ethad1 = elec->parameter(ElectronParameters::ethad1);

    if( deltar < 0.1 ) { // good electron
      m_h_mce_goodemWeight->fill(emWeight,1.);
      m_h_mce_goodepiNN->fill(epiNN,1.);
      m_h_mce_goodeta->fill(eta,1.);
      m_h_mce_goodEp->fill(eoverp,1.);
      m_h_mce_goodIsol->fill(etisol/GeV,1.);
      m_h_mce_goodetHad1->fill(ethad1/GeV,1.);

      if( (*eItr)->pt() > 200*GeV ) {
        m_h_mce_goodEp200->fill(eoverp,1.);
        m_h_mce_goodetHad1200->fill(ethad1/GeV,1.);
      }

      int isem = elec->isEM();
      if( isem == 0 ) {
        m_h_mce_goodEMbits->fill(0,1.);
      } else {
        int isemcal = 0;
        int isemtrk = 0;
        for(int i=1;i<16;++i) {
          if(isem%2==1) {
            m_h_mce_goodEMbits->fill((double)i,1.);
            if(i<5) ++isemcal;
            if(i>8 && i<12) ++isemtrk;
          }
          isem/=2;
        }
        if(isemcal!=0) m_h_mce_goodEMbits->fill((double)6,1.);
        if(isemtrk!=0) m_h_mce_goodEMbits->fill((double)14,1.);
      }

    } else { // bad electron
      m_h_mce_bademWeight->fill(emWeight,1.);
      m_h_mce_badepiNN->fill(epiNN,1.);
      m_h_mce_badeta->fill(eta,1.);
      m_h_mce_badEp->fill(eoverp,1.);
      m_h_mce_badIsol->fill(etisol/GeV,1.);
      m_h_mce_badetHad1->fill(ethad1/GeV,1.);

      int isem = elec->isEM();
      if( isem == 0 ) {
        m_h_mce_badEMbits->fill(0,1.);
      } else {
        int isemcal = 0;
        int isemtrk = 0;
        for(int i=1;i<16;++i) {
          if(isem%2==1) {
            m_h_mce_badEMbits->fill((double)i,1.);
            if(i<5) ++isemcal;
            if(i>8 && i<12) ++isemtrk;
          }
          isem/=2;
        }
        if(isemcal!=0) m_h_mce_badEMbits->fill((double)6,1.);
        if(isemtrk!=0) m_h_mce_badEMbits->fill((double)14,1.);
      }

      // Match to taus and to all electrons
      double retau = 0.999;
      double ree = 0.999;
      TruthParticleContainer::const_iterator ismatch;
      for(TruthParticleContainer::const_iterator is = (*spclTES).begin();
      is != (*spclTES).end() ; ++is) {
        double r = (*eItr)->hlv().deltaR( (*is)->hlv() );
        if( abs((*is)->pdgId()) == 15 ) {
          if( r < retau ) retau = r;
        }
        if( abs((*is)->pdgId()) == 11 && 
        (*is)->getGenParticle()->barcode() < 100000) {
          if( r < ree ) {
            ree = r;
            ismatch = is;
          }
        }
      }
      m_h_mce_badRtau->fill(retau,1.);
      m_h_mce_badRelec->fill(ree,1.);
      if( ree < 0.1 && *ismatch ) {
        mLog <<MSG::DEBUG
             <<"BADE pt,eta,pdgid,isol = "
             <<(*eItr)->pt() <<" " <<(*eItr)->eta() <<" " 
             <<(*eItr)->pdgId() <<" " <<etisol
             <<" matches pt,eta,pdgId,isol,status,barcode = "
             <<(*ismatch)->pt() <<" " <<(*ismatch)->eta() <<" " 
             <<(*ismatch)->pdgId() <<" " <<(*ismatch)->etIsol() <<" " 
             <<(*ismatch)->getGenParticle()->status() <<" " 
             <<(*ismatch)->getGenParticle()->barcode()
             <<endreq;
        m_h_mce_badIsol2D->fill(etisol/GeV,(*ismatch)->etIsol()/GeV,1.);  
        m_h_mce_badPtres->fill((*eItr)->pt()/(*ismatch)->pt(),1.);
      }

    } // endif good/bad electron

  }

  return sc;

}
