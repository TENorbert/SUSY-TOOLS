#include "SUSYPhysUser/MyLLTruthHistTool.h"
//#include "SUSYPhysUtils/ExtendTrackToCalo.h"

#include "ParticleEvent/Muon.h"
#include "ParticleEvent/MuonContainer.h"
#include "ParticleEvent/Electron.h"
#include "ParticleEvent/ElectronContainer.h"
#include "ParticleEvent/ParticleJet.h"
#include "ParticleEvent/TruthParticle.h"
#include "ParticleEvent/TruthParticleContainer.h"

#include "Particle/TrackParticleContainer.h"
#include "Particle/TrackParticle.h"

#include "HepMC/GenEvent.h"
#include "HepMC/GenParticle.h"
#include "HepMC/GenVertex.h"
#include "CLHEP/Vector/LorentzVector.h"

#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/MsgStream.h"
#include <math.h>
#include <string>


//////////////////////////////////////////////////////////////////////
MyLLTruthHistTool::MyLLTruthHistTool(  const std::string& type,
					 const std::string& name,
					 const IInterface* parent )
  :  SusyObjectTool( type, name, parent)  
{
  // declare the interface for this tool
  declareInterface<ISusyObjectTool> (this); 

  declareProperty("PrefixName", m_prefix = "");
  declareProperty("SpclMcName", m_spclMcName = "SpclMC");
  declareProperty("SoftEName", m_softEName = "");
  declareProperty("ptMinHardElectron", m_ptHardCut=20*GeV );
  declareProperty("electronKey",m_electronKey = "ElectronCollection");
  declareProperty("trackKey",m_trackKey = "TrackParticleCandidate");
}

MyLLTruthHistTool::~MyLLTruthHistTool() {}


//////////////////////////////////////////////////////////////////////
StatusCode MyLLTruthHistTool::initialize() {
  SusyObjectTool::initialize();

  MsgStream log(msgSvc(), name());

  log << MSG::INFO << "Booking Histos in folder " << m_foldername << endreq;

  m_h_chi2_etnearL = m_HistSvc->book(m_foldername,m_prefix+"chi2_etnearL",
    "et near",100,0.,200.);
  m_h_chi2_etfarL = m_HistSvc->book(m_foldername,m_prefix+"chi2_etfarL",
    "et far",100,0.,200.);
  m_h_chi2_mpairL = m_HistSvc->book(m_foldername,m_prefix+"chi2_mpairL",
    "M pair",100,0.,200.);
  m_h_chi2_etnearR = m_HistSvc->book(m_foldername,m_prefix+"chi2_etnearR",
    "et near",100,0.,200.);
  m_h_chi2_etfarR = m_HistSvc->book(m_foldername,m_prefix+"chi2_etfarR",
    "et far",100,0.,200.);
  m_h_chi2_mpairR = m_HistSvc->book(m_foldername,m_prefix+"chi2_mpairR",
    "M pair",100,0.,200.);

  m_h_mcemu_ptmx = m_HistSvc->book(m_foldername,m_prefix+"mcemu_ptmx",
    "pt",50,0.,250.);
  m_h_mcemu_id0 = m_HistSvc->book(m_foldername,m_prefix+"mcemu_id0",
    "ID0",100,0.,100.);
  m_h_mcemu_id1 = m_HistSvc->book(m_foldername,m_prefix+"mcemu_id1",
    "ID1",100,0.,100.);
  m_h_mcemu_id2 = m_HistSvc->book(m_foldername,m_prefix+"mcemu_id2",
    "ID2",100,0.,100.);

  return StatusCode::SUCCESS;
}


//////////////////////////////////////////////////////////////////////
StatusCode MyLLTruthHistTool::takeAction() {  

  MsgStream mLog(msgSvc(), name());

  ////////////////////////////////////////
  /// get the SpclMC AOD container from StoreGate
  /// We need the whole thing, not just the electrons/muons
  ////////////////////////////////////////

  const TruthParticleContainer* spclTES;
  StatusCode sc=m_pSG->retrieve( spclTES, m_spclMcName);
  if( sc.isFailure()  ||  !spclTES ) {
    mLog << MSG::WARNING
         << "No AOD SpclMC container found in TDS"
         << endreq;
    return StatusCode::SUCCESS;
  }  

  ////////////////////////////////////////
  /// Get the TrackParticleContainer
  ////////////////////////////////////////

  const Rec::TrackParticleContainer* trackTES;
  sc=m_pSG->retrieve( trackTES, m_trackKey);
  if( sc.isFailure()  ||  !trackTES ) {
     mLog << MSG::WARNING
          << "No AOD electron container found in TDS"
          << endreq;
     return StatusCode::SUCCESS;
  }

  const IParticleContainer* myElectrons(0);
  sc=Get(susy::electron,myElectrons);
  if(sc == StatusCode::FAILURE){
    mLog << MSG::WARNING
         << "No electron container found with name "
         << susy::electron
         << endreq;
    return StatusCode::FAILURE;
  }

  const IParticleContainer* myMuons(0);
  sc=Get(susy::muon,myMuons);
  if(sc == StatusCode::FAILURE){
    return StatusCode::FAILURE;
  }

  ////////////////////////////////////////
  /// Iterate over the truth container
  /// Find chi20~ -> ellL~ or ellR~ decays
  ////////////////////////////////////////

  for(TruthParticleContainer::const_iterator it = (*spclTES).begin();
  it != (*spclTES).end() ; ++it) {
    // find a chi2 -> l lL~
    if( (*it)->pdgId() != 1000023 ) continue;
    int nellL = 0;
    int nellR = 0;

    // tpgen must be declared const, but tpvtx must NOT be const for the 
    // subsequent particle_iterator's.
    // This is REALLY stupid!! FIX ME!!

    const HepMC::GenParticle* tpgen = (*it)->getGenParticle();
    if( !tpgen ) continue;
    HepMC::GenVertex* tpvtx = tpgen->end_vertex();
    if( !tpvtx ) continue;

    // Find slepton among (first generation) children
    HepMC::GenVertex::particle_iterator ipd =
      tpvtx->particles_begin(HepMC::children);
    HepMC::GenVertex::particle_iterator ipdE =
      tpvtx->particles_end(HepMC::children);

    const HepMC::GenParticle* lnear = 0;
    const HepMC::GenParticle* slnear = 0;
    for( ; ipd != ipdE; ++ipd ) {
      int id = abs( (*ipd)->pdg_id() );
      if( id == 1000011 || id == 1000013 ) {
        ++nellL;
        slnear = (*ipd);
      }
      if( id == 2000011 || id == 2000013 ) {
        ++nellR;
        slnear = (*ipd);
      }
      if( id == 11 || id == 13 ) {
        lnear = (*ipd);
      }
    }
    if( lnear == 0 || slnear == 0 ) continue;

    // Find final leptons
    HepLorentzVector pnear(0,0,0,0);
    HepLorentzVector pfar(0,0,0,0);
    int nfound = 0;

    HepMC::GenVertex* slvtx = slnear->end_vertex();
    if( slvtx == 0 ) continue;
    HepMC::GenVertex::particle_iterator sld = 
      slvtx->particles_begin(HepMC::descendants);
    HepMC::GenVertex::particle_iterator sldE = 
      slvtx->particles_end(HepMC::descendants);
    for(; sld != sldE; ++sld) {
      if( (*sld)->status() != 1 || (*sld)->barcode() > 100000 ) continue;
      int id = abs( (*sld)->pdg_id() );
      if( id == 11 || id == 13 ) {
        pfar = (*sld)->momentum();
        ++nfound;
      }
    }

    HepMC::GenVertex* lvtx = lnear->end_vertex();
    if( lvtx == 0 && lnear->status() == 1 ) {
      pnear = lnear->momentum();
      ++nfound;
    }
    if( lvtx == 0 ) continue;
    HepMC::GenVertex::particle_iterator ld =
      lvtx->particles_begin(HepMC::descendants);
    HepMC::GenVertex::particle_iterator ldE =
      lvtx->particles_end(HepMC::descendants);
    for(; ld != ldE; ++ld) {
      if( (*ld)->status() != 1 || (*ld)->barcode() > 100000 ) continue;
      int id = abs( (*ld)->pdg_id() );
      if( id == 11 || id == 13 ) {
        pnear = (*ld)->momentum();
        ++nfound;
      }
    }

    if( nfound != 2 || pnear.e() == 0 || pfar.e() == 0 ) {
      mLog <<MSG::ERROR <<"Bad event!" <<endreq;
      continue;
    }

    // Fill ell_L histograms
    if( nellL != 0 ) {
      if( fabs(pnear.eta()) < 2.5 && fabs(pfar.eta()) < 2.5 ) {
        m_h_chi2_etnearL->fill( pnear.perp()/GeV, 1. );
        m_h_chi2_etfarL->fill( pfar.perp()/GeV, 1.);
        double m12 = (pnear + pfar).m();
        m_h_chi2_mpairL->fill(m12/GeV,1.);
      }
    }

    // Fill ell_R histograms
    if( nellR != 0 ) {
      if( fabs(pnear.eta()) < 2.5 && fabs(pfar.eta()) < 2.5 ) {
        m_h_chi2_etnearR->fill( pnear.perp()/GeV, 1. );
        m_h_chi2_etfarR->fill( pfar.perp()/GeV, 1.);
        double m12 = (pnear + pfar).m();
        m_h_chi2_mpairR->fill(m12/GeV,1.);
      }
    }
  }

  ////////////////////////
  // Source of e-mu events
  ////////////////////////


  if( myElectrons->size() >= 1 && myMuons->size() >= 1 ) {
    double ptmxe = (*myElectrons->begin())->pt();
    double ptmxmu = (*myMuons->begin())->pt();
    double ptmx = (ptmxe>ptmxmu) ? ptmxe : ptmxmu;
    m_h_mcemu_ptmx->fill(ptmx/GeV,1.);    

    for(TruthParticleContainer::const_iterator it = (*spclTES).begin();
    it != (*spclTES).end() ; ++it) {
      int ida = abs( (*it)->pdgId() );
      if( ida < 100 ) m_h_mcemu_id0->fill(ida,1.);
      if( ida > 1000000 && ida < 2000000 ) {
        m_h_mcemu_id1->fill( ida%1000000, 1.);
      } else if( ida > 2000000 ) {
        m_h_mcemu_id2->fill( ida%1000000, 1.);
      }
    }
  }



  return StatusCode::SUCCESS;

}

