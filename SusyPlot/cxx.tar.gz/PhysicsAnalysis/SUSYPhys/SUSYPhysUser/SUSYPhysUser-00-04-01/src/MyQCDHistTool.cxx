/***********************************************************************
Filename : MyQCDHistTool.cxx
Author   : Frank Paige
Created  : September 2004

Tool to make histograms of jet kinematics.
***********************************************************************/

#include "SUSYPhysUser/MyQCDHistTool.h"
#include "ParticleEvent/TruthParticle.h"
#include "ParticleEvent/TruthParticleContainer.h"
#include "HepMC/GenParticle.h"

#include "EventInfo/EventInfo.h"
#include "EventInfo/EventID.h"
#include "EventInfo/AtlasMcWeight.h"

#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "AIDA/IProfile1D.h"
#include "GaudiKernel/MsgStream.h"
#include <math.h>
#include <string>

//////////////////////////////////////////////////////////////////////
MyQCDHistTool::MyQCDHistTool( const std::string& type,
                                            const std::string& name,
                                            const IInterface* parent )
  : SusyObjectTool( type, name, parent)
{
  declareInterface<ISusyObjectTool> (this);

  declareProperty("PrefixName", m_prefix = "");
  declareProperty("SpclMcName", m_spclMcName = "SpclMC");
  declareProperty("MuonName", m_muonName = "MuonCollection");

}

MyQCDHistTool::~MyQCDHistTool()
{}

//////////////////////////////////////////////////////////////////////
StatusCode MyQCDHistTool::initialize() 
{
  SusyObjectTool::initialize();

  MsgStream mLog(msgSvc(), name());

  mLog << MSG::INFO << "in initialize()" << endreq;

  StatusCode sc = StatusCode::SUCCESS;

  /// Book jet histograms with optional folder name
  /// WARNING: A histogram which is declared but not book will produce
  /// a segmentation violation with no useful traceback from athena.py.

  m_h_qcd_pt0 = m_HistSvc->book(m_foldername,m_prefix+"qcd_pt0",
    "pt(jet0)",100,0.,500.);
  m_h_qcd_meff = m_HistSvc->book(m_foldername,m_prefix+"qcd_meff",
    "Meff",100,0.,1000.);
  m_h_qcd_ptnu = m_HistSvc->book(m_foldername,m_prefix+"qcd_ptnu",
    "pt nu",100,0.,500.);
  m_h_qcd_ptmu = m_HistSvc->book(m_foldername,m_prefix+"qcd_ptmu",
    "pt mu",100,0.,500.);
  m_h_qcd_fracj2 = m_HistSvc->book(m_foldername,m_prefix+"qcd_fracj2",
    "pt(jet2)/Meff",100,0.,1.);
  m_h_qcd_ncharge = m_HistSvc->book(m_foldername,m_prefix+"qcd_ncharge",
    "N charge",50,0.,50.);
  m_h_qcd_fnarrow05 = m_HistSvc->book(m_foldername,m_prefix+"qcd_fnarrow05",
    "pt narrow",100,0.,1.);
  m_h_qcd_fnarrow10 = m_HistSvc->book(m_foldername,m_prefix+"qcd_fnarrow10",
    "pt narrow",100,0.,1.);
  m_h_qcd_ptcrack = m_HistSvc->book(m_foldername,m_prefix+"qcd_ptcrack",
    "pt crack",100,0.,500.);

  m_h_qcd_pt0pass = m_HistSvc->book(m_foldername,m_prefix+"qcd_pt0pass",
    "pt(jet0)",100,0.,500.);
  m_h_qcd_meffpass = m_HistSvc->book(m_foldername,m_prefix+"qcd_meffpass",
    "Meff",100,0.,1000.);
  m_h_qcd_ipass = m_HistSvc->book(m_foldername,m_prefix+"qcd_ipass",
    "Meff",10,0.,10.);

  return sc;

}

//////////////////////////////////////////////////////////////////////
StatusCode MyQCDHistTool::takeAction() 
{

  MsgStream mLog(msgSvc(), name());

  StatusCode sc = StatusCode::SUCCESS;

  // Get truth jets

  const IParticleContainer* myJetsMc(0);
  sc=Get(susy::jetmc, myJetsMc);
  if(sc == StatusCode::FAILURE || !myJetsMc){
    return StatusCode::SUCCESS;
  }
  if( myJetsMc->size() == 0 ) return StatusCode::SUCCESS;
  IParticleContainer::const_iterator jetMcItr  = (*myJetsMc).begin();
  IParticleContainer::const_iterator jetMcItrB = (*myJetsMc).begin();
  IParticleContainer::const_iterator jetMcItrE = (*myJetsMc).end();

  // Get truth Muons

  const IParticleContainer* myMuonsMc(0);
  sc=Get(susy::muonmc, myMuonsMc);
  if(sc == StatusCode::FAILURE || !myMuonsMc){
    return StatusCode::SUCCESS;
  }
  IParticleContainer::const_iterator muonMcItr  = (*myMuonsMc).begin();
  IParticleContainer::const_iterator muonMcItrB = (*myMuonsMc).begin();
  IParticleContainer::const_iterator muonMcItrE = (*myMuonsMc).end();

  // Special particles

  const TruthParticleContainer* spclTES(0);
  sc=m_pSG->retrieve( spclTES, m_spclMcName);
  if( sc.isFailure()  ||  !spclTES ) {
    mLog << MSG::WARNING
         << "No AOD SpclMC container found in TDS"
         << endreq;
    return StatusCode::SUCCESS;
  }
  TruthParticleContainer::const_iterator spclMcItr  = (*spclTES).begin();
  TruthParticleContainer::const_iterator spclMcItrB = (*spclTES).begin();
  TruthParticleContainer::const_iterator spclMcItrE = (*spclTES).end();

  // EventInfo
  const EventInfo* eventInfo;
  sc=m_pSG->retrieve( eventInfo );
  if( sc.isFailure()  ||  !eventInfo ) {
     mLog << MSG::WARNING
          << "No EventInfo found in TDS"
          << endreq; 
     return StatusCode::SUCCESS;
  }  

  ////////////////////////////////////////

  // Get weight from EventInfo

  double wt = AtlasMcWeight::getEventWeight(*eventInfo);
  mLog <<MSG::DEBUG <<"EventInfo wt = " <<wt <<endreq;


  double pt0 = (*jetMcItrB)->pt();
  mLog <<MSG::VERBOSE <<"QCD pt0 = " <<pt0 <<endreq;
  m_h_qcd_pt0->fill(pt0/GeV,wt);

  // Effective mass from jets + muons + neutrinos

  double meff = 0;
  for(jetMcItr = jetMcItrB; jetMcItr != jetMcItrE; ++jetMcItr) {
    double pt = (*jetMcItr)->pt();
    meff += pt;
  }
  double px = 0;
  double py = 0;
  double ptmu = 0;
  for(spclMcItr = spclMcItrB; spclMcItr != spclMcItrE; ++spclMcItr) {
    if( (*spclMcItr)->getGenParticle()->status() != 1 ) continue;
    int ida = abs( (*spclMcItr)->pdgId() );
    if( ida == 12 || ida == 14 || ida == 16 ) {
      px += (*spclMcItr)->px();
      py += (*spclMcItr)->py();
    }
    if( ida == 13 ) ptmu += (*spclMcItr)->pt();
  }
  double ptnu = sqrt( px*px + py*py );
  meff += ptnu;
  meff += ptmu;
  mLog <<MSG::VERBOSE <<"QCD meff = " <<meff <<endreq;
  m_h_qcd_meff->fill(meff/GeV,wt);

  if( pt0 < 75*GeV || meff < 300*GeV) return StatusCode::SUCCESS;

  ////////////////////////////////////////

  int ipass = 0;

  // Jet 3
  double ptj2 = 0;
  double fracj2 = 0;
  if( myJetsMc->size() >= 3 ) {
    const IParticle* jet2 = (*myJetsMc)[2];
    mLog <<MSG::VERBOSE <<"QCD jet2 = " <<jet2 <<endreq;
    ptj2 = jet2->pt();
    mLog <<MSG::VERBOSE <<"QCD ptj2 = " <<ptj2 <<endreq;
    fracj2 = ptj2/meff;
    if( ptj2 > 50*GeV ) {
      m_h_qcd_fracj2->fill(fracj2,wt);
      if( fracj2 > 0.25 ) ipass += 1;
    }
  }

  // Neutrinos
  mLog <<MSG::VERBOSE <<"QCD ptnu = " <<ptnu <<endreq;
  if( ptnu > 0 ) m_h_qcd_ptnu->fill(ptnu/GeV,wt);
  if( ptnu > 50*GeV ) ipass += 2;

  // Muons -- require pt > 0.1*ptjet if in jet
  mLog <<MSG::VERBOSE <<"QCD muons" <<endreq;
  for(spclMcItr = spclMcItrB; spclMcItr != spclMcItrE; ++spclMcItr) {
    if( (*spclMcItr)->getGenParticle()->status() != 1 ) continue;
    double ida = abs( (*spclMcItr)->pdgId() );
    if( ida != 13 ) continue;
    double pt = (*spclMcItr)->pt();
    if( pt < 10*GeV ) continue;
    mLog <<MSG::VERBOSE <<"QCD ptmu = " <<pt <<endreq;
    int idx = -1;
    double dr = 0.999;
    int id = 0;
    bool ok = m_pAnalysisTools->matchR((*spclMcItr),myJetsMc,idx,dr,id);
    double ptj = -1;
    if( ok ) {
      if( dr < 0.4 ) ptj = ((*myJetsMc)[idx])->pt();
    }
    if( ptj < 0 || pt/ptj > 0.1 ) {
      m_h_qcd_ptmu->fill(pt/GeV,wt);
      if( pt > 10*GeV ) ipass += 4;
    }
  }

  // Narrow jets
  mLog <<MSG::VERBOSE <<"QCD narrow jets" <<endreq;
  for(jetMcItr = jetMcItrB; jetMcItr != jetMcItrE; ++jetMcItr) {
    double pt = (*jetMcItr)->pt();
    if( pt < 20*GeV ) continue;
    double px05 = 0;
    double py05 = 0;
    double px10 = 0;
    double py10 = 0;
    int ncharge = 0;
    double charge = 0;
    // Loop over stable particles
    for(spclMcItr = spclMcItrB; spclMcItr != spclMcItrE; ++spclMcItr) {
      if( (*spclMcItr)->getGenParticle()->status() != 1 ) continue;
      double dr = (*jetMcItr)->hlv().deltaR( (*spclMcItr)->hlv() );
      if( dr > 0.4 ) continue;
      double ptspcl = (*spclMcItr)->pt();
      if( ptspcl > 2*GeV && (*spclMcItr)->charge() != 0 ) {
        charge += (*spclMcItr)->charge();
        ++ncharge;
      }
      if( dr < 0.10 ) {
        px10 += (*spclMcItr)->px();
        py10 += (*spclMcItr)->py();
      }
      if( dr < 0.05 ) {
        px05 += (*spclMcItr)->px();
        py05 += (*spclMcItr)->py();
      }
    }
    m_h_qcd_ncharge->fill((double)ncharge,wt);
    double f05 = sqrt(px05*px05+py05*py05)/pt;
    double f10 = sqrt(px10*px10+py10*py10)/pt;
    if( ncharge <= 3 && charge <= 1.5 ) {
      mLog <<MSG::VERBOSE <<"QCD f05,f10 = " <<f05 <<" " <<f10 <<endreq;
      m_h_qcd_fnarrow05->fill(f05,wt);
      m_h_qcd_fnarrow10->fill(f10,wt);
      if( f05 > 0.8 || f10 > 0.9 ) ipass += 8;
    }
  }

  // Jets in crack region -- at least 3 jets
  mLog <<MSG::VERBOSE <<"QCD crack jets" <<endreq;
  for(jetMcItr = jetMcItrB; jetMcItr != jetMcItrE; ++jetMcItr) {
    double pt = (*jetMcItr)->pt();
    double etaa = fabs( (*jetMcItr)->eta() );
    if( etaa < 3.0 || etaa > 3.4 ) continue;
    mLog <<MSG::VERBOSE <<"QCD ptcrack = " <<pt <<endreq;
    if( ptj2 > 50*GeV) {
      m_h_qcd_ptcrack->fill(pt/GeV,wt);
      if( pt > 100*GeV ) ipass += 16;
    }
  }

  if( ipass ) {
    mLog <<MSG::VERBOSE <<"QCD pass = " <<pt0 <<" " <<meff <<endreq;
    m_h_qcd_pt0pass->fill(pt0/GeV,wt);
    m_h_qcd_meffpass->fill(meff/GeV,wt);
    for(int i=1; i<10; ++i ) {
      if( ipass%2 ) m_h_qcd_ipass->fill((double)i,wt);
      ipass = ipass/2;
    }
  }

  return sc;
}
