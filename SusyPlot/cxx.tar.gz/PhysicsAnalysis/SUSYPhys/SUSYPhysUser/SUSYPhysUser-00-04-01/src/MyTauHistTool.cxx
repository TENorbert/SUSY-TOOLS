#include "SUSYPhysUser/MyTauHistTool.h"
#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/MsgStream.h"
#include "CLHEP/Matrix/Vector.h"
#include "FourMom/P4Help.h"

#include "Particle/TrackParticleContainer.h"
#include "Particle/TrackParticle.h"
#include "ParticleEvent/TauJet.h"
#include "ParticleEvent/TauJetContainer.h"

#include <math.h>
#include <string>

//////////////////////////////////////////////////////////////////////
MyTauHistTool::MyTauHistTool( const std::string& type,
                                  const std::string& name,
                                  const IInterface* parent )
  : SusyObjectTool( type, name, parent)
{
  // declare the interface for this tool
  declareInterface<ISusyObjectTool> (this); 

  declareProperty("PrefixName", m_prefix = "");
  declareProperty("trackKey",m_trackKey = "TrackParticleCandidate");
  declareProperty("SusyTrackKey",m_SusyTrackKey = "SusyTracks");
  declareProperty("TauEtCut", m_ettauStandardCut = 20.0*GeV);
  declareProperty("TauEtHardCut", m_ettauHardCut = 40.0*GeV);
  declareProperty("TrackEtCut", m_etTrkCut = 40.0*GeV);

}

MyTauHistTool::~MyTauHistTool() {}

//////////////////////////////////////////////////////////////////////
StatusCode MyTauHistTool::initialize() {
  SusyObjectTool::initialize();
  MsgStream log(msgSvc(), name());

  log << MSG::INFO << "Booking Histos in folder " << m_foldername << endreq;

  m_h_tau_n =  m_HistSvc->book(m_foldername,m_prefix+"tau_n",
    "N Tau",20,0.,20.);
  m_h_tau_pt1 =  m_HistSvc->book(m_foldername,m_prefix+"tau_et1",
    "pt (leading Tau)",50,0.,250.);
  m_h_tau_pt =  m_HistSvc->book(m_foldername,m_prefix+"tau_et",
    "et (tau)",50,0.,250.);
  m_h_tau_ptplus =  m_HistSvc->book(m_foldername,m_prefix+"tau_etplus",
    "et (tau)",50,0.,250.);
  m_h_tau_ptminus =  m_HistSvc->book(m_foldername,m_prefix+"tau_etminus",
    "et (tau)",50,0.,250.);
  m_h_tau_etaall =  m_HistSvc->book(m_foldername,m_prefix+"tau_eta",
    "eta",50,-5.,5.);

  m_h_tau_Mllos = m_HistSvc->book(m_foldername,m_prefix+"tau_Mllos",
    "Mll",50,0.,200.);
  m_h_tau_Mllss = m_HistSvc->book(m_foldername,m_prefix+"tau_Mllss",
    "Mll",50,0.,200.);
  m_h_tau_Mltrkos = m_HistSvc->book(m_foldername,m_prefix+"tau_Mltrkos",
    "Mll",50,0.,200.);
  m_h_tau_Mltrkss = m_HistSvc->book(m_foldername,m_prefix+"tau_Mltrkss",
    "Mll",50,0.,200.);

  m_h_tau_like = m_HistSvc->book(m_foldername,m_prefix+"tau_like",
    "tau Like",80,-20.,20.);
  m_h_tau_ntrack = m_HistSvc->book(m_foldername,m_prefix+"tau_ntrack",
    "N track",10,0.,10.);
  m_h_tau_rem = m_HistSvc->book(m_foldername,m_prefix+"tau_rem",
    "R EM",100,0.,1.);
  m_h_tau_isofrac = m_HistSvc->book(m_foldername,m_prefix+"tau_isofrac",
    "Iso Frac",100,0.,1.);
  m_h_tau_stripwidth = m_HistSvc->book(m_foldername,m_prefix+"tau_stripwidth",
    "Strip width",100,0.,0.1);
  m_h_tau_ntrack1 = m_HistSvc->book(m_foldername,m_prefix+"tau_ntrack1",
    "N track",10,0.,10.);
  m_h_tau_rjet = m_HistSvc->book(m_foldername,m_prefix+"tau_rjet",
    "R jet",100,0.,1.);
  m_h_tau_etfracjet = m_HistSvc->book(m_foldername,m_prefix+"tau_etfracjet",
    "ETfrac jet",100,0.,10.);

  m_h_tau_nisotrk = m_HistSvc->book(m_foldername,m_prefix+"tau_nisotrk",
    "N iso trk",20,0.,20.);
  m_h_tau_ptisotrk = m_HistSvc->book(m_foldername,m_prefix+"tau_ptisotrk",
    "pt iso trk",100,0.,100.);

  return StatusCode::SUCCESS;
}


//////////////////////////////////////////////////////////////////////
StatusCode MyTauHistTool::takeAction() {  
  MsgStream mLog(msgSvc(), name());
  const IParticleContainer* myTaus(0);

  StatusCode sc=Get(susy::tau,myTaus);
  if(sc == StatusCode::FAILURE){
    return StatusCode::SUCCESS;
  }

  const IParticleContainer* myJets(0);
  sc=Get(susy::jet,myJets);
  if(sc == StatusCode::FAILURE){
    return StatusCode::SUCCESS;
  }

  /// Get the TrackParticleContainer
  const Rec::TrackParticleContainer* trackTES;
  sc=m_pSG->retrieve( trackTES, m_trackKey);
  if( sc.isFailure()  ||  !trackTES ) {
     mLog << MSG::WARNING
          << "No TrackParticle container found in TDS"
          << endreq;
     return StatusCode::SUCCESS;
  }

  /// Get SusyTracks
  const Rec::TrackParticleContainer* SusyTracks;
  sc=m_pSG->retrieve( SusyTracks, m_SusyTrackKey);
  if( sc.isFailure()  ||  !trackTES ) {
     mLog << MSG::WARNING
          << "No SusyTracks container found in TDS"
          << endreq;
     return StatusCode::SUCCESS;
  }
  Rec::TrackParticleContainer::const_iterator trk;
  Rec::TrackParticleContainer::const_iterator trkB = SusyTracks->begin();
  Rec::TrackParticleContainer::const_iterator trkE = SusyTracks->end();

  //////////////////////////////

  if (myTaus->size() >0) {
    m_h_tau_pt1->fill((*(myTaus->begin()))->pt()/GeV,1.);
  }

  // tau pairs
  int ntau = myTaus->size();
  if( ntau > 1 ) {
    for(int i=0; i<ntau; ++i) {
      for(int j=i+1; j<ntau; ++j) {
        double m12 = ( (*myTaus)[i]->hlv() + (*myTaus)[j]->hlv() ).m();
        if( (*myTaus)[i]->charge() * (*myTaus)[j]->charge() < 0) {
          m_h_tau_Mllos->fill(m12/GeV,1.);
        } else {
          m_h_tau_Mllss->fill(m12/GeV,1.);
        }
      }
    }
  }

  // inclusive taus
  // pt cut on n,eta as for mctau
  int nTau=0;
  for(IParticleContainer::const_iterator it= myTaus->begin(); 
  it !=myTaus->end(); ++it){
    if((*it)->pt() > m_ettauStandardCut) ++nTau;
    m_h_tau_pt->fill((*it)->pt()/GeV,1.);
    if((*it)->charge()>0) m_h_tau_ptplus->fill((*it)->pt()/GeV,1.);
    if((*it)->charge()<0) m_h_tau_ptminus->fill((*it)->pt()/GeV,1.);
    if((*it)->pt() > m_ettauStandardCut) m_h_tau_etaall->fill((*it)->eta(),1.);

    // Get retrieves an IParticleContainer, so we have to dynamic_cast
    // to use Tau methods:
    TauJet* tau = dynamic_cast< TauJet* >(*it);
    m_h_tau_like->fill(tau->likelihood(),1.);
    m_h_tau_ntrack->fill(tau->numTrack(),1.);

    m_h_tau_rem->fill(tau->EMRadius(),1.);
    m_h_tau_isofrac->fill(tau->IsoFrac(),1.);
    m_h_tau_stripwidth->fill(tau->stripWidth2(),1.);

    //m_h_tau_ntrack1->fill(tau->nTrack1(),1.);
    //P4Help::deltaR needs I4Momentum, not HepLorentzVector
    int ntrk1 = 0;
    Rec::TrackParticleContainer::const_iterator tkItr = (*trackTES).begin();
    Rec::TrackParticleContainer::const_iterator tkItrE = (*trackTES).end();
    for(; tkItr != tkItrE; ++tkItr) {
      if( (*tkItr)->pt() < 1*GeV) continue;
      double dr = fabs( (*it)->phi()-(*tkItr)->phi() );
      if( dr>M_PI ) dr = 2*M_PI - dr;
      dr = sqrt( dr*dr + pow((*it)->eta()-(*tkItr)->eta(),2) );
      if( dr < 0.3 ) ++ntrk1;
    }
    m_h_tau_ntrack1->fill( (double)ntrk1, 1.);

    // Isolation using jets
    int index = -1;
    double deltaRMatch = 0.999;
    int pdgId = 0;
    bool findAMatch = m_pAnalysisTools->matchR((*it), myJets,
                                               index, deltaRMatch,pdgId);
    if( !findAMatch ) deltaRMatch = 0.999;
    deltaRMatch = (deltaRMatch>0.999) ? 0.999 : deltaRMatch;
    m_h_tau_rjet->fill(deltaRMatch,1.0);
    if( findAMatch ) {
      double etfracjet = (*it)->pt() / (*myJets)[index]->et();
      if(etfracjet>9.999) etfracjet = 9.999;
      if( deltaRMatch<0.4 ) m_h_tau_etfracjet->fill(etfracjet,1.);
    }

  }
  m_h_tau_n->fill((float)nTau,1.);

  // Mass distribution for (hard) tau + any isolated track

  mLog <<MSG::DEBUG <<"SusyTracks size = " <<SusyTracks->size()
       <<endreq;

  m_h_tau_nisotrk->fill( SusyTracks->size(),1);
  for(trk=trkB; trk!=trkE; ++trk) {
    m_h_tau_ptisotrk->fill( (*trk)->pt()/GeV,1.);
  }

  for(IParticleContainer::const_iterator it= myTaus->begin(); 
  it !=myTaus->end(); ++it) {
    if( (*it)->pt() < m_ettauHardCut ) continue;
    double qtau = (*it)->charge();
    for(trk=trkB; trk!=trkE; ++trk) {
      if( (*it)->hlv().deltaR((*trk)->hlv()) < 0.1 ) continue;
      if( (*trk)->pt() > m_etTrkCut ) continue;
      double qtrk = (*trk)->charge();
      double mltrk = ( (*it)->hlv() + (*trk)->hlv() ).m();
      if( qtau*qtrk < 0 ) {
        m_h_tau_Mltrkos->fill(mltrk/GeV,1.);
      } else {
        m_h_tau_Mltrkss->fill(mltrk/GeV,1.);
      }
    }
  }

  return StatusCode::SUCCESS;
}

