// Simple muon plots
// Ian Hinchliffe/Davide Costanzo
// Sept2004

#include "SUSYPhysUser/MyMuonHistTool.h"
#include "ParticleEvent/Muon.h"
#include "TrkTrack/FitQuality.h"
#include "Particle/TrackParticle.h"
#include "Particle/TrackParticleContainer.h"

#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/MsgStream.h"
#include "CLHEP/Vector/LorentzVector.h"
#include <math.h>
#include <string>

MyMuonHistTool::MyMuonHistTool(  const std::string& type,
					 const std::string& name,
					 const IInterface* parent )
  :  SusyObjectTool( type, name, parent)  
{
  // declare the interface for this tool
  declareInterface<ISusyObjectTool> (this); 
  // Here the properties which are specife to this hist 
  declareProperty("Fix90x", m_fix90x = 0 );
}


MyMuonHistTool::~MyMuonHistTool() {}

// Initialize method. 
StatusCode MyMuonHistTool::initialize() {
  SusyObjectTool::initialize();

  MsgStream log(msgSvc(), name());
  log << MSG::INFO << "Booking Histos in folder " << m_foldername << endreq;

  m_h_mu_n = m_HistSvc->book(m_foldername,m_prefix+"mu_n",
    "N muon",20,0.,20.);
  m_h_mu_pt1 = m_HistSvc->book(m_foldername,m_prefix+"mu_pt1",
    "pt1",50,0.,250.);
  m_h_mu_pt = m_HistSvc->book(m_foldername,m_prefix+"mu_pt",
    "pt",50,0.,250.);
  m_h_mu_ptplus = m_HistSvc->book(m_foldername,m_prefix+"mu_ptplus",
    "pt",50,0.,250.);
  m_h_mu_ptminus = m_HistSvc->book(m_foldername,m_prefix+"mu_ptminus",
    "pt",50,0.,250.);
  m_h_mu_etaall = m_HistSvc->book(m_foldername,m_prefix+"mu_eta",
    "eta",50,0.,5.);
  m_h_mu_isol = m_HistSvc->book(m_foldername,m_prefix+"mu_etIsol",
    "Et isol",50,0.,50.);
  m_h_mu_chi2 = m_HistSvc->book(m_foldername,m_prefix+"mu_chi2",
    "chi2",100,0.,25.);

  return StatusCode::SUCCESS;
}


// Called by the algorithm to read collections from the store and   makes some plots.


StatusCode MyMuonHistTool::takeAction() {  
  MsgStream log(msgSvc(), name());
  const IParticleContainer* myMuons(0);
  StatusCode sc=Get(susy::muon,myMuons);
  if(sc == StatusCode::FAILURE){
    return StatusCode::FAILURE;
  }
  m_h_mu_n->fill((float)myMuons->size(),1.);
  
  if (myMuons->size() >0) {
    m_h_mu_pt1->fill((*(myMuons->begin()))->pt()/GeV,1.);
  }

  for (IParticleContainer::const_iterator thismuon= myMuons->begin();
  thismuon !=myMuons->end(); ++thismuon){
    m_h_mu_pt->fill( (*thismuon)->pt()/GeV, 1.);
    if((*thismuon)->charge()>0) m_h_mu_ptplus->fill((*thismuon)->pt()/GeV,1.);
    if((*thismuon)->charge()<0) m_h_mu_ptminus->fill((*thismuon)->pt()/GeV,1.);
    m_h_mu_etaall->fill( fabs((*thismuon)->eta()), 1.);

    // Muon specific variables
    const Muon* muon = dynamic_cast< const Muon* >(*thismuon);
    if( !muon ) continue;

    // Muon isolation is wrongly computed in 9.0.4 AOD builder;
    // pt_inner-pt_outer was added rather than subtracted.
    // So subtract twice as much here:
    // Corrected (I hope) in 10.0.1. New getEtIsol in 10.0. uses cones from
    // Reconstruction/Muid/MuidParticleCreator/src/MuidCnvAlg.cxx
    // ones[4]= 0.45

    double etisol = (muon->getEtIsol())[4]; 
    m_h_mu_isol->fill(etisol/GeV,1.);

    // chi2() is missing in 10.0.1
    const Rec::TrackParticle* duh = muon->get_CombinedMuonTrackParticle();
    if( duh ) {
      double chi2 = duh->fitQuality()->chiSquared();
      int ndof = duh->fitQuality()->numberDoF();
      if( ndof > 0 ) chi2 = chi2/ndof;
      m_h_mu_chi2->fill(chi2,1.);
    }

  }
  
   return StatusCode::SUCCESS;

}

