/***********************************************************************
Filename : MyJetHistTool.cxx
Author   : Frank Paige
Created  : September 2004

Tool to make histograms of jet kinematics.
***********************************************************************/

#include "SUSYPhysUser/MyJetHistTool.h"
#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/MsgStream.h"
#include <math.h>
#include <string>

// To access ParticleJet methods
#include "ParticleEvent/ParticleJet.h"
#include "ParticleEvent/ParticleJetContainer.h"

//////////////////////////////////////////////////////////////////////
MyJetHistTool::MyJetHistTool( const std::string& type,
                                  const std::string& name,
                                  const IInterface* parent )
  : SusyObjectTool( type, name, parent)  
{
  // declare the interface for this tool
  declareInterface<ISusyObjectTool> (this); 

  declareProperty("PrefixName", m_prefix = "");
  declareProperty("JetEtCut", m_etJetStandardCut = 15.0*GeV);
}


MyJetHistTool::~MyJetHistTool() {}


//////////////////////////////////////////////////////////////////////
// Initialize method. 

StatusCode MyJetHistTool::initialize() {

  SusyObjectTool::initialize();

  MsgStream mLog(msgSvc(), name());
  mLog <<MSG::INFO <<"Initializing histograms in " <<m_foldername <<endreq;

  /// Book jet histograms with optional folder name
  /// WARNING: A histogram which is declared but not book will produce
  /// a segmentation violation with no useful traceback from athena.py.

  m_h_jetn = m_HistSvc->book(m_foldername,m_prefix+"jet_n",
    "N jet",20,0.,20.);
  m_h_jetet = m_HistSvc->book(m_foldername,m_prefix+"jet_et",
    "ET jet",100,0.,1000.);
  m_h_jetet1 = m_HistSvc->book(m_foldername,m_prefix+"jet_et1",
    "ET jet1",100,0.,1000.);
  m_h_jetet2 = m_HistSvc->book(m_foldername,m_prefix+"jet_et2",
    "ET jet2",100,0.,1000.);
  m_h_jetm12 = m_HistSvc->book(m_foldername,m_prefix+"jet_m12",
    "M(jet1-2)",100,0.,1000.);
  m_h_jeteta10 = m_HistSvc->book(m_foldername,m_prefix+"jet_eta10",
    "eta jet10",100,0.,5.);
  m_h_jeteta20 = m_HistSvc->book(m_foldername,m_prefix+"jet_eta20",
    "eta jet20",100,0.,5.);
  m_h_jeteta50 = m_HistSvc->book(m_foldername,m_prefix+"jet_eta50",
    "eta jet50",100,0.,5.);
  m_h_jeteta100 = m_HistSvc->book(m_foldername,m_prefix+"jet_eta100",
    "eta jet100",100,0.,5.);
  m_h_jetetemfrac20 = m_HistSvc->book(m_foldername,m_prefix+"jet_etemfrac20",
    "eta em20",100,0.,5.);
  m_h_jetethadfrac20 = m_HistSvc->book(m_foldername,m_prefix+"jet_ethadfrac20",
    "eta had20",100,0.,5.);

  mLog <<MSG::INFO <<"Initializing done" <<endreq;

  return StatusCode::SUCCESS;
}


//////////////////////////////////////////////////////////////////////
// Called by the algorithm to read collections from the store and   
// makes some plots.

StatusCode MyJetHistTool::takeAction() {  

  MsgStream mLog(msgSvc(), name());
  StatusCode sc;

  const IParticleContainer* myJets(0);
  sc=Get(susy::jet,myJets);
  if(sc == StatusCode::FAILURE){
    return StatusCode::FAILURE;
  }
  IParticleContainer::const_iterator jetItr  = (*myJets).begin();
  IParticleContainer::const_iterator jetItrE = (*myJets).end();

  /// counters
  int njet15 =  0;

  /// the 2 leading jets - the collections are ordered
  if (myJets->size() >= 2) {
    m_h_jetet1->fill((*myJets)[0]->pt()/GeV,1.);
    m_h_jetet2->fill((*myJets)[1]->pt()/GeV,1.);
    m_h_jetm12->fill(((*myJets)[0]->hlv()+(*myJets)[1]->hlv()).m()/GeV,1.);
  }

  for(; jetItr != jetItrE; ++jetItr) {
    double ej = (*jetItr)->e();
    double ptj = (*jetItr)->pt();
    if(ptj > 15*GeV) ++njet15;
    mLog << MSG::DEBUG << "ej,ptj = " <<ej <<" " <<ptj <<endreq;

    // Kinematic plots
    m_h_jetet->fill( ptj/GeV,1.);
    double etaj = (*jetItr)->hlv().pseudoRapidity();
    double etaaj = fabs(etaj);
    if( ptj>10*GeV ) m_h_jeteta10->fill(etaaj,1.);
    if( ptj>20*GeV ) m_h_jeteta20->fill(etaaj,1.);
    if( ptj>50*GeV ) m_h_jeteta50->fill(etaaj,1.);
    if( ptj>100*GeV ) m_h_jeteta100->fill(etaaj,1.);

/*
    // EM and Had ET fractions
    if( ptj > 20*GeV ) {
      double etem = (*jetItr)->etEM(0)+(*jetItr)->etEM(1)+
                    (*jetItr)->etEM(2);
      double ethad = (*jetItr)->etHad(0)+(*jetItr)->etHad(1)+
                     (*jetItr)->etHad(2);
      m_h_jetetemfrac20->fill(etem/ptj,1.);
      m_h_jetethadfrac20->fill(ethad/ptj,1.);
    }
*/

  }
  m_h_jetn->fill( (double)njet15, 1.);


  return StatusCode::SUCCESS;
}

