#include "GaudiKernel/DeclareFactoryEntries.h"

#include "SUSYPhysUser/MySimpleHistTool.h"
#include "SUSYPhysUser/MyGlobalHistTool.h"
#include "SUSYPhysUser/MyInclusiveHistTool.h"
#include "SUSYPhysUser/MyMuonHistTool.h"
#include "SUSYPhysUser/MyJetHistTool.h"
#include "SUSYPhysUser/MyTauHistTool.h"
#include "SUSYPhysUser/MyElectronHistTool.h"
#include "SUSYPhysUser/MyMuonTruthHistTool.h"
#include "SUSYPhysUser/MyElectronTruthHistTool.h"
#include "SUSYPhysUser/MyJetTruthHistTool.h"
#include "SUSYPhysUser/MyTauTruthHistTool.h"
#include "SUSYPhysUser/MyLLHistTool.h"
#include "SUSYPhysUser/MyLLTruthHistTool.h"
#include "SUSYPhysUser/MyQCDHistTool.h"

DECLARE_TOOL_FACTORY( MySimpleHistTool );
DECLARE_TOOL_FACTORY( MyGlobalHistTool );
DECLARE_TOOL_FACTORY( MyInclusiveHistTool );
DECLARE_TOOL_FACTORY( MyMuonHistTool );
DECLARE_TOOL_FACTORY( MyElectronHistTool );
DECLARE_TOOL_FACTORY( MyJetHistTool );
DECLARE_TOOL_FACTORY( MyTauHistTool );
DECLARE_TOOL_FACTORY( MyMuonTruthHistTool );
DECLARE_TOOL_FACTORY( MyElectronTruthHistTool );
DECLARE_TOOL_FACTORY( MyJetTruthHistTool );
DECLARE_TOOL_FACTORY( MyTauTruthHistTool );
DECLARE_TOOL_FACTORY( MyLLHistTool );
DECLARE_TOOL_FACTORY( MyLLTruthHistTool );
DECLARE_TOOL_FACTORY( MyQCDHistTool );

DECLARE_FACTORY_ENTRIES( SUSYPhysUser  )
{
    DECLARE_TOOL( MySimpleHistTool );
    DECLARE_TOOL( MyGlobalHistTool );
    DECLARE_TOOL( MyInclusiveHistTool );
    DECLARE_TOOL( MyMuonHistTool );
    DECLARE_TOOL( MyElectronHistTool );
    DECLARE_TOOL( MyJetHistTool );
    DECLARE_TOOL( MyTauHistTool );
    DECLARE_TOOL( MyMuonTruthHistTool );
    DECLARE_TOOL( MyElectronTruthHistTool );
    DECLARE_TOOL( MyJetTruthHistTool );
    DECLARE_TOOL( MyTauTruthHistTool );
    DECLARE_TOOL( MyLLHistTool );
    DECLARE_TOOL( MyLLTruthHistTool );
    DECLARE_TOOL( MyQCDHistTool );
};
