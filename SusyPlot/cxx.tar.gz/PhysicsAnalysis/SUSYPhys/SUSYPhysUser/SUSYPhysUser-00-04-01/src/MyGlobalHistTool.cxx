/***********************************************************************
Filename : MyGlobalHistTool.cxx
Author   : Dan Tovey
Created  : October 2004

Tool to make histograms of Global quantities.

Aug 2005: rewritten to use new SusyGlobalCreator with correct treatment
of muons.

***********************************************************************/

#include "SUSYPhysUser/MyGlobalHistTool.h"

#include "SUSYPhysUtils/SusyGlobalObject.h"
#include "ParticleEvent/TruthParticle.h"
#include "ParticleEvent/TruthParticleContainer.h"
#include "ParticleEvent/ParticleJet.h"
#include "ParticleEvent/ParticleJetContainer.h"
#include "ParticleEvent/MuonContainer.h"
#include "ParticleEvent/Muon.h"
#include "CaloEvent/CaloSampling.h"
#include "TrkTrack/FitQuality.h"
#include "Particle/TrackParticle.h"
#include "Particle/TrackParticleContainer.h"
#include "MissingETEvent/MissingET.h"

#include "EventInfo/EventInfo.h"
#include "EventInfo/EventID.h"
#include "EventInfo/AtlasMcWeight.h"

#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/MsgStream.h"
#include <math.h>
#include <string>

//////////////////////////////////////////////////////////////////////
MyGlobalHistTool::MyGlobalHistTool( const std::string& type,
                                  const std::string& name,
                                  const IInterface* parent )
  : SusyObjectTool( type, name, parent)  
{
  // declare the interface for this tool
  declareInterface<ISusyObjectTool> (this); 

  declareProperty("PrefixName", m_prefix = "");
  declareProperty("SpclMcName", m_spclMcName = "SpclMC");
  declareProperty("MuonContainerName", m_muonContainerName="MuonCollection");
  declareProperty("MuonMcName", m_muonMcName="AllMuonMc");
  declareProperty("MuonChi2Cut", m_muonChi2Cut=5);
  declareProperty("MetName", m_metName="MET_Final");
  declareProperty("MuonMooreCut", m_muonMooreCut=0.1);
  declareProperty("MuonMDTCut", m_muonMDTCut=15);
}

MyGlobalHistTool::~MyGlobalHistTool() {}


//////////////////////////////////////////////////////////////////////
// Initialize method. 

StatusCode MyGlobalHistTool::initialize() {

  SusyObjectTool::initialize();

  MsgStream mLog(msgSvc(), name());
  mLog <<MSG::INFO <<"Initializing histograms in " <<m_foldername <<endreq;

  /// Book histograms with optional folder name
  /// WARNING: A histogram which is declared but not book will produce
  /// a segmentation violation with no useful traceback from athena.py.

  // Scales are GeV
  double diflim = 1000;
  double elim = 5000;

  m_h_miss_ex = m_HistSvc->book(m_foldername,m_prefix+"miss_ex",
  "ExMiss",100,-diflim,diflim);
  m_h_miss_ey = m_HistSvc->book(m_foldername,m_prefix+"miss_ey",
  "EyMiss",100,-diflim,diflim);
  m_h_miss_et = m_HistSvc->book(m_foldername,m_prefix+"miss_et",
  "EtMiss",100,0.,diflim);
  m_h_miss_etcut = m_HistSvc->book(m_foldername,m_prefix+"miss_etcut",
  "EtMiss",100,0.,diflim);
  m_h_miss_etfinal = m_HistSvc->book(m_foldername,m_prefix+"miss_etfinal",
  "EtMiss",100,0.,diflim);
  m_h_miss_etsum = m_HistSvc->book(m_foldername,m_prefix+"miss_etsum",
  "EtSum",100,0.,elim);

  m_h_mcmiss_ex = m_HistSvc->book(m_foldername,m_prefix+"mcmiss_ex",
  "Exmiss",100,-diflim,diflim);
  m_h_mcmiss_ey = m_HistSvc->book(m_foldername,m_prefix+"mcmiss_ey",
  "Eymiss",100,-diflim,diflim);
  m_h_mcmiss_et = m_HistSvc->book(m_foldername,m_prefix+"mcmiss_et",
  "Etmiss",100,0.,diflim);
  m_h_mcmiss_etcut = m_HistSvc->book(m_foldername,m_prefix+"mcmiss_etcut",
  "Etmiss",100,0.,diflim);
  m_h_mcmiss_etsum = m_HistSvc->book(m_foldername,m_prefix+"mcmiss_etsum",
  "EtSum",100,0.,elim);

  m_h_mcmiss_dex = m_HistSvc->book(m_foldername,m_prefix+"mcmiss_dex",
  "Exmiss",100,-diflim,diflim);
  m_h_mcmiss_dey = m_HistSvc->book(m_foldername,m_prefix+"mcmiss_dey",
  "Eymiss",100,-diflim,diflim);
  m_h_mcmiss_det = m_HistSvc->book(m_foldername,m_prefix+"mcmiss_det",
  "Etmiss",100,0.,diflim);
  m_h_mcmiss_detcut = m_HistSvc->book(m_foldername,m_prefix+"mcmiss_detcut",
  "Etmiss",100,0.,diflim);
  m_h_mcmiss_detsum = m_HistSvc->book(m_foldername,m_prefix+"mcmiss_detsum",
  "EtSum",100,-diflim,diflim);

  m_h_mcmiss_jetet = m_HistSvc->book(m_foldername,m_prefix+"mcmiss_jetet",
  "Etmiss",100,0.,diflim);
  m_h_mcmiss_jeteta = m_HistSvc->book(m_foldername,m_prefix+"mcmiss_jeteta",
  "Eta",100,0.,5.);
  m_h_mcmiss_jetdphi = m_HistSvc->book(m_foldername,m_prefix+"mcmiss_jetdphi",
  "Phi",100,0.,1.);
  m_h_mcmiss_jetphimin = m_HistSvc->book(m_foldername,m_prefix+"mcmiss_jetphimin",
  "Phi",100,0.,1.);
  m_h_mcmiss_jetphimax = m_HistSvc->book(m_foldername,m_prefix+"mcmiss_jetphimax",
  "Phi",100,0.,1.);
  m_h_mcmiss_jetetamin = m_HistSvc->book(m_foldername,m_prefix+"mcmiss_jetetamin",
  "Eta",100,0.,5.);

  m_h_miss_mupt = m_HistSvc->book(m_foldername,m_prefix+"miss_mupt",
  "mupt",100,0.,500.);
  m_h_miss_muchi2 = m_HistSvc->book(m_foldername,m_prefix+"miss_muchi2",
  "muchi2",100,0.,20.);
  m_h_miss_mueta = m_HistSvc->book(m_foldername,m_prefix+"miss_mueta",
  "mueta",60,0.,3.);
  m_h_miss_mueta50 = m_HistSvc->book(m_foldername,m_prefix+"miss_mueta50",
  "mueta",60,0.,3.);
  m_h_miss_muidrat = m_HistSvc->book(m_foldername,m_prefix+"miss_muidrat",
  "murat",100,0.,2.);
  m_h_miss_mumoorat = m_HistSvc->book(m_foldername,m_prefix+"miss_mumoorat",
  "murat",100,0.,2.);
  m_h_miss_mun = m_HistSvc->book(m_foldername,m_prefix+"miss_mun",
  "mueta",20,0.,20);
  m_h_miss_mumdt = m_HistSvc->book(m_foldername,m_prefix+"miss_mumdt",
  "mueta",40,0.,40);

  m_h_miss_mumcpt = m_HistSvc->book(m_foldername,m_prefix+"miss_mumcpt",
  "mupt",100,0.,500.);
  m_h_miss_mumcr = m_HistSvc->book(m_foldername,m_prefix+"miss_mumcr",
  "mur",100,0.,1.);

  m_h_susy0id = m_HistSvc->book(m_foldername,m_prefix+"susy0ID",
  "ID 0",100,0,100.0);
  m_h_susy1id = m_HistSvc->book(m_foldername,m_prefix+"susy1ID",
  "ID 1",100,0,100.0);
  m_h_susy2id = m_HistSvc->book(m_foldername,m_prefix+"susy2ID",
  "ID 2",100,0,100.0);

  m_h_meff = m_HistSvc->book(m_foldername,m_prefix+"meff",
  "Meff", 100,0.,elim);
  m_h_meff4j = m_HistSvc->book(m_foldername,m_prefix+"meff4j",
  "Meff", 100,0.,elim);
  m_h_meff4jcut = m_HistSvc->book(m_foldername,m_prefix+"meff4jcut",
  "Meff", 100,0.,elim);
  m_h_meff4jlep = m_HistSvc->book(m_foldername,m_prefix+"meff4jlep",
  "Meff", 100,0.,elim);
  m_h_mtlx = m_HistSvc->book(m_foldername,m_prefix+"mtlx",
  "MT(l,x)", 100,0.,200.);
  m_h_meff4jlepcut = m_HistSvc->book(m_foldername,m_prefix+"meff4jlepcut",
  "Meff", 100,0.,elim);

  mLog <<MSG::INFO <<"Initializing done" <<endreq;

  return StatusCode::SUCCESS;
}


//////////////////////////////////////////////////////////////////////
// Called by the algorithm to read collections from the store and   
// makes some plots.

StatusCode MyGlobalHistTool::takeAction() {  

  MsgStream mLog(msgSvc(), name());
  StatusCode sc;

  ////////////////////////////////////////
  /// Special particles
  ////////////////////////////////////////

  const TruthParticleContainer* spclTES;
  sc=m_pSG->retrieve( spclTES, m_spclMcName);
  if( sc.isFailure()  ||  !spclTES ) {
    mLog << MSG::WARNING
         << "No AOD SpclMC container found in TDS"
         << endreq;
    return StatusCode::SUCCESS;
  }

  for(TruthParticleContainer::const_iterator it = (*spclTES).begin();
  it != (*spclTES).end() ; ++it) {
    int ida = abs( (*it)->pdgId() );
    int idpre = ida/1000000;
    int id = ida%1000000;
    mLog <<MSG::VERBOSE
         <<"SUSY particle = "
         <<ida <<" " <<idpre <<" " <<id
         <<endreq;
    if( idpre == 0 ) m_h_susy0id->fill( (double)id, 1.);
    if( idpre == 1 ) m_h_susy1id->fill( (double)id, 1.);
    if( idpre == 2 ) m_h_susy2id->fill( (double)id, 1.);
  }

  ////////////////////////////////////////
  /// Missing ET, etc
  ////////////////////////////////////////

  const SusyGlobalObject* myEtmiss;
  sc=m_pSG->retrieve(myEtmiss,  m_inputCollection[susy::global] );
  if( sc.isFailure()  ||  !myEtmiss ) 
    {
      mLog << MSG::WARNING
	   << "No Global object found in TDS with key "
           <<m_inputCollection[susy::global]
	   << endreq; 
      return StatusCode::SUCCESS;
    }  

  const SusyGlobalObject* myEtmissMC;
  sc=m_pSG->retrieve(myEtmissMC,  m_inputCollection[susy::globalmc]);
  if( sc.isFailure()  ||  !myEtmissMC ) 
    {
      mLog << MSG::WARNING
	   << "No truth Global object found in TDS with key "
           << m_inputCollection[susy::globalmc]
	   << endreq; 
      return StatusCode::SUCCESS;
    }  

  const IParticleContainer* myJetsMC(0);
  sc=Get(susy::jetmc,myJetsMC);
  if(sc == StatusCode::FAILURE || !myJetsMC){
    return StatusCode::SUCCESS;
  }

  const IParticleContainer* myJets(0);
  sc=Get(susy::jet,myJets);
  if(sc == StatusCode::FAILURE || !myJets){
    return StatusCode::SUCCESS;
  }

  const MissingET* pMissing = 0;
  sc=m_pSG->retrieve(pMissing, m_metName);
  if( sc.isFailure()  ||  !pMissing ) {
    mLog << MSG::WARNING
        << "No missing Et object found in TDS with name "
        << m_metName
        << endreq;
    return StatusCode::SUCCESS;
  }

  const EventInfo* eventInfo;
  sc=m_pSG->retrieve( eventInfo );
  if( sc.isFailure()  ||  !eventInfo ) {
     mLog << MSG::WARNING
          << "No EventInfo found in TDS"
          << endreq;
     return StatusCode::SUCCESS;
  }  
  double wt = AtlasMcWeight::getEventWeight(*eventInfo);
  //mLog <<MSG::INFO <<"Weight = " <<wt <<endreq;
  if( wt > 0 ) wt = 1;
  if( wt < 0 ) wt = -1;

  /////////////////////////////////

  // Check etsum for bad events. See 
  // https://uimon.cern.ch/twiki/bin/view/Atlas/JetEtMValidation

  double etsum=myEtmiss->etsum();
  double etmiss=myEtmiss->etmiss();

  if( etsum < 0 ) return StatusCode::SUCCESS;

  // Default missing ET
  m_h_miss_etfinal->fill(pMissing->et()/GeV,wt);

  double phimiss = atan2( myEtmiss->pymiss(), myEtmiss->pxmiss() );
  double dphij0 = -M_PI;
  if( myJets->size() > 0 ) {
    dphij0 = fabs( ((*myJets)[0])->phi() - phimiss );
    if(dphij0 > M_PI) dphij0 = 2*M_PI - dphij0;
  }

  m_h_miss_ex->fill( myEtmiss->pxmiss()/GeV, wt);
  m_h_miss_ey->fill( myEtmiss->pymiss()/GeV, wt);
  m_h_miss_et->fill( etmiss/GeV, wt);
  if( dphij0 < 0.9*M_PI ) m_h_miss_etcut->fill( etmiss/GeV, wt);
  m_h_miss_etsum->fill( myEtmiss->etsum()/GeV, wt);

  double etmissmc = myEtmissMC->etmiss();
  double phimissmc = atan2( myEtmissMC->pymiss(), myEtmissMC->pxmiss() );
  double dphij0mc = -M_PI;
  if( myJetsMC->size() > 0 ) {
    dphij0mc = fabs( ((*myJetsMC)[0])->phi() - phimissmc );
    if(dphij0mc > M_PI) dphij0mc = 2*M_PI - dphij0mc;
  }

  m_h_mcmiss_ex->fill( myEtmissMC->pxmiss()/GeV, wt);
  m_h_mcmiss_ey->fill( myEtmissMC->pymiss()/GeV, wt);
  m_h_mcmiss_et->fill( etmissmc/GeV, wt);
  if( dphij0mc < 0.9*M_PI ) m_h_mcmiss_etcut->fill( etmissmc/GeV, wt);
  m_h_mcmiss_etsum->fill( myEtmissMC->etsum()/GeV, wt);

  double dexmiss = myEtmiss->pxmiss() - myEtmissMC->pxmiss();
  double deymiss = myEtmiss->pymiss() - myEtmissMC->pymiss();
  double detmiss = sqrt( dexmiss*dexmiss + deymiss*deymiss );
  double dphimiss = atan2(deymiss,dexmiss);
  double detsum = myEtmiss->etsum() - myEtmissMC->etsum();

  m_h_mcmiss_dex->fill( dexmiss/GeV, wt);
  m_h_mcmiss_dey->fill( deymiss/GeV, wt);
  m_h_mcmiss_det->fill( detmiss/GeV, wt);
  if( dphij0 < 0.9*M_PI ) m_h_mcmiss_detcut->fill( detmiss/GeV, wt);
  m_h_mcmiss_detsum->fill( detsum/GeV, wt);


  // Bad events
  // Plot distributions for MC jets with pt > 100GeV

  if( fabs(detmiss) > 100*GeV ) {

    if( myJetsMC->size() > 0 ) {
      IParticleContainer::const_iterator jmc = myJetsMC->begin();
      IParticleContainer::const_iterator jmcE = myJetsMC->end();
      double dphimin = 1000;
      double dphimax = -1000;
      double etamin = 1000;

      for(; jmc != jmcE; ++jmc) {
        if( (*jmc)->pt() < 100*GeV ) continue;
        m_h_mcmiss_jetet->fill( (*jmc)->pt()/GeV, wt);
        m_h_mcmiss_jeteta->fill( fabs((*jmc)->eta()), wt);
        double dphi = fabs((*jmc)->phi() - dphimiss);
        if(dphi > M_PI) dphi = 2*M_PI - dphi;
        if(dphi < dphimin) {
          dphimin = dphi;
          etamin = (*jmc)->eta();
        }
        if(dphi > dphimax) dphimax = dphi;
        m_h_mcmiss_jetdphi->fill(dphi/M_PI, wt);
      }

      m_h_mcmiss_jetphimin->fill( dphimin/M_PI, wt);
      m_h_mcmiss_jetphimax->fill( dphimax/M_PI, wt);
      if( etamin < 999. ) m_h_mcmiss_jetetamin->fill(etamin,wt);

    }
  }

  ////////////////////////////////////////
  /// Effective Mass
  ////////////////////////////////////////

  const IParticleContainer* myElectrons(0);
  sc=Get(susy::electron,myElectrons);
  if(sc == StatusCode::FAILURE){
    return StatusCode::FAILURE;
  }

  const IParticleContainer* myMuons(0);
  sc=Get(susy::muon,myMuons);
  if(sc == StatusCode::FAILURE  || !myMuons){
    return StatusCode::SUCCESS;
  }

  double meff = etmiss;
  int nlep = myElectrons->size() + myMuons->size();
  int n50 = 0;
  int n100 = 0;
  double ptlep = -1;
  double philep = 0;

  IParticleContainer::const_iterator itj = myJets->begin();
  for( ; itj != myJets->end(); ++itj ) {
    double pt = (*itj)->pt();
    meff += pt;
    if( pt > 50*GeV ) ++n50;
    if( pt > 100*GeV ) ++n100;
  }

  IParticleContainer::const_iterator itmu = myMuons->begin();
  for( ; itmu != myMuons->end(); ++itmu ) {
    double pt = (*itmu)->pt();
    meff += pt;
    if( pt > 50*GeV ) ++n50;
    if( pt > 100*GeV ) ++n100;
    if( pt > ptlep ) {
      ptlep = pt;
      philep = (*itmu)->phi();
    }
  }

  IParticleContainer::const_iterator ite = myElectrons->begin();
  for( ; ite != myElectrons->end(); ++ite ) {
    double pt = (*ite)->pt();
    meff += pt;
    if( pt > 50*GeV ) ++n50;
    if( pt > 100*GeV ) ++n100;
    if( pt > ptlep ) {
      ptlep = pt;
      philep = (*ite)->phi();
    }
  }

  // Effective mass with cuts

  if( etmiss > 100*GeV && etmiss > 0.2*meff ) {
    m_h_meff->fill(meff/GeV, wt);
    if( n100 >= 2 && n50 >= 4 ) {
      m_h_meff4j->fill(meff/GeV, wt);
      if( dphij0 < 0.9*M_PI ) m_h_meff4jcut->fill(meff/GeV, wt);

      // Meff for events with lepton
      // Veto M_T < M_W 
      if( nlep > 0 && ptlep > 0 ) {
        m_h_meff4jlep->fill(meff/GeV, wt);
        double dphilx = fabs(phimiss - philep);
        if( dphilx > M_PI ) dphilx = 2*M_PI - dphilx;
        double mtlx = sqrt(2*etmiss*ptlep*(1-cos(dphilx)));
        m_h_mtlx->fill(mtlx/GeV,wt);
        if( mtlx > 100*GeV ) m_h_meff4jlepcut->fill(meff/GeV,wt);
      }

    }
  }

  ////////////////////////////////////////
  /// Muons
  ////////////////////////////////////////

  const MuonContainer* muonTES = 0;
  sc=m_pSG->retrieve( muonTES, m_muonContainerName);
  if( sc.isFailure()  ||  !muonTES ) {
     mLog << MSG::WARNING
          << "No AOD muon container found in TDS with name "
          << m_muonContainerName
          << endreq;
     return StatusCode::SUCCESS;
  }

  const IParticleContainer* allMuonsMc(0);
  sc=m_pSG->retrieve( allMuonsMc, m_muonMcName);
  if( sc.isFailure()  ||  !allMuonsMc ) {
     mLog << MSG::WARNING
          << "No AOD muon container found in TDS with name "
          << m_muonMcName
          << endreq;
     return StatusCode::SUCCESS;
  }

  int mu50 = 0;
  for (MuonContainer::const_iterator it = (*muonTES).begin();
  it != (*muonTES).end() ; ++it) {
    bool pass=true;

    // Get rid of soft ones
    if( (*it)->author() != MuonParameters::highPt) pass=false;

    // chi2() is missing in 10.0.1, so get it indirectly:

    const Rec::TrackParticle* duh = (*it)->get_CombinedMuonTrackParticle();
    double chi2 = 1000;
    int mdthit = -1;
    if( duh ) {
      chi2 = duh->fitQuality()->chiSquared();
      int ndof =  duh->fitQuality()->numberDoF();
      if( ndof > 0 ) chi2 = chi2/ndof;
      if( chi2 > m_muonChi2Cut || ndof <= 0 ) pass=false;
      mdthit = (*it)->numberOfMDTHits();
      int mdtcut = mdthit;
      if( fabs((*it)->eta())>1.0 && fabs((*it)->eta())<1.4 ) mdtcut += 5;
      if( fabs((*it)->eta()) < 2.0 && mdtcut < m_muonMDTCut ) pass=false;
    } else {
      pass=false;
    }

    const Rec::TrackParticle* moo = (*it)->get_MuonExtrapolatedTrackParticle();
    if( moo && (*it)->pt() > 50*GeV ) {
      double moorat = moo->pt()/(*it)->pt();
      m_h_miss_mumoorat->fill(moorat, wt);
      if( fabs(moorat-1.0) > m_muonMooreCut ) pass=false;
    }

    if( pass ) {
      if( (*it)->pt()>50*GeV) ++mu50;
      m_h_miss_mupt->fill( (*it)->pt()/GeV, wt);
      m_h_miss_muchi2->fill(chi2, wt);
      m_h_miss_mueta->fill( fabs((*it)->eta()), wt);
      if( (*it)->pt()>50*GeV) m_h_miss_mueta50->fill( fabs((*it)->eta()), wt);
      const Rec::TrackParticle* foo = (*it)->get_InDetTrackParticle();
      if( foo ) {
        if( (*it)->pt()>50*GeV) {
          double rat = foo->pt() / (*it)->pt();
          m_h_miss_muidrat->fill(rat,wt);
          m_h_miss_mumdt->fill( (double)((*it)->numberOfMDTHits()), wt);

          int index = -1;
          double deltar;
          int pdgId = 0;
          bool ok = m_pAnalysisTools->matchR((*it), allMuonsMc, index,
                    deltar, pdgId);
          if( !ok ) deltar = 0.999;
          m_h_miss_mumcr->fill( deltar, wt );

          /*
          // Dump bad muons
          if( deltar > 0.2 ) {
            int run = eventInfo->event_ID()->run_number();
            int evt = eventInfo->event_ID()->event_number();
            mLog <<MSG::WARNING
                 <<"BAD MUON run,event,pt,eta,phi,mdthit = "
                 <<run <<" " <<evt <<" " 
                 <<(*it)->pt() <<" " <<(*it)->eta() <<" " <<(*it)->phi() <<" " 
                 <<mdthit
                 <<endreq;
          }
          */

        }
      }        
    }
  }
  m_h_miss_mun->fill( (float)mu50,wt);

  if( allMuonsMc->size() > 0 ) {
    IParticleContainer::const_iterator mumc  = allMuonsMc->begin();
    IParticleContainer::const_iterator mumcE = allMuonsMc->end();
    for( ; mumc != mumcE; ++mumc) {
      m_h_miss_mumcpt->fill( (*mumc)->pt()/GeV, wt );
    }
  }

  return StatusCode::SUCCESS;
}

