#include "SUSYPhysUser/mT2Fcn.h"

#include <math.h>
#include <string>

double mT2Fcn::operator()(const std::vector<double>& par) const {

  double qT1x = par[0];
  double qT1y = par[1];
      
  double qT2x = theExmiss - qT1x;
  double qT2y = theEymiss - qT1y;

  double ETj1 = hypot(thePT1x,thePT1y);
  double ETj2 = hypot(thePT2x,thePT2y);    

  double ETchi1 = sqrt(qT1x*qT1x + qT1y*qT1y + theMchi*theMchi);
  double ETchi2 = sqrt(qT2x*qT2x + qT2y*qT2y + theMchi*theMchi);

  double mTsq1 = theMchi*theMchi + 2.0*(ETj1*ETchi1 - (thePT1x*qT1x + thePT1y*qT1y));
  double mTsq2 = theMchi*theMchi + 2.0*(ETj2*ETchi2 - (thePT2x*qT2x + thePT2y*qT2y));
      
  return fmax(mTsq1,mTsq2);
      
}
