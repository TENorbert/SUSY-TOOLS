#include "SUSYPhysUser/MyLLHistTool.h"
#include "ParticleEvent/Muon.h"
#include "ParticleEvent/Electron.h"
#include "ParticleEvent/ParticleJet.h"

#include "CLHEP/Vector/LorentzVector.h"

#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/MsgStream.h"
#include <math.h>
#include <string>


//////////////////////////////////////////////////////////////////////
MyLLHistTool::MyLLHistTool(  const std::string& type,
					 const std::string& name,
					 const IInterface* parent )
  :  SusyObjectTool( type, name, parent)  
{
  // declare the interface for this tool
  declareInterface<ISusyObjectTool> (this); 

  declareProperty("PrefixName", m_prefix = "");
  declareProperty("SoftEName", m_softEName = "");
  declareProperty("SoftMuName", m_softMuName = "");
  declareProperty("PtHardCut", m_pthardcut = 50.*GeV);

}

MyLLHistTool::~MyLLHistTool() {}


//////////////////////////////////////////////////////////////////////
StatusCode MyLLHistTool::initialize() {
  SusyObjectTool::initialize();

  MsgStream log(msgSvc(), name());

  log << MSG::INFO << "Booking Histos in folder " << m_foldername << endreq;

  m_h_ee_Mllos = m_HistSvc->book(m_foldername,m_prefix+"ee_Mllos",
    "Mll",50,0.,200.);
  m_h_ee_Mllss = m_HistSvc->book(m_foldername,m_prefix+"ee_Mllss",
    "Mll",50,0.,200.);
  m_h_mumu_Mllos =  m_HistSvc->book(m_foldername,m_prefix+"mumu_Mllos",
    "Mll",50,0.,200.);
  m_h_mumu_Mllss =  m_HistSvc->book(m_foldername,m_prefix+"mumu_Mllss",
    "Mll",50,0.,200.);
  m_h_emu_Mllos =  m_HistSvc->book(m_foldername,m_prefix+"emu_Mllos",
    "Mll",50,0.,200.);
  m_h_emu_Mllss =  m_HistSvc->book(m_foldername,m_prefix+"emu_Mllss",
    "Mll",50,0.,200.);

  m_h_ee_pt =  m_HistSvc->book(m_foldername,m_prefix+"ee_pt",
    "pt",50,0.,200.);
  m_h_emu_pt =  m_HistSvc->book(m_foldername,m_prefix+"emu_pt",
    "pt",50,0.,200.);
  m_h_mumu_pt =  m_HistSvc->book(m_foldername,m_prefix+"mumu_pt",
    "pt",50,0.,200.);
  m_h_ee_pt21 =  m_HistSvc->book(m_foldername,m_prefix+"ee_pt21",
    "pt",50,0.,1.);
  m_h_emu_pt21 =  m_HistSvc->book(m_foldername,m_prefix+"emu_pt21",
    "pt",50,0.,1.);
  m_h_mumu_pt21 =  m_HistSvc->book(m_foldername,m_prefix+"mumu_pt21",
    "pt",50,0.,1.);

  m_h_ee_Mllq =  m_HistSvc->book(m_foldername,m_prefix+"ee_Mllq",
    "Mllq",50,0.,1000.);
  m_h_mumu_Mllq =  m_HistSvc->book(m_foldername,m_prefix+"mumu_Mllq",
    "Mllq",50,0.,1000.);
  m_h_emu_Mllq =  m_HistSvc->book(m_foldername,m_prefix+"emu_Mllq",
    "Mllq",50,0.,1000.);

  m_h_ee_Mlqmx =  m_HistSvc->book(m_foldername,m_prefix+"ee_Mlqmx",
    "Mlqmx",50,0.,1000.);
  m_h_mumu_Mlqmx =  m_HistSvc->book(m_foldername,m_prefix+"mumu_Mlqmx",
    "Mlqmx",50,0.,1000.);
  m_h_emu_Mlqmx =  m_HistSvc->book(m_foldername,m_prefix+"emu_Mlqmx",
    "Mlqmx",50,0.,1000.);

  m_h_ee_Mlqmn =  m_HistSvc->book(m_foldername,m_prefix+"ee_Mlqmn",
    "Mlqmn",50,0.,1000.);
  m_h_mumu_Mlqmn =  m_HistSvc->book(m_foldername,m_prefix+"mumu_Mlqmn",
    "Mlqmn",50,0.,1000.);
  m_h_emu_Mlqmn =  m_HistSvc->book(m_foldername,m_prefix+"emu_Mlqmn",
    "Mlqmn",50,0.,1000.);

  m_h_ee_Tllq =  m_HistSvc->book(m_foldername,m_prefix+"ee_Tllq",
    "Tllq",50,0.,1000.);
  m_h_mumu_Tllq =  m_HistSvc->book(m_foldername,m_prefix+"mumu_Tllq",
    "Tllq",50,0.,1000.);
  m_h_emu_Tllq =  m_HistSvc->book(m_foldername,m_prefix+"emu_Tllq",
    "Tllq",50,0.,1000.);

  m_h_ee_MlqmxR =  m_HistSvc->book(m_foldername,m_prefix+"ee_MlqmxR",
    "Mlq",50,0.,1000.);
  m_h_ee_MlqmxL =  m_HistSvc->book(m_foldername,m_prefix+"ee_MlqmxL",
    "Mlq",50,0.,1000.);
  m_h_mumu_MlqmxR =  m_HistSvc->book(m_foldername,m_prefix+"mumu_MlqmxR",
    "Mlq",50,0.,1000.);
  m_h_mumu_MlqmxL =  m_HistSvc->book(m_foldername,m_prefix+"mumu_MlqmxL",
    "Mlq",50,0.,1000.);
  m_h_emu_MlqmxR =  m_HistSvc->book(m_foldername,m_prefix+"emu_MlqmxR",
    "Mlq",50,0.,1000.);
  m_h_emu_MlqmxL =  m_HistSvc->book(m_foldername,m_prefix+"emu_MlqmxL",
    "Mlq",50,0.,1000.);
  m_h_ee_MlqmnR =  m_HistSvc->book(m_foldername,m_prefix+"ee_MlqmnR",
    "Mlq",50,0.,1000.);
  m_h_ee_MlqmnL =  m_HistSvc->book(m_foldername,m_prefix+"ee_MlqmnL",
    "Mlq",50,0.,1000.);
  m_h_mumu_MlqmnR =  m_HistSvc->book(m_foldername,m_prefix+"mumu_MlqmnR",
    "Mlq",50,0.,1000.);
  m_h_mumu_MlqmnL =  m_HistSvc->book(m_foldername,m_prefix+"mumu_MlqmnL",
    "Mlq",50,0.,1000.);
  m_h_emu_MlqmnR =  m_HistSvc->book(m_foldername,m_prefix+"emu_MlqmnR",
    "Mlq",50,0.,1000.);
  m_h_emu_MlqmnL =  m_HistSvc->book(m_foldername,m_prefix+"emu_MlqmnL",
    "Mlq",50,0.,1000.);


  return StatusCode::SUCCESS;
}


//////////////////////////////////////////////////////////////////////
StatusCode MyLLHistTool::takeAction() {  

  MsgStream mLog(msgSvc(), name());

  const IParticleContainer* myMuons(0);
  StatusCode sc=Get(susy::muon,myMuons);
  if(sc == StatusCode::FAILURE){
    return StatusCode::FAILURE;
  }
  const IParticleContainer* myElectrons(0);
  sc=Get(susy::electron,myElectrons);
  if(sc == StatusCode::FAILURE){
    return StatusCode::FAILURE;
  }
  const IParticleContainer* myJets(0);
  sc=Get(susy::jet,myJets);
  if(sc == StatusCode::FAILURE){
    return StatusCode::FAILURE;
  }

  // Soft electrons and muons
  const IParticleContainer* softElectrons(0);
  sc=m_pSG->retrieve(softElectrons, m_softEName );
  if(sc == StatusCode::FAILURE){
    mLog <<MSG::WARNING <<"Did not find soft electrons named " 
         <<m_softEName <<endreq;
    return StatusCode::FAILURE;
  }

  const IParticleContainer* softMuons(0);
  sc=m_pSG->retrieve(softMuons, m_softMuName );
  if(sc == StatusCode::FAILURE){
    mLog <<MSG::WARNING <<"Did not find soft muons named " 
         <<m_softMuName <<endreq;
    return StatusCode::FAILURE;
  }

  int ne = myElectrons->size();
  int nmu = myMuons->size();
  int nsofte = softElectrons->size();
  int nsoftmu = softMuons->size();
  // Soft electrons/muons should contain all of them
  if( nsofte+nsoftmu < 2 ) return StatusCode::SUCCESS;
  if( myJets->size() < 2 ) return StatusCode::SUCCESS;

  // We treat electrons and muons separately because of the different
  // efficiencies.
  // Given a fixed interface, where should we put a function to make the
  // various l+l- + jet combinations??

  // Dilepton edges
  double edgeL = 58.191*GeV;
  double edgeR = 100.896*GeV;

  // Electron-electron
  // Use track to define electron eta-phi

  for(int i=0; i<ne; ++i) {
    const Electron* ei = dynamic_cast<const Electron*>((*myElectrons)[i]);
    if( ! ei->hasTrack() ) continue;
    double pti = ei->pt();
    double etai = ei->track()->eta();
    double phii = ei->track()->phi();
    HepLorentzVector hlvi(pti*cos(phii),pti*sin(phii),pti*sinh(etai),
                          pti*cosh(etai));
    for(int j=i+1; j<ne; ++j) {
      const Electron* ej = dynamic_cast<const Electron*>((*myElectrons)[j]);
      if( ! ej->hasTrack() ) continue;
      double ptj = ej->pt();
      double etaj = ej->track()->eta();
      double phij = ej->track()->phi();
      if( pti < m_pthardcut && ptj < m_pthardcut ) continue;
      HepLorentzVector hlvj(ptj*cos(phij),ptj*sin(phij),ptj*sinh(etaj),
                            ptj*cosh(etaj));
      HepLorentzVector pij = hlvi+hlvj;
      bool osij = false;
      if((*myElectrons)[i]->charge()*(*myElectrons)[j]->charge() < 0) {
        osij = true;
      }
      if( osij ) {
        m_h_ee_Mllos->fill( pij.m()/GeV, 1.);
        double ptmax = (pti>ptj) ? pti : ptj;
        m_h_ee_pt->fill(ptmax/GeV,1.);
        double ptrat = (pti>ptj) ? ptj/pti : pti/ptj;
        m_h_ee_pt21->fill(ptrat,1.);
      } else {
        m_h_ee_Mllss->fill( pij.m()/GeV, 1.);
      }
      // Combine OS pair with two hardest jets
      if( osij ) {
        double mllq,mlqmx,mlqmn,tllq;
        llqComb(hlvi,hlvj,myJets,mllq,mlqmx,mlqmn,tllq);
        m_h_ee_Mllq->fill(mllq/GeV,1.);
        m_h_ee_Mlqmx->fill(mlqmx/GeV,1.);
        m_h_ee_Mlqmn->fill(mlqmn/GeV,1.);
        if( pij.m()>50*GeV ) m_h_ee_Tllq->fill(tllq/GeV,1.);
        if( pij.m() < edgeL ) {
          m_h_ee_MlqmxL->fill(mlqmx/GeV,1.);
          m_h_ee_MlqmnL->fill(mlqmn/GeV,1.);
        } else if ( pij.m() < edgeR ) {
            m_h_ee_MlqmxR->fill(mlqmx/GeV,1.);
            m_h_ee_MlqmnR->fill(mlqmn/GeV,1.);
        }
      }
    }
  }   

  // Add non-overlapping soft electrons
  for(int i=0; i<nsofte; ++i) {
    int index = -1;
    double deltaRMatch = 0;
    int pdgId = 0;
    bool findAMatch = m_pAnalysisTools->matchR( (*softElectrons)[i],
    myElectrons, index, deltaRMatch, pdgId);
    if( deltaRMatch<0.1 ) continue;
    const Electron* ei = dynamic_cast<const Electron*>((*softElectrons)[i]);
    if( ! ei->hasTrack() ) continue;
    double pti = ei->pt();
    double etai = ei->track()->eta();
    double phii = ei->track()->phi();
    HepLorentzVector hlvi(pti*cos(phii),pti*sin(phii),pti*sinh(etai),
                          pti*cosh(etai));
    for(int j=0; j<ne; ++j) {
      const Electron* ej = dynamic_cast<const Electron*>((*myElectrons)[j]);
      if( ! ej->hasTrack() ) continue;
      double ptj = ej->pt();
      double etaj = ej->track()->eta();
      double phij = ej->track()->phi();
      if( pti < m_pthardcut && ptj < m_pthardcut ) continue;
      HepLorentzVector hlvj(ptj*cos(phij),ptj*sin(phij),ptj*sinh(etaj),
                            ptj*cosh(etaj));
      HepLorentzVector pij = hlvi+hlvj;
      bool osij = false;
      if((*softElectrons)[i]->charge()*(*myElectrons)[j]->charge() < 0) {
        osij = true;
      }
      if( osij ) {
        m_h_ee_Mllos->fill( pij.m()/GeV, 1.);
        double ptmax = (pti>ptj) ? pti : ptj;
        m_h_ee_pt->fill(ptmax/GeV,1.);
        double ptrat = (pti>ptj) ? ptj/pti : pti/ptj;
        m_h_ee_pt21->fill(ptrat,1.);
      } else {
        m_h_ee_Mllss->fill( pij.m()/GeV, 1.);
      }
      // Combine OS pair with two hardest jets
      if( osij ) {
        double mllq,mlqmx,mlqmn,tllq;
        llqComb(hlvi,hlvj,myJets,mllq,mlqmx,mlqmn,tllq);
        m_h_ee_Mllq->fill(mllq/GeV,1.);
        m_h_ee_Mlqmx->fill(mlqmx/GeV,1.);
        m_h_ee_Mlqmn->fill(mlqmn/GeV,1.);
        if( pij.m()>50*GeV ) m_h_ee_Tllq->fill(tllq/GeV,1.);
        if( pij.m() < edgeL ) {
          m_h_ee_MlqmxL->fill(mlqmx/GeV,1.);
          m_h_ee_MlqmnL->fill(mlqmn/GeV,1.);
        } else if ( pij.m() < edgeR ) {
            m_h_ee_MlqmxR->fill(mlqmx/GeV,1.);
            m_h_ee_MlqmnR->fill(mlqmn/GeV,1.);
        }
      }
    }
  }   

  // Muon-muon

  for(int i=0; i<nmu; ++i) {
    double pti = (*myMuons)[i]->pt();
    HepLorentzVector hlvi = (*myMuons)[i]->hlv();
    for(int j=i+1; j<nmu; ++j) {
      double ptj = (*myMuons)[j]->pt();
      if( pti < m_pthardcut && ptj < m_pthardcut ) continue;
      HepLorentzVector hlvj = (*myMuons)[j]->hlv();
      HepLorentzVector pij = hlvi+hlvj;
      bool osij = false;
      if((*myMuons)[i]->charge()*(*myMuons)[j]->charge() < 0) {
        osij = true;
      }
      if( osij ) {
        m_h_mumu_Mllos->fill( pij.m()/GeV, 1.);
        double ptmax = (pti>ptj) ? pti : ptj;
        m_h_mumu_pt->fill(ptmax/GeV,1.);
        double ptrat = (pti>ptj) ? ptj/pti : pti/ptj;
        m_h_mumu_pt21->fill(ptrat,1.);
      } else {
        m_h_mumu_Mllss->fill( pij.m()/GeV, 1.);
      }
      // Combine OS pair with two hardest jets
      if( osij ) {
        double mllq,mlqmx,mlqmn,tllq;
        llqComb(hlvi,hlvj,myJets,mllq,mlqmx,mlqmn,tllq);
        m_h_mumu_Mllq->fill(mllq/GeV,1.);
        m_h_mumu_Mlqmx->fill(mlqmx/GeV,1.);
        m_h_mumu_Mlqmn->fill(mlqmn/GeV,1.);
        if( pij.m()>50*GeV ) m_h_mumu_Tllq->fill(tllq/GeV,1.);
        if( pij.m() < edgeL ) {
          m_h_mumu_MlqmxL->fill(mlqmx/GeV,1.);
          m_h_mumu_MlqmnL->fill(mlqmn/GeV,1.);
        } else if ( pij.m() < edgeR ) {
            m_h_mumu_MlqmxR->fill(mlqmx/GeV,1.);
            m_h_mumu_MlqmnR->fill(mlqmn/GeV,1.);
        }
      }
    }
  }   

  // Add non-overlapping soft muons
  for(int i=0; i<nsoftmu; ++i) {
    int index = -1;
    double deltaRMatch = 0;
    int pdgId = 0;
    bool findAMatch = m_pAnalysisTools->matchR( (*softMuons)[i],
    myMuons, index, deltaRMatch, pdgId);
    if( deltaRMatch<0.1 ) continue;
    double pti = (*softMuons)[i]->pt();
    HepLorentzVector hlvi = (*softMuons)[i]->hlv();
    for(int j=0; j<nmu; ++j) {
      double ptj = (*myMuons)[j]->pt();
      if( pti < m_pthardcut && ptj < m_pthardcut ) continue;
      HepLorentzVector hlvj = (*myMuons)[j]->hlv();
      HepLorentzVector pij = hlvi+hlvj;
      bool osij = false;
      if((*softMuons)[i]->charge()*(*myMuons)[j]->charge() < 0) {
        osij = true;
      }
      if( osij ) {
        m_h_mumu_Mllos->fill( pij.m()/GeV, 1.);
        double ptmax = (pti>ptj) ? pti : ptj;
        m_h_mumu_pt->fill(ptmax/GeV,1.);
        double ptrat = (pti>ptj) ? ptj/pti : pti/ptj;
        m_h_mumu_pt21->fill(ptrat,1.);
      } else {
        m_h_mumu_Mllss->fill( pij.m()/GeV, 1.);
      }
      // Combine OS pair with two hardest jets
      if( osij ) {
        double mllq,mlqmx,mlqmn,tllq;
        llqComb(hlvi,hlvj,myJets,mllq,mlqmx,mlqmn,tllq);
        m_h_mumu_Mllq->fill(mllq/GeV,1.);
        m_h_mumu_Mlqmx->fill(mlqmx/GeV,1.);
        m_h_mumu_Mlqmn->fill(mlqmn/GeV,1.);
        if( pij.m()>50*GeV ) m_h_mumu_Tllq->fill(tllq/GeV,1.);
        if( pij.m() < edgeL ) {
          m_h_mumu_MlqmxL->fill(mlqmx/GeV,1.);
          m_h_mumu_MlqmnL->fill(mlqmn/GeV,1.);
        } else if ( pij.m() < edgeR ) {
            m_h_mumu_MlqmxR->fill(mlqmx/GeV,1.);
            m_h_mumu_MlqmnR->fill(mlqmn/GeV,1.);
        }
      }
    }
  }   

  // Electron-muon

  for(int i=0; i<ne; ++i) {
    const Electron* ei = dynamic_cast<const Electron*>((*myElectrons)[i]);
    if( ! ei->hasTrack() ) continue;
    double pti = ei->pt();
    double etai = ei->track()->eta();
    double phii = ei->track()->phi();
    HepLorentzVector hlvi(pti*cos(phii),pti*sin(phii),pti*sinh(etai),
                          pti*cosh(etai));
    for(int j=0; j<nmu; ++j) {
      double ptj = (*myMuons)[j]->pt();
      if( pti < m_pthardcut && ptj < m_pthardcut ) continue;
      HepLorentzVector hlvj = (*myMuons)[j]->hlv();
      HepLorentzVector pij = hlvi+hlvj;
      bool osij = false;
      if((*myElectrons)[i]->charge()*(*myMuons)[j]->charge() < 0) {
        osij = true;
      }
      if( osij ) {
        m_h_emu_Mllos->fill( pij.m()/GeV, 1.);
        double ptmax = (pti>ptj) ? pti : ptj;
        m_h_emu_pt->fill(ptmax/GeV,1.);
        double ptrat = (pti>ptj) ? ptj/pti : pti/ptj;
        m_h_emu_pt21->fill(ptrat,1.);
      } else {
        m_h_emu_Mllss->fill( pij.m()/GeV, 1.);
      }
      // Combine OS pair with two hardest jets
      if( osij ) {
        double mllq,mlqmx,mlqmn,tllq;
        llqComb(hlvi,hlvj,myJets,mllq,mlqmx,mlqmn,tllq);
        m_h_emu_Mllq->fill(mllq/GeV,1.);
        m_h_emu_Mlqmx->fill(mlqmx/GeV,1.);
        m_h_emu_Mlqmn->fill(mlqmn/GeV,1.);
        if( pij.m()>50*GeV ) m_h_emu_Tllq->fill(tllq/GeV,1.);
        if( pij.m() < edgeL ) {
          m_h_emu_MlqmxL->fill(mlqmx/GeV,1.);
          m_h_emu_MlqmnL->fill(mlqmn/GeV,1.);
        } else if ( pij.m() < edgeR ) {
            m_h_emu_MlqmxR->fill(mlqmx/GeV,1.);
            m_h_emu_MlqmnR->fill(mlqmn/GeV,1.);
        }
      }
    }
  }

  // Add non-overlapping soft electrons
  for(int i=0; i<nsofte; ++i) {
    int index = -1;
    double deltaRMatch = 0;
    int pdgId = 0;
    bool findAMatch = m_pAnalysisTools->matchR( (*softElectrons)[i],
    myElectrons, index, deltaRMatch, pdgId);
    if( deltaRMatch<0.1 ) continue;
    const Electron* ei = dynamic_cast<const Electron*>((*softElectrons)[i]);
    if( ! ei->hasTrack() ) continue;
    double pti = ei->pt();
    double etai = ei->track()->eta();
    double phii = ei->track()->phi();
    HepLorentzVector hlvi(pti*cos(phii),pti*sin(phii),pti*sinh(etai),
                          pti*cosh(etai));
    for(int j=0; j<nmu; ++j) {
      double ptj = (*myMuons)[j]->pt();
      if( pti < m_pthardcut && ptj < m_pthardcut ) continue;
      HepLorentzVector hlvj = (*myMuons)[j]->hlv();
      HepLorentzVector pij = hlvi+hlvj;
      bool osij = false;
      if((*softElectrons)[i]->charge()*(*myMuons)[j]->charge() < 0) {
        osij = true;
      }
      if( osij ) {
        m_h_emu_Mllos->fill( pij.m()/GeV, 1.);
        double ptmax = (pti>ptj) ? pti : ptj;
        m_h_emu_pt->fill(ptmax/GeV,1.);
        double ptrat = (pti>ptj) ? ptj/pti : pti/ptj;
        m_h_emu_pt21->fill(ptrat,1.);
      } else {
        m_h_emu_Mllss->fill( pij.m()/GeV, 1.);
      }
      // Combine OS pair with two hardest jets
      if( osij ) {
        double mllq,mlqmx,mlqmn,tllq;
        llqComb(hlvi,hlvj,myJets,mllq,mlqmx,mlqmn,tllq);
        m_h_emu_Mllq->fill(mllq/GeV,1.);
        m_h_emu_Mlqmx->fill(mlqmx/GeV,1.);
        m_h_emu_Mlqmn->fill(mlqmn/GeV,1.);
        if( pij.m()>50*GeV ) m_h_emu_Tllq->fill(tllq/GeV,1.);
        if( pij.m() < edgeL ) {
          m_h_emu_MlqmxL->fill(mlqmx/GeV,1.);
          m_h_emu_MlqmnL->fill(mlqmn/GeV,1.);
        } else if ( pij.m() < edgeR ) {
            m_h_emu_MlqmxR->fill(mlqmx/GeV,1.);
            m_h_emu_MlqmnR->fill(mlqmn/GeV,1.);
        }
      }
    }
  }   

  // Add non-overlapping soft muons
  for(int i=0; i<nsoftmu; ++i) {
    int index = -1;
    double deltaRMatch = 0;
    int pdgId = 0;
    bool findAMatch = m_pAnalysisTools->matchR( (*softMuons)[i],
    myMuons, index, deltaRMatch, pdgId);
    if( deltaRMatch<0.1 ) continue;
    double pti = (*softMuons)[i]->pt();
    HepLorentzVector hlvi = (*softMuons)[i]->hlv();
    for(int j=0; j<ne; ++j) {
      const Electron* ej = dynamic_cast<const Electron*>((*myElectrons)[j]);
      if( ! ej->hasTrack() ) continue;
      double ptj = ej->pt();
      double etaj = ej->track()->eta();
      double phij = ej->track()->phi();
      if( pti < m_pthardcut && ptj < m_pthardcut ) continue;
      HepLorentzVector hlvj(ptj*cos(phij),ptj*sin(phij),ptj*sinh(etaj),
                            ptj*cosh(etaj));
      HepLorentzVector pij = hlvi+hlvj;
      bool osij = false;
      if((*softMuons)[i]->charge()*(*myElectrons)[j]->charge() < 0) {
        osij = true;
      }
      if( osij ) {
        m_h_emu_Mllos->fill( pij.m()/GeV, 1.);
        double ptmax = (pti>ptj) ? pti : ptj;
        m_h_emu_pt->fill(ptmax/GeV,1.);
        double ptrat = (pti>ptj) ? ptj/pti : pti/ptj;
        m_h_emu_pt21->fill(ptrat,1.);
      } else {
        m_h_emu_Mllss->fill( pij.m()/GeV, 1.);
      }
      // Combine OS pair with two hardest jets
      if( osij ) {
        double mllq,mlqmx,mlqmn,tllq;
        llqComb(hlvi,hlvj,myJets,mllq,mlqmx,mlqmn,tllq);
        m_h_emu_Mllq->fill(mllq/GeV,1.);
        m_h_emu_Mlqmx->fill(mlqmx/GeV,1.);
        m_h_emu_Mlqmn->fill(mlqmn/GeV,1.);
        if( pij.m()>50*GeV ) m_h_emu_Tllq->fill(tllq/GeV,1.);
        if( pij.m() < edgeL ) {
          m_h_emu_MlqmxL->fill(mlqmx/GeV,1.);
          m_h_emu_MlqmnL->fill(mlqmn/GeV,1.);
        } else if ( pij.m() < edgeR ) {
            m_h_emu_MlqmxR->fill(mlqmx/GeV,1.);
            m_h_emu_MlqmnR->fill(mlqmn/GeV,1.);
        }
      }
    }
  }

  return StatusCode::SUCCESS;
}

//////////////////////////////////////////////////////////////////////
// l+ l- + jet combinations. See TDR and Cambridge analyses
// Also hard and soft lq combinations for pure lR~ region (Luc Pape)
//////////////////////////////////////////////////////////////////////

void MyLLHistTool::llqComb(const HepLorentzVector& ell0, 
const HepLorentzVector& ell1, const IParticleContainer* jets, 
double& mllq, double& mlqmx, double& mlqmn, double& tllq) {

  double mll = ( ell0 + ell1 ).m();
  double mllq0 = ( ell0 + ell1 + (*jets)[0]->hlv() ).m();
  double mllq1 = ( ell0 + ell1 + (*jets)[1]->hlv() ).m();
  HepLorentzVector pj;
  double mllqmax;

  if( mllq0<mllq1 ) {
    mllq = mllq0;    
    pj = (*jets)[0]->hlv();
    mllqmax = mllq1;
  } else {
    mllq = mllq1;
    pj = (*jets)[1]->hlv();
    mllqmax = mllq0;
  }

  double m0 = ( ell0 + pj ).m();
  double m1 = ( ell1 + pj ).m();
  mlqmx = (m0>m1) ? m0 : m1;
  mlqmn = (m0<m1) ? m0 : m1;

  tllq = (mllq0>mllq1) ? mllq0 : mllq1;

}

