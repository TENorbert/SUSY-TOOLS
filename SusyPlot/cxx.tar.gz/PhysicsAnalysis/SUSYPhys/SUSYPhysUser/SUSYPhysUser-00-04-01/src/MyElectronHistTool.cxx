// Simple SUSY electron plot
// Ian Hinchliffe 
// Sept 2004

#include "SUSYPhysUser/MyElectronHistTool.h"
#include "ParticleEvent/Electron.h"
#include "ParticleEvent/ElectronParamDefs.h"
#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "GaudiKernel/MsgStream.h"
#include "CLHEP/Vector/LorentzVector.h"
#include <math.h>
#include <string>


MyElectronHistTool::MyElectronHistTool(  const std::string& type,
					 const std::string& name,
					 const IInterface* parent )
  :  SusyObjectTool( type, name, parent)  
{
  // declare the interface for this tool
  declareInterface<ISusyObjectTool> (this); 
  // Here the properties which are specife to this hist 
}


MyElectronHistTool::~MyElectronHistTool() {}

// Initialize method. 
StatusCode MyElectronHistTool::initialize() {
  SusyObjectTool::initialize();
  MsgStream log(msgSvc(), name());
  log << MSG::INFO << "Booking Histos in folder " << m_foldername << endreq;

  m_h_e_n =  m_HistSvc->book(m_foldername,m_prefix+"e_n",
    "N electron",20,0.,20.);
  m_h_e_pt1 =  m_HistSvc->book(m_foldername,m_prefix+"e_pt1",
    "pt1",50,0.,250.);
  m_h_e_pt =  m_HistSvc->book(m_foldername,m_prefix+"e_pt",
    "pt",50,0.,250.);
  m_h_e_ptplus =  m_HistSvc->book(m_foldername,m_prefix+"e_ptplus",
    "pt",50,0.,250.);
  m_h_e_ptminus =  m_HistSvc->book(m_foldername,m_prefix+"e_ptminus",
    "pt",50,0.,250.);
  m_h_e_eta =  m_HistSvc->book(m_foldername,m_prefix+"e_eta",
    "eta",50,0.,5.);
  m_h_e_eta20 =  m_HistSvc->book(m_foldername,m_prefix+"e_eta20",
    "eta",50,0.,5.);
  m_h_e_eta50 =  m_HistSvc->book(m_foldername,m_prefix+"e_eta50",
    "eta",50,0.,5.);
  m_h_softept =  m_HistSvc->book(m_foldername,m_prefix+"e_ptsoft",
    "pt",50,0.,250.);
  m_h_softeeta =  m_HistSvc->book(m_foldername,m_prefix+"e_etasoft",
    "eta",50,0.,5.);


  return StatusCode::SUCCESS;
}


// Called by the algorithm to read collections from the store and   makes some plots.


StatusCode MyElectronHistTool::takeAction() {  

  MsgStream mLog(msgSvc(), name());

  const IParticleContainer* myElectrons(0);
  StatusCode sc=Get(susy::electron,myElectrons);
  if(sc == StatusCode::FAILURE){
    mLog << MSG::WARNING
         << "No electron container found with name "
         << susy::electron
         << endreq;
    return StatusCode::FAILURE;
  }

  if (myElectrons->size() >0) {
    m_h_e_pt1->fill((*(myElectrons->begin()))->pt()/GeV,1.);
  }

  int nElectron15 = 0;
  for (IParticleContainer::const_iterator thiselectron = myElectrons->begin();
  thiselectron != myElectrons->end(); ++thiselectron){
    double ptj = (*thiselectron)->pt();
    double etaaj = fabs( (*thiselectron)->eta() );
    m_h_e_eta->fill(etaaj,1.);
    if(ptj > 20*GeV) m_h_e_eta20->fill(etaaj,1.);
    if(ptj > 50*GeV) m_h_e_eta50->fill(etaaj,1.);
    m_h_e_pt->fill(ptj/GeV,1.);
    if( (*thiselectron)->charge() > 0 ) m_h_e_ptplus->fill(ptj/GeV,1.);
    if( (*thiselectron)->charge() < 0 ) m_h_e_ptminus->fill(ptj/GeV,1.);
    if(ptj>15*GeV) ++nElectron15;
    const Electron* electron = dynamic_cast< const Electron* >(*thiselectron);
    if(electron->author() == ElectronParameters::softe) {
      m_h_softept->fill(electron->pt()/GeV,1.);
      m_h_softeeta->fill(electron->eta(),1.);      
    }
  }
  m_h_e_n->fill((double)nElectron15,1.);
  


   return StatusCode::SUCCESS;
}

