/***********************************************************************
Filename : MyJetTruthHistTool.cxx
Author   : Frank Paige
Created  : September 2004

Tool to make histograms of jet kinematics.
***********************************************************************/

#include "SUSYPhysUser/MyJetTruthHistTool.h"
#include "AIDA/IHistogram1D.h"
#include "AIDA/IHistogram2D.h"
#include "AIDA/IProfile1D.h"
#include "GaudiKernel/MsgStream.h"
#include <math.h>
#include <string>

//////////////////////////////////////////////////////////////////////
MyJetTruthHistTool::MyJetTruthHistTool( const std::string& type,
                                            const std::string& name,
                                            const IInterface* parent )
  : SusyObjectTool( type, name, parent)
{
  declareInterface<ISusyObjectTool> (this);

  declareProperty("PrefixName", m_prefix = "");
  declareProperty("JetEtCut", m_etJetStandardCut = 15.0*GeV);
  declareProperty("JetMatchCone", m_maxDeltaRMatchCut = 0.1);
}

MyJetTruthHistTool::~MyJetTruthHistTool()
{}

//////////////////////////////////////////////////////////////////////
StatusCode MyJetTruthHistTool::initialize() 
{
  SusyObjectTool::initialize();

  MsgStream mLog(msgSvc(), name());

  mLog << MSG::INFO << "in initialize()" << endreq;

  StatusCode sc = StatusCode::SUCCESS;

  /// Book jet histograms with optional folder name
  /// WARNING: A histogram which is declared but not book will produce
  /// a segmentation violation with no useful traceback from athena.py.

  m_h_mcjet_n = m_HistSvc->book(m_foldername,m_prefix+"mcjet_n",
    "N jet",20,0.,20.);
  m_h_mcjet_et = m_HistSvc->book(m_foldername,m_prefix+"mcjet_et",
    "ET jet",100,0.,500.);
  m_h_mcjet_eta10 = m_HistSvc->book(m_foldername,m_prefix+"mcjet_eta10",
    "eta jet10",100,0.,5.);
  m_h_mcjet_eta20 = m_HistSvc->book(m_foldername,m_prefix+"mcjet_eta20",
    "eta jet20",100,0.,5.);
  m_h_mcjet_eta50 = m_HistSvc->book(m_foldername,m_prefix+"mcjet_eta50",
    "eta jet50",100,0.,5.);
  m_h_mcjet_eta100 = m_HistSvc->book(m_foldername,m_prefix+"mcjet_eta100",
    "eta jet100",100,0.,5.);
  m_h_mcjet_rmatch = m_HistSvc->book(m_foldername,m_prefix+"mcjet_rmatch",
    "R match",100,0,1.);

  // Resolution histograms
  m_h_mcjet_etres[0]  = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etres0020",
    "ETres",100,0.,2.);
  m_h_mcjet_etres[1] =  m_HistSvc->book(m_foldername,m_prefix+"mcjet_etres0030",
    "ETres",100,0.,2.);
  m_h_mcjet_etres[2]  = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etres0040",
    "ETres",100,0.,2.);
  m_h_mcjet_etres[3]  = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etres0060",
    "ETres",100,0.,2.);
  m_h_mcjet_etres[4]  = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etres0080",
    "ETres",100,0.,2.);
  m_h_mcjet_etres[5]  = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etres0120",
    "ETres",100,0.,2.);
  m_h_mcjet_etres[6]  = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etres0160",
    "ETres",100,0.,2.);
  m_h_mcjet_etres[7]  = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etres0240",
    "ETres",100,0.,2.);
  m_h_mcjet_etres[8]  = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etres0320",
    "ETres",100,0.,2.);
  m_h_mcjet_etres[9]  = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etres0480",
    "ETres",100,0.,2.);
  m_h_mcjet_etres[10] = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etres0640",
    "ETres",100,0.,2.);
  m_h_mcjet_etres[11] = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etres0960",
    "ETres",100,0.,2.);
  m_h_mcjet_etres[12] = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etres1280",
    "ETres",100,0.,2.);
  m_h_mcjet_etres[13] = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etres1920",
    "ETres",100,0.,2.);
  m_h_mcjet_etres[14] = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etres2560",
    "ETres",100,0.,2.);
  m_h_mcjet_etres[15] = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etres3840",
    "ETres",100,0.,2.);

  // Eta profile histograms histograms
  m_h_mcjet_etprof[0]  = m_HistSvc->bookProf(m_foldername,m_prefix+"mcjet_etprof0020",
    "ETprof",50,0.,5.);
  m_h_mcjet_etprof[1] =  m_HistSvc->bookProf(m_foldername,m_prefix+"mcjet_etprof0030",
    "ETprof",50,0.,5.);
  m_h_mcjet_etprof[2]  = m_HistSvc->bookProf(m_foldername,m_prefix+"mcjet_etprof0040",
    "ETprof",50,0.,5.);
  m_h_mcjet_etprof[3]  = m_HistSvc->bookProf(m_foldername,m_prefix+"mcjet_etprof0060",
    "ETprof",50,0.,5.);
  m_h_mcjet_etprof[4]  = m_HistSvc->bookProf(m_foldername,m_prefix+"mcjet_etprof0080",
    "ETprof",50,0.,5.);
  m_h_mcjet_etprof[5]  = m_HistSvc->bookProf(m_foldername,m_prefix+"mcjet_etprof0120",
    "ETprof",50,0.,5.);
  m_h_mcjet_etprof[6]  = m_HistSvc->bookProf(m_foldername,m_prefix+"mcjet_etprof0160",
    "ETprof",50,0.,5.);
  m_h_mcjet_etprof[7]  = m_HistSvc->bookProf(m_foldername,m_prefix+"mcjet_etprof0240",
    "ETprof",50,0.,5.);
  m_h_mcjet_etprof[8]  = m_HistSvc->bookProf(m_foldername,m_prefix+"mcjet_etprof0320",
    "ETprof",50,0.,5.);
  m_h_mcjet_etprof[9]  = m_HistSvc->bookProf(m_foldername,m_prefix+"mcjet_etprof0480",
    "ETprof",50,0.,5.);
  m_h_mcjet_etprof[10] = m_HistSvc->bookProf(m_foldername,m_prefix+"mcjet_etprof0640",
    "ETprof",50,0.,5.);
  m_h_mcjet_etprof[11] = m_HistSvc->bookProf(m_foldername,m_prefix+"mcjet_etprof0960",
    "ETprof",50,0.,5.);
  m_h_mcjet_etprof[12] = m_HistSvc->bookProf(m_foldername,m_prefix+"mcjet_etprof1280",
    "ETprof",50,0.,5.);
  m_h_mcjet_etprof[13] = m_HistSvc->bookProf(m_foldername,m_prefix+"mcjet_etprof1920",
    "ETprof",50,0.,5.);
  m_h_mcjet_etprof[14] = m_HistSvc->bookProf(m_foldername,m_prefix+"mcjet_etprof2560",
    "ETprof",50,0.,5.);
  m_h_mcjet_etprof[15] = m_HistSvc->bookProf(m_foldername,m_prefix+"mcjet_etprof3840",
    "ETprof",50,0.,5.);

  // Resolution histograms
  m_h_mcjet_etabad[0]  = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etabad0020",
    "etabad",50,0.,5.);
  m_h_mcjet_etabad[1] =  m_HistSvc->book(m_foldername,m_prefix+"mcjet_etabad0030",
    "etabad",50,0.,5.);
  m_h_mcjet_etabad[2]  = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etabad0040",
    "etabad",50,0.,5.);
  m_h_mcjet_etabad[3]  = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etabad0060",
    "etabad",50,0.,5.);
  m_h_mcjet_etabad[4]  = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etabad0080",
    "etabad",50,0.,5.);
  m_h_mcjet_etabad[5]  = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etabad0120",
    "etabad",50,0.,5.);
  m_h_mcjet_etabad[6]  = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etabad0160",
    "etabad",50,0.,5.);
  m_h_mcjet_etabad[7]  = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etabad0240",
    "etabad",50,0.,5.);
  m_h_mcjet_etabad[8]  = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etabad0320",
    "etabad",50,0.,5.);
  m_h_mcjet_etabad[9]  = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etabad0480",
    "etabad",50,0.,5.);
  m_h_mcjet_etabad[10] = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etabad0640",
    "etabad",50,0.,5.);
  m_h_mcjet_etabad[11] = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etabad0960",
    "etabad",50,0.,5.);
  m_h_mcjet_etabad[12] = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etabad1280",
    "etabad",50,0.,5.);
  m_h_mcjet_etabad[13] = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etabad1920",
    "etabad",50,0.,5.);
  m_h_mcjet_etabad[14] = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etabad2560",
    "etabad",50,0.,5.);
  m_h_mcjet_etabad[15] = m_HistSvc->book(m_foldername,m_prefix+"mcjet_etabad3840",
    "etabad",50,0.,5.);

  return sc;

}

//////////////////////////////////////////////////////////////////////
StatusCode MyJetTruthHistTool::takeAction() 
{

  // jet energy bins
  static const double etbin[17] = {  
      20.*GeV,   30.*GeV,   40.*GeV,   60.*GeV,
      80.*GeV,  120.*GeV,  160.*GeV,  240.*GeV,
     320.*GeV,  480.*GeV,  640.*GeV,  960.*GeV,
    1280.*GeV, 1920.*GeV, 2560.*GeV, 3840.*GeV,
    5120.*GeV
  };

  MsgStream mLog(msgSvc(), name());

  StatusCode sc = StatusCode::SUCCESS;

  // Get reconstructed jets

  const IParticleContainer* myJets(0);
  sc=Get(susy::jet, myJets);
  if(sc == StatusCode::FAILURE || !myJets){
    return StatusCode::FAILURE;
  }
  IParticleContainer::const_iterator jetItr  = (*myJets).begin();
  IParticleContainer::const_iterator jetItrE = (*myJets).end();

  // Get truth jets

  const IParticleContainer* myJetsMc(0);
  sc=Get(susy::jetmc, myJetsMc);
  if(sc == StatusCode::FAILURE || !myJetsMc){
    return StatusCode::FAILURE;
  }
  IParticleContainer::const_iterator jetMcItr  = (*myJetsMc).begin();
  IParticleContainer::const_iterator jetMcItrE = (*myJetsMc).end();

  mLog <<MSG::DEBUG 
       <<"Input sizes = " <<myJets->size() <<" " <<myJetsMc->size()
       <<endreq;

  // Kinematic plots for MC jets

  int njet15 = 0;
  for(; jetMcItr != jetMcItrE; ++jetMcItr) {
    double ej = (*jetMcItr)->e();
    double ptj = (*jetMcItr)->pt();
    if(ptj > 15*GeV) ++njet15;
    m_h_mcjet_et->fill( ptj/GeV,1.);
    double etaj = (*jetMcItr)->hlv().pseudoRapidity();
    double etaaj = fabs(etaj);
    if( ptj>10*GeV ) m_h_mcjet_eta10->fill(etaaj,1.);
    if( ptj>20*GeV ) m_h_mcjet_eta20->fill(etaaj,1.);
    if( ptj>50*GeV ) m_h_mcjet_eta50->fill(etaaj,1.);
    if( ptj>100*GeV ) m_h_mcjet_eta100->fill(etaaj,1.);
  }
  m_h_mcjet_n->fill( (double)njet15, 1.);

  mLog <<MSG::DEBUG <<"Done mc plots" <<endreq;

  // Iterate over reconstructed jets

  for(; jetItr != jetItrE; ++jetItr) {
    double ej = (*jetItr)->e();
    double ptj = (*jetItr)->pt();
    double etaaj = fabs((*jetItr)->eta());
    mLog << MSG::DEBUG << "ej,ptj = " <<ej <<" " <<ptj <<endreq;

    // find a match to this jet in the MC truth container
    // the index and deltaR are returned
    int index = -1;
    double deltaRMatch;
    int pdgId = 0;
    bool findAMatch = m_pAnalysisTools->matchR((*jetItr), myJetsMc,
                                               index, deltaRMatch,pdgId);
    if (findAMatch ) {
      deltaRMatch = (deltaRMatch > 0.999) ? 0.999 : deltaRMatch;
    }
    if(ptj > 25*GeV) m_h_mcjet_rmatch->fill(deltaRMatch,1.);

    // Resolution plots for jets with good match and eta<3
    if( deltaRMatch<m_maxDeltaRMatchCut ) {
      const IParticle*  jetMCMatch = (*myJetsMc)[index]; 
      double ptjmc = jetMCMatch->pt();
      double ejmc = jetMCMatch->e();
      double res = ptj/ptjmc;
      mLog << MSG::DEBUG << "res = " <<res <<endreq;

      // Bin in MC jet energy (not ET as before)
      if( ptjmc < 20*GeV ) continue;
      for(int i=0; i<16; ++i) {
        if( ejmc >= etbin[i] && ejmc < etbin[i+1] ) {
          if( etaaj<3.0 ) (m_h_mcjet_etres[i])->fill(res,1.);
          (m_h_mcjet_etprof[i])->fill(etaaj,res,1.);
          if( fabs(res-1) > 0.2 ) (m_h_mcjet_etabad[i])->fill(etaaj,1.);
        }
      }
    }
  }

  mLog <<MSG::DEBUG <<"Done res plots" <<endreq;

  return sc;
}
