#include "SUSYPhysAlgs/SusyGlobalMcCreator.h"
#include "SUSYPhysUtils/SusyGlobalObject.h"
#include "MissingETEvent/MissingEtTruth.h"

SusyGlobalMcCreator::SusyGlobalMcCreator(const std::string& name,  ISvcLocator* pSvcLocator) 
  : SusyCreator(name, pSvcLocator)
{}

SusyGlobalMcCreator::~SusyGlobalMcCreator() {

}

StatusCode SusyGlobalMcCreator::execute() 
{
  MsgStream log(messageService(), name());
  log << MSG::DEBUG << "Executing SusyGlobalMcCreator" << endreq;

  SusyGlobalObject* susyGlobalObject = new SusyGlobalObject();

  /// record the container of user pre selected jets in StoreGate
  if(StatusCode::FAILURE == m_pSG->record(susyGlobalObject,m_outputKey) )
    {
      log << MSG::ERROR << "Unable to record Susy Global Object in StoreGate" 
	  << endreq;
      return StatusCode::FAILURE;
    } 
  else log << MSG::DEBUG << "User global object (MC) recorded in StoreGate." << endreq;

  StatusCode sc = StatusCode::SUCCESS;

  double pxMiss = 0;
  double pyMiss = 0;
  double ptMiss = 0;
  double ptSum = 0;

  const MissingEtTruth* pMissing;
  /// retrieve the missing Et object from TDS
  sc=m_pSG->retrieve(pMissing, m_inputKey);
  if( sc.isFailure()  ||  !pMissing ) 
    {
      log << MSG::WARNING
	  << "No missing Et object found in TDS"
	  << endreq; 
      return StatusCode::SUCCESS;
    }  

  pxMiss = pMissing->exTruth(MissingEtTruth::NonInt);
  pyMiss = pMissing->eyTruth(MissingEtTruth::NonInt);
  ptMiss = hypot(pxMiss,pyMiss);
  ptSum = pMissing->etSumTruth(MissingEtTruth::Int);
  
  susyGlobalObject->setPxmiss(pxMiss);
  susyGlobalObject->setPymiss(pyMiss);
  susyGlobalObject->setEtmiss(ptMiss);
  susyGlobalObject->setEtsum(ptSum);

  // lock the container in SG
  m_pSG->setConst(susyGlobalObject);
  return StatusCode::SUCCESS;
}

StatusCode SusyGlobalMcCreator::finalize() {

  return StatusCode::SUCCESS;
}
