#include "SUSYPhysAlgs/SusyMuonMcCreator.h"
#include "EventKernel/IParticleContainer.h"
#include "ParticleEvent/TruthParticleContainer.h"
#include "ParticleEvent/TruthParticle.h"
#include "HepMC/GenParticle.h"

#include <math.h>
#include <string>


SusyMuonMcCreator::SusyMuonMcCreator(const std::string& name,  ISvcLocator* pSvcLocator) 
  : SusyCreator(name, pSvcLocator)
{
    declareProperty("Isolation", m_isolation=5.*GeV);
}

SusyMuonMcCreator::~SusyMuonMcCreator() {

}

StatusCode SusyMuonMcCreator::execute() {
  MsgStream mLog(messageService(), name());

  /// create an empty user particle ccontainer for filling - to recorded in StoreGate
  /// The container does not own the elements (view_elements)
  //// THIS WORKS ONLY FOR > 8.7.0!
  IParticleContainer* susyMuonMcContainer = new IParticleContainer(SG::VIEW_ELEMENTS);

  /// record the container of user pre selected muons in StoreGate
  if(StatusCode::FAILURE == m_pSG->record(susyMuonMcContainer,m_outputKey) ){
    mLog << MSG::ERROR 
         << "Unable to record Susy Muon Container in StoreGate" << endreq;
    return StatusCode::FAILURE;
  } else {
    mLog << MSG::DEBUG 
         << "User container of muons recorded in StoreGate" << endreq;
  }  

  /// get the SpclMC AOD container from StoreGate
  const TruthParticleContainer* spclTES;
  StatusCode sc=m_pSG->retrieve( spclTES, m_inputKey);
  if( sc.isFailure()  ||  !spclTES ) {
     mLog << MSG::WARNING
          << "No AOD SpclMC container found in TDS"
          << endreq; 
     return StatusCode::SUCCESS;
  }  

  /// iterate over the container 
  for (TruthParticleContainer::const_iterator it = (*spclTES).begin(); 
  it != (*spclTES).end() ; ++it) {
    // select the muons by applying cuts:
    bool pass=true;
    if( (*it)->hasPdgId() ) {
      if( (*it)->pdgId() != 13 && (*it)->pdgId() != -13 ) pass=false;
    } else {
      pass=false;
    }
    if( (*it)->getGenParticle()->status() != 1) pass = false;
    if( (*it)->getGenParticle()->barcode() > 99999 ) pass = false;
    if((*it)->pt() < m_Ptmin ) pass=false;
    if(fabs((*it)->eta()) > m_EtaCut) pass=false;

    // Truth etIsol() contains muons; reconstructed isolation does not.
    // Gives false fakes, so subtract any extra muons here.
    double etisol = (*it)->etIsol();
    for (TruthParticleContainer::const_iterator it2 = (*spclTES).begin(); 
    it2 != (*spclTES).end() ; ++it2) {
      if( !(*it2)->hasPdgId() ) continue;
      if( abs((*it2)->pdgId()) != 13 ) continue;
      if( it2==it ) continue;
      if( (*it)->hlv().deltaR((*it2)->hlv()) > 0.45 ) continue;
      etisol -= (*it2)->pt();
    }
    if(etisol > m_isolation) pass = false;

    if(pass) susyMuonMcContainer->push_back(*it);
  }

  mLog << MSG::DEBUG << "Number of Susy MC Muons selected " 
       << susyMuonMcContainer->size() << endreq;

  // lock the container in SG
  m_pSG->setConst(susyMuonMcContainer);
  return StatusCode::SUCCESS;
}

StatusCode SusyMuonMcCreator::finalize() {

  return StatusCode::SUCCESS;
}
