// SusyTauCreator.cxx
// Pulls taus out of the AOD and makes selections
// Authors Ian Hinchliffe, Davide Costanzo, F Paige
// Sept 2004


#include "SUSYPhysAlgs/SusyTauCreator.h"

#include "EventKernel/IParticle.h"
#include "EventKernel/IParticleContainer.h"
#include "ParticleEvent/TauJetContainer.h"
#include "ParticleEvent/TauJet.h"
#include "Particle/TrackParticleContainer.h"
#include "Particle/TrackParticle.h"
#include "CLHEP/Matrix/Vector.h"

#include <string>


SusyTauCreator::SusyTauCreator(const std::string& name,  ISvcLocator* pSvcLocator) 
  : SusyCreator(name, pSvcLocator)
{
  // Use different likelihood cuts for 1-prong and 3-prong taus
  // Increase cut below 30GeV with LikelihoodSlope (per GeV)
  declareProperty("LikelihoodCut",m_likelihoodCut=0);
  declareProperty("LikelihoodCut3",m_likelihoodCut3=3);
  declareProperty("LikelihoodSlope",m_likelihoodSlope=0.1);
  declareProperty("trackKey",m_trackKey = "TrackParticleCandidate");
  declareProperty("ExtraTrack1",m_extraTrack1 = 0);
  // Both these cuts help to remove e background
  declareProperty("HadFraction",m_hadFraction = 0.1);
  declareProperty("HadTotal",m_hadTotal = 5*GeV);
}

SusyTauCreator::~SusyTauCreator() {

}

StatusCode SusyTauCreator::execute() {
  MsgStream log(messageService(), name());

  /// create an empty user particle ccontainer for filling - to recorded in StoreGate
  /// The container does not own the elements (view_elements)
  //// THIS WORKS ONLY FOR > 8.7.0!
  IParticleContainer* susyTauContainer = new IParticleContainer(SG::VIEW_ELEMENTS);

  /// record the container of user pre selected taus in StoreGate
  if(StatusCode::FAILURE == m_pSG->record(susyTauContainer,m_outputKey) ){
    log << MSG::ERROR << "Unable to record Susy Tau Container in StoreGate" 
	 << endreq;
    return StatusCode::FAILURE;
  } else
    log << MSG::DEBUG << "User container of taus recorded in StoreGate." << endreq;
  
  /// get the tau AOD container from StoreGate
  const TauJetContainer* tauTES;
  StatusCode sc=m_pSG->retrieve( tauTES, m_inputKey);
  if( sc.isFailure()  ||  !tauTES ) {
     log << MSG::WARNING
          << "No AOD tau container found in TDS"
          << endreq; 
     return StatusCode::SUCCESS;
  }  

  /// Get the TrackParticleContainer
  const Rec::TrackParticleContainer* trackTES;
  sc=m_pSG->retrieve( trackTES, m_trackKey);
  if( sc.isFailure()  ||  !trackTES ) {
     log << MSG::WARNING
         << "No TrackParticle container found in TDS"
         << endreq;
     return StatusCode::SUCCESS;
  }

  // Vector of used tracks
  std::vector< const Rec::TrackParticle* > usedTracks;

  /// iterate over the container 
  for (TauJetContainer::const_iterator it = (*tauTES).begin(); 
  it != (*tauTES).end() ; ++it) {

    // select the taus by applying cuts:
    bool pass=true;
    if( (*it)->pt() < m_Ptmin ) pass=false;
    if( fabs((*it)->eta()) > m_EtaCut ) pass=false;

    // tau specific cuts
    // There is more background for 3-prong events so the cut is harder.
    if( fabs((*it)->charge()) != 1 ) pass=false;
    int ntrack = (*it)->numTrack();
    if( ntrack > 3 ) pass=false;
    // Use tighter likelihood cuts for soft and 3-prong taus
    double softlike = ( (*it)->pt() > 30*GeV ) ? 0 :
    m_likelihoodSlope * (30*GeV-(*it)->pt())/(1*GeV);
    if( (*it)->likelihood()<m_likelihoodCut+softlike ) pass=false;
    if( ntrack>=3 && (*it)->likelihood()<m_likelihoodCut3+softlike ) pass=false;

    // Multi-track candidates must have M < 1.5GeV
    // Should really do this including full covariance matrix. Also
    // should include width of a1, which Herwig apparently does not.
    // Hence the cut is made somewhat loose...
    HepLorentzVector ptrk(0,0,0,0);
    for(int i=0; i<ntrack; ++i) {
      ptrk += (*it)->track(i)->hlv();
    }
    if( ptrk.m() > 1.5*GeV ) pass=false;

    // All candidates must have hadronic energy to remove electrons.
    // Not included in Michael Heldmann's likelihood?
    if( (*it)->etHad() < m_hadFraction*ptrk.perp() ) pass=false;
    if( (*it)->etHad() < m_hadTotal ) pass=false;

    // nTrack1 is always zero!
    // if( (*it)->nTrack1() != 1 ) pass=false;
    // Recompute nTrack1 using fixed pt>1GeV and R<0.3
    int ntrk1 = 0;
    Rec::TrackParticleContainer::const_iterator tkItr = (*trackTES).begin();
    Rec::TrackParticleContainer::const_iterator tkItrE = (*trackTES).end();
    for(; tkItr != tkItrE; ++tkItr) {
      if( (*tkItr)->pt() < 1*GeV) continue;
      double dr = (*it)->hlv().deltaR( (*tkItr)->hlv() );
      if( dr < 0.3 ) ++ntrk1;
    }
    if( ntrk1 > ntrack + m_extraTrack1 ) pass=false;


    // Check for overlaps with previous taus -- slidingwindow bug.
    // Should really select on some basis rather than taking the first.
    bool overlap = false;
    if( pass ) {
      for(unsigned int j=0; j<usedTracks.size(); ++j) {
        for(int k=0; k<ntrack; ++k) {
          if( (*it)->track(k) == usedTracks[j] ) overlap = true;
        }
      }
      for(int k=0; k<ntrack; ++k) {
        usedTracks.push_back( (*it)->track(k) );
      }
    }
    if( overlap ) pass=false;    
    
    if( (*it)->likelihood() > 0 ) {
      log <<MSG::DEBUG
          <<"TAU candidate pt,eta,nTrack,likelihood,pass = "
          <<(*it)->pt() <<" "
          <<(*it)->eta() <<" "
          <<(*it)->numTrack() <<" "
          <<(*it)->likelihood() <<" "
          <<pass
          <<endreq;
    }

    // if the tau passes the cuts put it into the new container:
    if(pass) susyTauContainer->push_back(*it);
  }

  log << MSG::DEBUG << "Number of Susy Taus selected " 
      << susyTauContainer->size() 
      << " from AOD tau size " << tauTES->size() << endreq;

  // lock the container in SG
  m_pSG->setConst(susyTauContainer);
  return StatusCode::SUCCESS;
}

StatusCode SusyTauCreator::finalize() {

  return StatusCode::SUCCESS;
}




