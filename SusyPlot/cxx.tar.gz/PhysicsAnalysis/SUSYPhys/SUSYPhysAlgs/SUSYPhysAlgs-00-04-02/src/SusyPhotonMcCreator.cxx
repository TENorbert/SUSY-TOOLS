// SusyPhotonMcCreator.cxx
// Pulls truth photons  out of the AOD and makes selections
// Authors  Ian Hinchliffe
// Sept 2004

#include "SUSYPhysAlgs/SusyPhotonMcCreator.h"
#include "EventKernel/IParticleContainer.h"
#include "ParticleEvent/TruthParticleContainer.h"
#include "ParticleEvent/TruthParticle.h"

#include "HepMC/GenParticle.h"

#include <string>


SusyPhotonMcCreator::SusyPhotonMcCreator(const std::string& name, ISvcLocator* pSvcLocator) 
  : SusyCreator(name, pSvcLocator)
{}

SusyPhotonMcCreator::~SusyPhotonMcCreator() {

}

StatusCode SusyPhotonMcCreator::execute() {
  MsgStream log(messageService(), name());

  /// create an empty user particle ccontainer for filling - to recorded in StoreGate
  /// The container does not own the elements (view_elements)
  //// THIS WORKS ONLY FOR > 8.7.0!
  IParticleContainer* susyPhotonMcContainer = new IParticleContainer(SG::VIEW_ELEMENTS);

  /// record the container of user pre selected Photons in StoreGate
  if(StatusCode::FAILURE == m_pSG->record(susyPhotonMcContainer,m_outputKey) ){
    log << MSG::ERROR 
        << "Unable to record Susy Photon Container in StoreGate" 
        << endreq;
    return StatusCode::FAILURE;
  } else
    log << MSG::DEBUG 
        << "User container of Photons recorded in StoreGate." 
        << endreq;
  
  /// get the SpclMC AOD container from StoreGate
  const TruthParticleContainer* spclTES;
  StatusCode sc=m_pSG->retrieve( spclTES, m_inputKey);
  if( sc.isFailure()  ||  !spclTES ) {
     log << MSG::WARNING
          << "No AOD SpclMC container found in TDS"
          << endreq; 
     return StatusCode::SUCCESS;
  }  

  /// iterate over the container 
  for (TruthParticleContainer::const_iterator it = (*spclTES).begin(); 
  it != (*spclTES).end() ; ++it) {
    // select the Photons by applying cuts:
    bool pass=true;
    if( (*it)->hasPdgId() ) {
      if( (*it)->pdgId() != 22 ) pass=false;
    } else {
      pass=false;
    }
    if((*it)->pt() < m_Ptmin ) pass=false;
    if(fabs((*it)->eta()) > m_EtaCut) pass=false;
    if( (*it)->getGenParticle()->status() != 1) pass = false;
    if( (*it)->getGenParticle()->barcode() > 99999 ) pass = false;

    if(pass) susyPhotonMcContainer->push_back(*it);
  }

  log << MSG::DEBUG << "Number of Susy MC Photons selected " 
      << susyPhotonMcContainer->size() << endreq;

  // lock the container in SG
  m_pSG->setConst(susyPhotonMcContainer);
  return StatusCode::SUCCESS;
}

StatusCode SusyPhotonMcCreator::finalize() {

  return StatusCode::SUCCESS;
}
