// SusyTrackCreator.cxx
// Pulls isolated high pt tracks out of the AOD and makes selections
// Authors Ian Hinchliffe, Davide Costanzo, F Paige
// Sept 2004


#include "SUSYPhysAlgs/SusyTrackCreator.h"

#include "EventKernel/IParticle.h"
#include "EventKernel/IParticleContainer.h"
#include "Particle/TrackParticleContainer.h"
#include "Particle/TrackParticle.h"
#include "CLHEP/Matrix/Vector.h"

#include <string>


SusyTrackCreator::SusyTrackCreator(const std::string& name,  ISvcLocator* pSvcLocator) 
  : SusyCreator(name, pSvcLocator)
{
  declareProperty("ptCut",m_ptCut = 6.*GeV);
  declareProperty("ptIsolCut",m_ptIsolCut = 1.*GeV);
  declareProperty("ptIsolR",m_ptIsolR = 0.4);
}

SusyTrackCreator::~SusyTrackCreator() {

}

StatusCode SusyTrackCreator::execute() {
  MsgStream mLog(messageService(), name());

  /// Create an empty user particle ccontainer for filling.
  /// TrackParticleContainer does not recognize VIEW_ELEMENTS,
  /// so we cannot use that.... 
  Rec::TrackParticleContainer* SusyTrackContainer = 
    new Rec::TrackParticleContainer();

  /// record the container of user tracks in StoreGate
  if(StatusCode::FAILURE == m_pSG->record(SusyTrackContainer,m_outputKey) ){
    mLog << MSG::ERROR 
         << "Unable to record Susy Track Container in StoreGate with name"
         << m_outputKey
	 << endreq;
    return StatusCode::FAILURE;
  } else {
    mLog << MSG::DEBUG 
         << "User container of tracks recorded in StoreGate as " 
         << m_outputKey
         << endreq;
  }

  /// Get the TrackParticleContainer
  const Rec::TrackParticleContainer* trackTES;
  StatusCode sc=m_pSG->retrieve( trackTES, m_inputKey);
  if( sc.isFailure()  ||  !trackTES ) {
     mLog << MSG::WARNING
          << "No TrackParticle container found in TDS"
          << endreq;
     return StatusCode::SUCCESS;
  }
  Rec::TrackParticleContainer::const_iterator tkItr;
  Rec::TrackParticleContainer::const_iterator tkItr2;
  Rec::TrackParticleContainer::const_iterator tkItrB = (*trackTES).begin();
  Rec::TrackParticleContainer::const_iterator tkItrE = (*trackTES).end();

  for(tkItr=tkItrB; tkItr!=tkItrE; ++tkItr) {
    if( (*tkItr)->pt() < m_ptCut ) continue;
    int nnear = 0;
    for(tkItr2=tkItrB; tkItr2!=tkItrE; ++tkItr2) {
      if( tkItr2==tkItr ) continue;
      if( (*tkItr2)->pt() < m_ptIsolCut ) continue;
      double dr = (*tkItr)->hlv().deltaR( (*tkItr2)->hlv() );
      if( dr > m_ptIsolR ) continue;
      ++nnear;
    }
    mLog <<MSG::DEBUG <<"SusyTrack pt,n = "
         <<(*tkItr)->pt() <<" " <<nnear
         <<endreq;
    if( nnear == 0 ) {
      Rec::TrackParticle* foo = new Rec::TrackParticle(**tkItr);
      SusyTrackContainer->push_back(foo);
    }
  }

  mLog << MSG::DEBUG << "Number of SusyTracks = " 
       << SusyTrackContainer->size() 
      << endreq;

  // lock the container in SG
  m_pSG->setConst(SusyTrackContainer);
  return StatusCode::SUCCESS;
}

StatusCode SusyTrackCreator::finalize() {

  return StatusCode::SUCCESS;
}




