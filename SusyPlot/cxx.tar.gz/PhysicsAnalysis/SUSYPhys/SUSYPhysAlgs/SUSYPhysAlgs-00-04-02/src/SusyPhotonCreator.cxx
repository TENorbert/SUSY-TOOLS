#include "SUSYPhysAlgs/SusyPhotonCreator.h"
#include "EventKernel/IParticleContainer.h"
#include "ParticleEvent/PhotonContainer.h"
#include "ParticleEvent/Photon.h"


SusyPhotonCreator::SusyPhotonCreator(const std::string& name,  ISvcLocator* pSvcLocator) 
  : SusyCreator(name, pSvcLocator)
{

}

SusyPhotonCreator::~SusyPhotonCreator() {

}

StatusCode SusyPhotonCreator::execute() {
  MsgStream log(messageService(), name());
  /// create an empty user particle ccontainer for filling - to recorded in StoreGate
  /// The container does not own the elements (view_elements)
  //// THIS WORKS ONLY FOR > 8.7.0!
  IParticleContainer* susyPhotonContainer = new IParticleContainer(SG::VIEW_ELEMENTS);
  /// record the container of user pre selected photons in StoreGate
  if(StatusCode::FAILURE == m_pSG->record(susyPhotonContainer,m_outputKey) ){
    log << MSG::ERROR << "Unable to record Susy Photon Container in StoreGate" 
	 << endreq;
    return StatusCode::FAILURE;
  } else
    log << MSG::DEBUG << "User container of photons recorded in StoreGate." << endreq;
  
  /// get the photon AOD container from StoreGate
  const PhotonContainer* photonTES;
  StatusCode sc=m_pSG->retrieve( photonTES, m_inputKey);
  if( sc.isFailure()  ||  !photonTES ) {
     log << MSG::WARNING
          << "No AOD photon container found in TDS"
          << endreq; 
     return StatusCode::SUCCESS;
  }  
  /// iterate over the container 
  for (PhotonContainer::const_iterator it = (*photonTES).begin(); it != (*photonTES).end() ; ++it) {
    // select the photons by applying cuts:
    bool pass=true;
    if((*it)->pt() < m_Ptmin ) pass=false;
    if(fabs((*it)->eta()) > m_EtaCut) pass=false;
    // if the photon passes the cuts put it into the new container:
    if(pass) susyPhotonContainer->push_back(*it);
  }

  log << MSG::DEBUG << "Number of Susy Photons selected " 
      << susyPhotonContainer->size() << endreq;

  // lock the container in SG
  m_pSG->setConst(susyPhotonContainer);
  return StatusCode::SUCCESS;
}

StatusCode SusyPhotonCreator::finalize() {

  return StatusCode::SUCCESS;
}
