/***********************************************************************
SusyGlobalCreator.cxx: Create object for missing ET and sum ET.

ESD missing ET calculation uses very loose muon selection, leading to
tails. Remove muon part and replace it with calculation using muons
like that in SusyMuonCreator but without isolation or other cuts.

***********************************************************************/

#include "SUSYPhysAlgs/SusyGlobalCreator.h"
#include "SUSYPhysUtils/SusyGlobalObject.h"
#include "MissingETEvent/MissingET.h"

#include "ParticleEvent/MuonContainer.h"
#include "ParticleEvent/Muon.h"
#include "TrkTrack/FitQuality.h"
#include "Particle/TrackParticle.h"
#include "Particle/TrackParticleContainer.h"


SusyGlobalCreator::SusyGlobalCreator(const std::string& name,  ISvcLocator* pSvcLocator) 
  : SusyCreator(name, pSvcLocator)
{
  declareProperty("SimType", m_sim = "Full");  
  declareProperty("MetMuonName", m_metMuonName="MET_Muon");
  declareProperty("MuonContainerName", m_muonContainerName="MuonCollection");
  declareProperty("MuonChi2Cut", m_muonChi2Cut=5);
  declareProperty("MuonIsolCut", m_muonIsolCut=1.0e9*GeV);
  declareProperty("MuonMooreCut", m_muonMooreCut=0.1);
  declareProperty("MuonMDTCut", m_muonMDTCut=15);
}

SusyGlobalCreator::~SusyGlobalCreator() 
{}

StatusCode SusyGlobalCreator::finalize() {
  return StatusCode::SUCCESS;
}

//////////////////
// Execute
//////////////////

StatusCode SusyGlobalCreator::execute() 
{
  MsgStream mLog(messageService(), name());
  mLog << MSG::DEBUG << "Executing SusyGlobalCreator" << endreq;

  SusyGlobalObject* susyGlobalObject = new SusyGlobalObject();

  /// record the container of user pre selected jets in StoreGate
  if(StatusCode::FAILURE == m_pSG->record(susyGlobalObject,m_outputKey) ) {
    mLog << MSG::ERROR << "Unable to record Susy Global Object in StoreGate"
         << endreq;
    return StatusCode::FAILURE;
  } 
  else {
    mLog << MSG::DEBUG << "User global object recorded in StoreGate." 
         << endreq;
  }

  StatusCode sc = StatusCode::SUCCESS;

  double pxMiss = 0;
  double pyMiss = 0;
  double ptMiss = 0;
  double ptSum = 0;

  /////////////////////////////////
  // Full Simulation/Reconstruction
  /////////////////////////////////
  if (m_sim == "Full") {

    /// retrieve the missing Et objects from TDS
    const MissingET* pMissing = 0;
    sc=m_pSG->retrieve(pMissing, m_inputKey);
    if( sc.isFailure()  ||  !pMissing ) {
      mLog << MSG::WARNING
          << "No missing Et object found in TDS with name "
          << m_inputKey
          << endreq; 
      return StatusCode::SUCCESS;
    }  
    const MissingET* pMissMuon = 0;
    sc=m_pSG->retrieve(pMissMuon, m_metMuonName);
    if( sc.isFailure()  ||  !pMissMuon ) {
      mLog << MSG::WARNING
          << "No missing MET_Muon object found in TDS with name "
          << m_metMuonName
          << endreq; 
      return StatusCode::SUCCESS;
    }  
    
    // Also retrieve muons
    const MuonContainer* muonTES = 0;
    sc=m_pSG->retrieve( muonTES, m_muonContainerName);
    if( sc.isFailure()  ||  !muonTES ) {
       mLog << MSG::WARNING
            << "No AOD muon container found in TDS with name "
            << m_muonContainerName
            << endreq;
       return StatusCode::SUCCESS;
    }

    // Remove MET_Muon part
    pxMiss = pMissing->etx() - pMissMuon->etx();
    pyMiss = pMissing->ety() - pMissMuon->ety();
    ptSum = pMissing->sumet();

    // Now include muons with good MuID match and chi2 in MET
    // Note no pt, eta, or isolation cuts are made

    MuonContainer::const_iterator itB = (*muonTES).begin(); 
    MuonContainer::const_iterator itE = (*muonTES).end(); 
    MuonContainer::const_iterator it;
    MuonContainer::const_iterator it2;

    for (it = itB; it != itE; ++it) {
      bool pass=true;

      // Get rid of soft ones
      if( (*it)->author() != MuonParameters::highPt) pass=false;

      // chi2() is missing in 10.0.1, so get it indirectly:
      // if((*it)->chi2() > m_muonChi2Cut ) pass=false;
      double chi2 = 1e20;
      int mdthit = -1;
      const Rec::TrackParticle* duh = (*it)->get_CombinedMuonTrackParticle();
      if( duh ) {
        double temp = duh->fitQuality()->chiSquared();
        int ndof =  duh->fitQuality()->numberDoF();
        if( ndof > 0 ) chi2 = temp/ndof;
        mdthit = (*it)->numberOfMDTHits();
      }
      if( chi2 > m_muonChi2Cut ) pass=false;
      int mdtcut = mdthit;
      if( fabs((*it)->eta())>1.0 && fabs((*it)->eta())<1.4 ) mdtcut += 5;
      if( fabs((*it)->eta()) < 2.0 && mdtcut < m_muonMDTCut ) pass=false;

      // Isolation ET is really E!
      // Logically should not cut on this, but reduces fakes(??)
      double etisol = ((*it)->getEtIsol())[4];
      etisol = etisol/cosh((*it)->eta());
      if( etisol > m_muonIsolCut ) pass=false;

      // Keep only best chi2 muon for this Moore track
      const Rec::TrackParticle* moo = (*it)->get_MuonSpectrometerTrackParticle();
      if( !moo ) pass=false;
      for(it2 = itB; it2 != itE; ++it2) {
        if(it2 == it) continue;
        const Rec::TrackParticle* moo2 = (*it2)->get_MuonSpectrometerTrackParticle();
        if(moo2 != moo) continue;
        const Rec::TrackParticle* duh2 = (*it2)->get_CombinedMuonTrackParticle();
        if( duh2 ) {
          double c2 = duh2->fitQuality()->chiSquared();
          int n2 =  duh2->fitQuality()->numberDoF();
          if( n2 > 0 ) {
            c2 = c2/n2;
            if( c2 < chi2 ) pass=false;
          }
        }
      }

      // Require reasonable Moore track
      const Rec::TrackParticle* mooextrap = 
      (*it)->get_MuonExtrapolatedTrackParticle();
      double moorat = 0;
      if( mooextrap ) {
        moorat = mooextrap->pt()/(*it)->pt();
      } 
      if( fabs(moorat-1.0) > m_muonMooreCut ) pass=false;

      // If the muon passes the cuts, SUBTRACT it from MET
      if( pass && moo ) {
        pxMiss -= moo->px();
        pyMiss -= moo->py();
      }
    }

    // Finally compute corrected ptMiss
    ptMiss = hypot(pxMiss,pyMiss);
  }

  //////////////////
  // Fast Simulation
  //////////////////
  else if (m_sim == "Fast") {
    /// retrieve the missing Et object from TDS
    const MissingET* pMissing;
    sc=m_pSG->retrieve(pMissing, "AtlfastMisingEt");
    if( sc.isFailure()  ||  !pMissing ) {
      mLog << MSG::WARNING
           << "No Atlfast missing Et object found in TDS"
           << endreq; 
      return StatusCode::SUCCESS;
    }
     pxMiss = pMissing->etx();
     pyMiss = pMissing->ety();
     ptMiss = hypot(pxMiss,pyMiss);
     ptSum = pMissing->sumet();

  } else {
    mLog << MSG::WARNING << "Wrong reconstruction/simulation options " 
         << m_sim <<" "<< endreq;
    return StatusCode::SUCCESS;
  }

  // Save result in susyGlobalObject

  susyGlobalObject->setPxmiss(pxMiss);
  susyGlobalObject->setPymiss(pyMiss);
  susyGlobalObject->setEtmiss(ptMiss);
  susyGlobalObject->setEtsum(ptSum);
  m_pSG->setConst(susyGlobalObject);

  return StatusCode::SUCCESS;

}

