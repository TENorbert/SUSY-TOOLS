/********************************************************************
Select muons making pt, eta, chi2, and isolation cuts.
Keep only best chi2!
********************************************************************/

#include "SUSYPhysAlgs/SusyMuonCreator.h"
#include "EventKernel/IParticleContainer.h"
#include "ParticleEvent/MuonContainer.h"
#include "ParticleEvent/Muon.h"

#include "TrkTrack/FitQuality.h"
#include "Particle/TrackParticle.h"
#include "Particle/TrackParticleContainer.h"

#include <math.h>


SusyMuonCreator::SusyMuonCreator(const std::string& name,  ISvcLocator* pSvcLocator) 
  : SusyCreator(name, pSvcLocator)
{
  declareProperty("Chi2Cut",m_Chi2 = 20.);  
  declareProperty("Chi2Slope",m_Chi2Slope = 0.5); // per GeV below 30GeV
  declareProperty("Isolation", m_isolation=5.*GeV);
}

SusyMuonCreator::~SusyMuonCreator() {

}

StatusCode SusyMuonCreator::execute() {
  MsgStream mLog(messageService(), name());
  /// create an empty user particle ccontainer for filling - to recorded in StoreGate
  /// The container does not own the elements (view_elements)
  //// THIS WORKS ONLY FOR > 8.7.0!
  IParticleContainer* susyMuonContainer = new IParticleContainer(SG::VIEW_ELEMENTS);
  /// record the container of user pre selected muons in StoreGate
  if(StatusCode::FAILURE == m_pSG->record(susyMuonContainer,m_outputKey) ){
    mLog << MSG::ERROR << "Unable to record Susy Muon Container in StoreGate" 
	 << endreq;
    return StatusCode::FAILURE;
  } else {
    mLog << MSG::DEBUG 
         << "User container of muons recorded in StoreGate." << endreq;
  }

  /// get the muon AOD container from StoreGate
  const MuonContainer* muonTES;
  StatusCode sc=m_pSG->retrieve( muonTES, m_inputKey);
  if( sc.isFailure()  ||  !muonTES ) {
     mLog << MSG::WARNING
          << "No AOD muon container found in TDS"
          << endreq; 
     return StatusCode::SUCCESS;
  }  

  /// iterate over the container 

  MuonContainer::const_iterator itB = (*muonTES).begin(); 
  MuonContainer::const_iterator itE = (*muonTES).end(); 
  MuonContainer::const_iterator it;
  MuonContainer::const_iterator it2;

  for(it = itB; it != itE; ++it) {
    bool pass=true;

    if((*it)->pt() < m_Ptmin ) pass=false;
    if(fabs((*it)->eta()) > m_EtaCut) pass=false;

    // Get rid of soft ones
    if( (*it)->author() != MuonParameters::highPt) pass=false;

    // chi2() is missing in 10.0.1, so get it indirectly:
    // if((*it)->chi2() > m_Chi2) pass=false;
    mLog <<MSG::DEBUG <<"Starting chi2" <<endreq;
    double chi2 = 1e20;
    const Rec::TrackParticle* duh = (*it)->get_CombinedMuonTrackParticle();
    if( duh ) {
      double temp = duh->fitQuality()->chiSquared();
      int ndof =  duh->fitQuality()->numberDoF();
      if( ndof > 0 ) chi2 = temp/ndof;
      mLog <<MSG::DEBUG <<"chi2,ndof = " <<chi2 <<" " <<ndof <<endreq;
    } 
    double chi2cut = m_Chi2;
    if((*it)->pt() < 30*GeV) chi2cut += m_Chi2Slope*(30-(*it)->pt()/GeV);
    if( chi2 > chi2cut) pass=false;

    // Isolation ET is really E!
    double etisol = ((*it)->getEtIsol())[4];
    etisol = etisol/cosh((*it)->eta());
    if( etisol > m_isolation ) pass=false;  

    // Keep only best chi2 muon for this Moore track
    const Rec::TrackParticle* moo = (*it)->get_MuonSpectrometerTrackParticle();
    if( !moo ) pass=false;
    for(it2 = itB; it2 != itE; ++it2) {
      if(it2 == it) continue;
      const Rec::TrackParticle* moo2 = (*it2)->get_MuonSpectrometerTrackParticle();
      if(moo2 != moo) continue;
      const Rec::TrackParticle* duh2 = (*it2)->get_CombinedMuonTrackParticle();
      if( duh2 ) {
        double c2 = duh2->fitQuality()->chiSquared();
        int n2 =  duh2->fitQuality()->numberDoF();
        if( n2 > 0 ) {
          c2 = c2/n2;
          if( c2 < chi2 ) pass=false;
        }
      }
    }

    // if the muon passes the cuts put it into the new container:
    if(pass) susyMuonContainer->push_back(*it);

  }

  mLog << MSG::DEBUG << "Number of Susy Muons selected " 
       << susyMuonContainer->size() << endreq;

  // lock the container in SG
  m_pSG->setConst(susyMuonContainer);
  return StatusCode::SUCCESS;
}

StatusCode SusyMuonCreator::finalize() {

  return StatusCode::SUCCESS;
}
