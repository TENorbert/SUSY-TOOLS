//
// Created from SusyJetCreator.cxx  (Fredrik Tegenfeldt 2004)
//
#include "SUSYPhysAlgs/SusyBJetCreator.h"

#include "EventKernel/IParticleContainer.h"
//#include "BTaggingEvent/BJet.h"
//#include "BTaggingEvent/BJetContainer.h"
//
// New b-tagging structure
//
#include "JetTagEvent/JetTag.h"
#include "JetTagEvent/JetTagContainer.h"

SusyBJetCreator::SusyBJetCreator(const std::string& name,  ISvcLocator* pSvcLocator) 
  : SusyCreator(name, pSvcLocator)
{
  declareProperty("BTagLHSig",    m_lhSigCut = 0.60);
}

SusyBJetCreator::~SusyBJetCreator() {
}

StatusCode SusyBJetCreator::execute() {
  MsgStream log(messageService(), name());
  //
  // Create an empty IParticleContainer to be stored in StoreGate 
  //
  ////  JetTagContainer* susyBJetContainer = new JetTagContainer(SG::VIEW_ELEMENTS);
  IParticleContainer* susyBJetContainer = new IParticleContainer(SG::VIEW_ELEMENTS);
  // record the container of user pre selected bjets in StoreGate
  if(StatusCode::FAILURE == m_pSG->record(susyBJetContainer,m_outputKey) ){
    log << MSG::ERROR << "Unable to record Susy BJet Container in StoreGate" 
	 << endreq;
    return StatusCode::FAILURE;
  } else
    log << MSG::DEBUG << "User container of b-jets recorded in StoreGate." << endreq;
  // get the jet AOD container from StoreGate
  const JetTagContainer* BJetTag;
  StatusCode sc;
  //
  sc=m_pSG->retrieve( BJetTag, m_inputKey);
  if( sc.isFailure()  ||  !BJetTag ) {
    log << MSG::WARNING
	<< "No AOD BJetTag container found in TDS: "
        << m_inputKey
	<< endreq;
    return StatusCode::SUCCESS;
  } else {
    log << MSG::DEBUG
	<< "AOD JetTag container found: "
        << m_inputKey
	<< endreq;
  }

//   sc=m_pSG->retrieve( BJetTES, m_inputKey);
//   if( sc.isFailure()  ||  !BJetTES ) {
//     log << MSG::WARNING
// 	<< "No AOD BJet container found in TDS: "
//         << m_inputKey
// 	<< endreq; 
//     return StatusCode::SUCCESS;
//   }  
  // iterate over the container 
  const Analysis::JetTag *bJet;
  for (JetTagContainer::const_iterator it = (*BJetTag).begin(); it != (*BJetTag).end() ; ++it) {
    // select the jetss by applying cuts:
    bJet = dynamic_cast<Analysis::JetTag *>(*it);
    bool pass=true;
    if(bJet->pt() < m_Ptmin )        pass=false;
    if(fabs(bJet->eta()) > m_EtaCut) pass=false;
    if(bJet->lhSig() < m_lhSigCut )  pass=false;
    // if the Jet passes the cuts put it into the new container:
    if(pass) susyBJetContainer->push_back(*it);
  }
  log << MSG::INFO << "Number of Susy BJets selected " << susyBJetContainer->size() << endreq;
  // lock the container in SG
  m_pSG->setConst(susyBJetContainer);
  return StatusCode::SUCCESS;
}

StatusCode SusyBJetCreator::finalize() {

  return StatusCode::SUCCESS;
}
