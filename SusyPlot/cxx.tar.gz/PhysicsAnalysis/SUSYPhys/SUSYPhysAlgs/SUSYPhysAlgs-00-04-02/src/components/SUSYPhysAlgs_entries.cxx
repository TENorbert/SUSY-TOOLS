#include "GaudiKernel/DeclareFactoryEntries.h"
#include "SUSYPhysAlgs/SusyMuonCreator.h"
#include "SUSYPhysAlgs/SusyMuonMcCreator.h"
#include "SUSYPhysAlgs/SusyJetCreator.h"
#include "SUSYPhysAlgs/SusyJetTruthCreator.h"
#include "SUSYPhysAlgs/SusyBJetCreator.h"
#include "SUSYPhysAlgs/SusyPhotonCreator.h"
#include "SUSYPhysAlgs/SusyPhotonMcCreator.h"
#include "SUSYPhysAlgs/SusyElectronMcCreator.h"
#include "SUSYPhysAlgs/SusyElectronCreator.h"
#include "SUSYPhysAlgs/SusyTauCreator.h"
#include "SUSYPhysAlgs/SusyTauMcCreator.h"
#include "SUSYPhysAlgs/SusyGlobalCreator.h"
#include "SUSYPhysAlgs/SusyGlobalMcCreator.h"
#include "SUSYPhysAlgs/SusyTrackCreator.h"
#include "SUSYPhysAlgs/SusyPlot.h"

DECLARE_ALGORITHM_FACTORY(SusyMuonMcCreator);
DECLARE_ALGORITHM_FACTORY(SusyMuonCreator);
DECLARE_ALGORITHM_FACTORY(SusyJetCreator);
DECLARE_ALGORITHM_FACTORY(SusyJetTruthCreator);
DECLARE_ALGORITHM_FACTORY(SusyBJetCreator);
DECLARE_ALGORITHM_FACTORY(SusyElectronCreator);
DECLARE_ALGORITHM_FACTORY(SusyElectronMcCreator);
DECLARE_ALGORITHM_FACTORY(SusyPhotonCreator);
DECLARE_ALGORITHM_FACTORY(SusyPhotonMcCreator);
DECLARE_ALGORITHM_FACTORY(SusyTauCreator);
DECLARE_ALGORITHM_FACTORY(SusyTauMcCreator);
DECLARE_ALGORITHM_FACTORY(SusyGlobalCreator);
DECLARE_ALGORITHM_FACTORY(SusyGlobalMcCreator);
DECLARE_ALGORITHM_FACTORY(SusyTrackCreator);
DECLARE_ALGORITHM_FACTORY(SusyPlot);

DECLARE_FACTORY_ENTRIES(SUSYPhysAlgs) {
  DECLARE_ALGORITHM( SusyMuonCreator );
  DECLARE_ALGORITHM( SusyMuonMcCreator );
  DECLARE_ALGORITHM( SusyJetCreator );
  DECLARE_ALGORITHM( SusyJetTruthCreator );
  DECLARE_ALGORITHM( SusyBJetCreator );
  DECLARE_ALGORITHM( SusyElectronCreator );
  DECLARE_ALGORITHM( SusyElectronMcCreator );
  DECLARE_ALGORITHM( SusyPhotonMcCreator );
  DECLARE_ALGORITHM( SusyPhotonCreator );
  DECLARE_ALGORITHM( SusyTauCreator );
  DECLARE_ALGORITHM( SusyTauMcCreator );
  DECLARE_ALGORITHM( SusyGlobalCreator );
  DECLARE_ALGORITHM( SusyGlobalMcCreator );
  DECLARE_ALGORITHM( SusyTrackCreator );
  DECLARE_ALGORITHM( SusyPlot );
}
