// SusyElectronCreator.cxx
// Pulls electrons out of the AOD and makes selections
// Authors Ian Hinchliffe, Davide Costanzo
// Sept 2004

#include "SUSYPhysAlgs/SusyElectronCreator.h"
#include "EventKernel/IParticleContainer.h"
#include "ParticleEvent/ElectronContainer.h"
#include "ParticleEvent/Electron.h"
#include "ParticleEvent/ElectronParamDefs.h"
#include "Particle/TrackParticleContainer.h"
#include "Particle/TrackParticle.h"

#include <string>

SusyElectronCreator::SusyElectronCreator(const std::string& name,  ISvcLocator* pSvcLocator) 
  : SusyCreator(name, pSvcLocator)
{
    declareProperty("useSofte",m_useSofte=false );
    declareProperty("applyTRTCuts",m_applyTRTCuts=false );
    declareProperty("Isolation", m_isolation=5.*GeV);
    declareProperty("epiNNCut", m_epiNNCut=0.8);
    declareProperty("epiWeightCut", m_epiWeightCut=0.9);
    declareProperty("trackKey",m_trackKey = "TrackParticleCandidate");
    declareProperty("TrackIsolation", m_trackIsolation=3.*GeV);
}

SusyElectronCreator::~SusyElectronCreator() {

}

StatusCode SusyElectronCreator::execute() {
  MsgStream mLog(messageService(), name());

  /// create an empty user particle ccontainer for filling - to recorded in StoreGate
  /// The container does not own the elements (view_elements)
  //// THIS WORKS ONLY FOR > 8.7.0!
  IParticleContainer* susyElectronContainer = new IParticleContainer(SG::VIEW_ELEMENTS);
  /// record the container of user pre selected electrons in StoreGate
  if(StatusCode::FAILURE == m_pSG->record(susyElectronContainer,m_outputKey) ){
    mLog << MSG::ERROR << "Unable to record Susy Electron Container in StoreGate" 
	 << endreq;
    return StatusCode::FAILURE;
  } else
    mLog << MSG::DEBUG 
         << "User container of electrons recorded in StoreGate." << endreq;
  
  /// get the electron AOD container from StoreGate
  const ElectronContainer* electronTES;
  StatusCode sc=m_pSG->retrieve( electronTES, m_inputKey);
  if( sc.isFailure()  ||  !electronTES ) {
     mLog << MSG::WARNING
          << "No AOD electron container found in TDS"
          << endreq; 
     return StatusCode::SUCCESS;
  }  

  /// Get the TrackParticleContainer
  const Rec::TrackParticleContainer* trackTES;
  sc=m_pSG->retrieve( trackTES, m_trackKey);
  if( sc.isFailure()  ||  !trackTES ) {
     mLog << MSG::WARNING
          << "No TrackParticle container found in TDS"
          << endreq;
     return StatusCode::SUCCESS;
  }

  ////////////////////////////////////////

  /// iterate over the container 
  for (ElectronContainer::const_iterator it = (*electronTES).begin(); 
  it != (*electronTES).end() ; ++it) {

    // select the electrons by applying cuts:
    bool pass=true;

    // Eta and pt selection cuts:
    if( (*it)->pt() < m_Ptmin ) pass=false;
    double etaa = fabs((*it)->eta());
    if( etaa > m_EtaCut ) pass=false;

    // disregard the softe
    if( (*it)->author() == ElectronParameters::softe && !m_useSofte ) 
    pass=false;

    // Calorimeter cuts
    // emWeight using Kamal's results
    double emWeight = (*it)->parameter(ElectronParameters::emWeight);
    double piWeight = (*it)->parameter(ElectronParameters::pionWeight);
    double epiNN = (*it)->parameter(ElectronParameters::epiNN);
    emWeight = (emWeight+piWeight>0) ? emWeight/(emWeight+piWeight) :
    emWeight;
    mLog <<MSG::DEBUG
         <<"Kamal weights = " <<emWeight <<" " <<piWeight <<" " 
         <<epiNN <<" EMPASS " <<pass
         <<endreq; 
    if( (*it)->isEM()%16 != 0 && epiNN < m_epiNNCut && 
    emWeight < m_epiWeightCut ) pass=false;

    // Request a track to the electron (this may be redundant)
    if( !(*it)->hasTrack() ) pass=false;

    // Track quality cuts
    if( (*it)->isEM() & 0x0200 != 0) pass=false;
    if( (*it)->isEM() & 0x0400 != 0) pass=false;

    // TRT cuts
    if( m_applyTRTCuts && (*it)->isEM() & 0x0800 != 0) pass=false;

    // Tighter E/p cut 
    // Relax cuts for high pt: a 200GeV track matched to a 1TeV 
    // EM cluster is a good electron!
    // Also relax cuts in endcap: c.f. Monika in DC1

    double eoverp = fabs( (*it)->parameter(ElectronParameters::EoverP) );
    double pttrack = (eoverp>0) ? (*it)->pt()/eoverp : 0;
    double errtrack = (pttrack>40*GeV) ? (pttrack-40*GeV)/(400*GeV) : 0;
    if(etaa<1.5 && (eoverp<0.8-2*errtrack || eoverp>1.3+2*errtrack) ) 
    pass=false;
    if(etaa>=1.5 && (eoverp<0.7-2*errtrack || eoverp>2.5+2*errtrack) ) 
    pass=false;

    // Isolation cut
    double etisol = (*it)->parameter(ElectronParameters::etcone);
    if( etisol > m_isolation ) pass=false;

    // Track isolation cut
    const Rec::TrackParticle* eTrk = (*it)->track();
    double pttrk1 = 0;
    Rec::TrackParticleContainer::const_iterator tkItr = (*trackTES).begin();
    Rec::TrackParticleContainer::const_iterator tkItrE = (*trackTES).end();
    for(; tkItr != tkItrE; ++tkItr) {
      if( (*tkItr) == eTrk ) continue;
      if( (*tkItr)->pt() < 1*GeV) continue;
      double dr = (*it)->hlv().deltaR( (*tkItr)->hlv() );
      if( dr < 0.3 ) pttrk1 += (*tkItr)->pt();
    }
    mLog << MSG::DEBUG << "Track isolation = " << pass << " " 
         << eTrk->pt() << " " << pttrk1
         << endreq;
    if( pttrk1 > m_trackIsolation) pass=false;

    // if the electron passes the cuts put it into the new container:
    if(pass) susyElectronContainer->push_back(*it);
  }

  mLog << MSG::DEBUG
       << "Number of Susy Electrons selected " 
       << susyElectronContainer->size() << endreq;

  // lock the container in SG
  m_pSG->setConst(susyElectronContainer);
  return StatusCode::SUCCESS;

}

StatusCode SusyElectronCreator::finalize() {

  return StatusCode::SUCCESS;
}
