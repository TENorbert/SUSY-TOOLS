// SusyJetTruthCreator.cxx
// Pulls truth jets out of the AOD and makes selections
// Authors  F Paige
// Sept 2004
#include "SUSYPhysAlgs/SusyJetTruthCreator.h"

#include "EventKernel/IParticleContainer.h"
#include "ParticleEvent/ParticleJetContainer.h"
#include "ParticleEvent/ParticleJet.h"

#include <string>

//////////////////////////////////////////////////////////////////////
SusyJetTruthCreator::SusyJetTruthCreator(const std::string& name,  ISvcLocator* pSvcLocator) 
  : SusyCreator(name, pSvcLocator)
{}

//////////////////////////////////////////////////////////////////////
SusyJetTruthCreator::~SusyJetTruthCreator() 
{}

//////////////////////////////////////////////////////////////////////
StatusCode SusyJetTruthCreator::execute() {
  MsgStream log(messageService(), name());

  /// create an empty user particle ccontainer for filling - to recorded in StoreGate
  /// The container does not own the elements (view_elements)
  //// THIS WORKS ONLY FOR > 8.7.0!
  IParticleContainer* susyJetContainer = new IParticleContainer(SG::VIEW_ELEMENTS);

  /// record the container of user pre selected jets in StoreGate
  if(StatusCode::FAILURE == m_pSG->record(susyJetContainer,m_outputKey) ){
    log << MSG::ERROR << "Unable to record Susy Jet Container in StoreGate" 
	 << endreq;
    return StatusCode::FAILURE;
  } else {
    log << MSG::DEBUG << "User container of jet recorded in StoreGate." 
        << endreq;
  }

  /// get the jet AOD container from StoreGate
  const ParticleJetContainer* jetTES;
  StatusCode sc=m_pSG->retrieve( jetTES, m_inputKey);
  if( sc.isFailure()  ||  !jetTES ) {
    log << MSG::WARNING
        << "No AOD ParticleJet container found in TDS for Truth with name "
        << m_inputKey
        << endreq; 
    return StatusCode::SUCCESS;
  }  

  log <<MSG::DEBUG <<"JetTruth size = " <<jetTES->size() <<endreq;

  /// iterate over the container 
  for (ParticleJetContainer::const_iterator it = (*jetTES).begin(); 
  it != (*jetTES).end() ; ++it) {
    bool pass=true;
    if( (*it) ) {
      if((*it)->pt() < m_Ptmin ) pass=false;
      if(fabs((*it)->eta()) > m_EtaCut) pass=false;
      if(pass) susyJetContainer->push_back((*it));
    }
  }

  // lock the container in SG
  m_pSG->setConst(susyJetContainer);

  log <<MSG::DEBUG <<"SusyJetTruthCreator done " <<endreq;

  return StatusCode::SUCCESS;

}

//////////////////////////////////////////////////////////////////////
StatusCode SusyJetTruthCreator::finalize() {
  return StatusCode::SUCCESS;
}

