#include "SUSYPhysAlgs/SusyJetCreator.h"
#include "EventKernel/IParticleContainer.h"
#include "ParticleEvent/ParticleJetContainer.h"
#include "ParticleEvent/ParticleJet.h"


SusyJetCreator::SusyJetCreator(const std::string& name,  ISvcLocator* pSvcLocator) 
  : SusyCreator(name, pSvcLocator)
{
}

SusyJetCreator::~SusyJetCreator() {

}

StatusCode SusyJetCreator::execute() {
  MsgStream log(messageService(), name());
  /// create an empty user particle ccontainer for filling - to recorded in StoreGate
  /// The container does not own the elements (view_elements)
  //// THIS WORKS ONLY FOR > 8.7.0!
  IParticleContainer* susyJetContainer = new IParticleContainer(SG::VIEW_ELEMENTS);
  /// record the container of user pre selected jets in StoreGate
  if(StatusCode::FAILURE == m_pSG->record(susyJetContainer,m_outputKey) ){
    log << MSG::ERROR << "Unable to record Susy Jet Container in StoreGate" 
	 << endreq;
    return StatusCode::FAILURE;
  } else
    log << MSG::DEBUG << "User container of jet recorded in StoreGate." << endreq;
  
  /// get the jet AOD container from StoreGate
  const ParticleJetContainer* jetTES;
  StatusCode sc=m_pSG->retrieve( jetTES, m_inputKey);
  if( sc.isFailure()  ||  !jetTES ) {
     log << MSG::WARNING
         << "No AOD ParticleJet container found in TDS with name "
         << m_inputKey  
         << endreq; 
     return StatusCode::SUCCESS;
  }  
  /// iterate over the container 
  for (ParticleJetContainer::const_iterator it = (*jetTES).begin(); it != (*jetTES).end() ; ++it) {
    // select the jetss by applying cuts:
    bool pass=true;
    if((*it)->pt() < m_Ptmin ) pass=false;
    if(fabs((*it)->eta()) > m_EtaCut) pass=false;
    // if the Jet passes the cuts put it into the new container:
    if(pass) susyJetContainer->push_back(*it);
  }

  log << MSG::DEBUG << "Number of Susy Jets selected " 
      << susyJetContainer->size() << endreq;

  // lock the container in SG
  m_pSG->setConst(susyJetContainer);
  return StatusCode::SUCCESS;
}

StatusCode SusyJetCreator::finalize() {

  return StatusCode::SUCCESS;
}
