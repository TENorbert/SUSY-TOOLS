#include "SUSYPhysAlgs/SusyTauMcCreator.h"


#include "EventKernel/IParticleContainer.h"

#include "ParticleEvent/TruthParticleContainer.h"
#include "ParticleEvent/TruthParticle.h"
#include "HepMC/GenParticle.h"
#include "HepMC/GenVertex.h"
#include "GaudiKernel/MsgStream.h"

#include <string>


SusyTauMcCreator::SusyTauMcCreator(const std::string& name,  ISvcLocator* pSvcLocator) 
  : SusyCreator(name, pSvcLocator)
{
    declareProperty("Isolation", m_isolation=5.*GeV);
}

SusyTauMcCreator::~SusyTauMcCreator() {

}

StatusCode SusyTauMcCreator::execute() {
  MsgStream log(messageService(), name());

  /// create an empty user particle ccontainer for filling - to recorded in StoreGate
  /// The container does not own the elements (view_elements)
  //// THIS WORKS ONLY FOR > 8.7.0!
  IParticleContainer* susyTauMcContainer = new IParticleContainer(SG::VIEW_ELEMENTS);

  /// record the container of user pre selected Taus in StoreGate
  if(StatusCode::FAILURE == m_pSG->record(susyTauMcContainer,m_outputKey) ){
    log << MSG::ERROR << "Unable to record Susy Tau Container in StoreGate" 
	 << endreq;
    return StatusCode::FAILURE;
  } else
    log << MSG::DEBUG << "User container of Taus recorded in StoreGate." << endreq;
  
  /// get the SpclMC AOD container from StoreGate
  const TruthParticleContainer* spclTES;
  StatusCode sc=m_pSG->retrieve( spclTES, m_inputKey);
  if( sc.isFailure()  ||  !spclTES ) {
     log << MSG::WARNING
          << "No AOD SpclMC container found in TDS"
          << endreq; 
     return StatusCode::SUCCESS;
  }  

  /// iterate over the container 
  for (TruthParticleContainer::const_iterator it = (*spclTES).begin(); 
  it != (*spclTES).end() ; ++it) {
    bool pass=true;
    // pdgId code
    if( (*it)->hasPdgId() ) {
      if( abs((*it)->pdgId()) != 15 ) pass=false;
    } else {
      pass=false;
    }

    // Kinematic cuts
    if((*it)->pt() < m_Ptmin ) pass=false;
    if(fabs((*it)->eta()) > m_EtaCut) pass=false;

    // Compute visible pt and remove self decays
    const TruthParticle* tp = dynamic_cast< const TruthParticle* >(*it);
    if( tp==0 ) continue;
    const HepMC::GenParticle* tpgen = tp->getGenParticle();
    if( !tpgen ) continue;
    HepMC::GenVertex* tpvtx = tpgen->end_vertex();
    if( !tpvtx ) continue;
    HepMC::GenVertex::particle_iterator ipd =
    tpvtx->particles_begin(HepMC::descendants);
    HepMC::GenVertex::particle_iterator ipdE =
    tpvtx->particles_end(HepMC::descendants);
    double ptvis = 0;
    // The test on barcode() is needed: with it momentum is conserved
    for( ; ipd != ipdE; ++ipd ) {
      int ida = abs((*ipd)->pdg_id());
      if( ida == 15 ) pass = false; // self decay
      if( ida == 12 || ida == 14 || ida ==16 ) continue; // neutrino
      if( (*ipd)->status() != 1 || (*ipd)->barcode() > 100000 ) continue; 
      ptvis += (*ipd)->momentum().perp();
    }
    if( ptvis < m_Ptmin ) pass=false;

    // Isolation cut -- does not work with Rome data
    //if((*it)->etIsol() > m_isolation) pass = false;

    if( abs((*it)->pdgId()) == 15 ) {
      log <<MSG::DEBUG
          <<"TAUMC candidate pt,ptvis,eta,isol,pass = "
          <<(*it)->pt() <<" "
          <<ptvis <<" "
          <<(*it)->eta() <<" "
          <<(*it)->etIsol() <<" "
          <<pass
          <<endreq;
    }

    // Save taus passing all cuts
    if(pass) susyTauMcContainer->push_back(*it);
  }

  log << MSG::DEBUG << "Number of Susy MC Taus selected " 
      << susyTauMcContainer->size() << endreq;

  // lock the container in SG
  m_pSG->setConst(susyTauMcContainer);
  return StatusCode::SUCCESS;
}

StatusCode SusyTauMcCreator::finalize() {

  return StatusCode::SUCCESS;
}
