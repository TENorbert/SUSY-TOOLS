#include "SUSYPhysAlgs/SusyCreator.h"
#include "CLHEP/Units/SystemOfUnits.h"


SusyCreator::SusyCreator(const std::string& name,  ISvcLocator* pSvcLocator) 
  : Algorithm(name, pSvcLocator)
{
  // Properties
  declareProperty("Ptcut",m_Ptmin = 10.*GeV);  
  declareProperty("Etacut",m_EtaCut = 2.5);  
  declareProperty("InputKey",m_inputKey ="");  
  declareProperty("OutputKey",m_outputKey="");  
}

SusyCreator::~SusyCreator() {

}

StatusCode SusyCreator::initialize() {
  // Initialize the generic creator
  MsgStream log(messageService(), name());
  log << MSG::INFO << "Initializing Creator " << name() << endreq;
  // Get a SG pointer:
  if (StatusCode::FAILURE == service("StoreGateSvc", m_pSG) ) {
     log << MSG::ERROR << "Could not find StoreGateSvc" << endreq;
     return StatusCode::FAILURE;
  }
  return StatusCode::SUCCESS;
}



