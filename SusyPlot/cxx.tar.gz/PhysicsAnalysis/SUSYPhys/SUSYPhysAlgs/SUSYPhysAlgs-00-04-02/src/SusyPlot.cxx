
// SusyPlot.cxx
// Description: Algorithm into which selector and plotter tools are pushed.
// AuthorList: Ian Hinchliffe Davide Costanzo:  Initial Code August 2004
//  The structure of this is as follows.
// //
//  Before this Alg is used as set of algs are called that reate muon, electron etc collections 
//   and put them in storgate. the keys are kept in a SusyBag (defined in SusyUtils/SusyTypes.h)
//   The set of keys defined by "PlotInputKeys" (settable property).
//  There are then a set of tools  (defined in SusyUtils). This alg uses the tools as follows.

//   It first calls the selector tool which is defined by ("Selector") which acts on 
//   the ("SelectInputKeys") (This feature is not yet implimented)
  
//   Then it calls the tool ("Redundancy") which has a default that gets run automatically unless overridden.
//   This tool uses the "PlotInputKeys" and removes overlaps. For example, objects that appear both as 
//   jets and electrons are removed from the jet container. The output of this tool is another set of 
//   objects in Storgate with another set of keys given by m_outputRedKey which is filled automatically by 
//   susy::createNewBag(m_inputPlotKey).

//   Next is called a set of Tools that make histograms specificied by ("HistogramList"). These act upon  m_outputRedKey


// Oct 2004: Added redundancy checker


#include "SUSYPhysAlgs/SusyPlot.h" 
#include "GaudiKernel/MsgStream.h"
#include "GaudiKernel/IToolSvc.h"

SusyPlot::SusyPlot(const std::string& name,  ISvcLocator* pSvcLocator)
  : Algorithm(name, pSvcLocator), m_in(0), m_out(0)
{
  //  std::vector<std::string> inputPlotKey, inputSelKey;
  // Properties
  declareProperty("PlotInputKeys",m_inputPlotVec);
  declareProperty("SelectInputKeys",m_inputSelVec);
  declareProperty("HistogramList",m_histList);
  declareProperty("Selector",m_selector="");
  declareProperty("Redundancy",m_redundancy="SusyRedundTool");
}
 
SusyPlot::~SusyPlot() {
 
}
 
StatusCode SusyPlot::initialize() {
  MsgStream log(messageService(), name());
  log << MSG::INFO << "Initializing SusyPlotter " << name() << endreq;
  // first setup defaults and do some checking
  log << MSG::INFO << "Defining the list of Input Keys: " << endreq;
  FillBag(m_inputPlotVec,m_inputPlotKey);
  log << MSG::INFO << "Defining the list of Selection Keys: " << endreq;  
  FillBag(m_inputSelVec,m_inputSelKey);
  //
  // create the tool service
  IToolSvc* myTools;
  StatusCode sc=service("ToolSvc",myTools);
  if ( sc.isFailure() ) {
    log << MSG::FATAL	<< "Tool Service not found"	<< endreq;
    return StatusCode::FAILURE;
  } 
  //check that the hist tools exist
  std::vector<std::string>::iterator hname;
  for (hname= m_histList.begin() ; hname  != m_histList.end(); hname++ ) {
    ISusyObjectTool* algToolPtr;
    StatusCode sCode = myTools->retrieveTool((*hname),algToolPtr,this);
    if ( sCode.isFailure() ){    // tool not found
      log << MSG::INFO << "Cannot find tool named <" << (*hname)  << ">" << endreq;
    } else {
      log << MSG::INFO << "found tool named <" <<  (*hname)   << ">" << endreq;
      m_histtools.push_back(algToolPtr);
    }
  }
  //check that the selectorTool exists if it has been specified
  if(m_selector!=""){
    ISusyObjectTool* algToolPtr;
    StatusCode sCode = myTools->retrieveTool(m_selector,algToolPtr,this);
    if ( sCode.isFailure() ){ //tool not found
      log << MSG::INFO << "Cannot find tool named <" <<   m_selector  << ">" << endreq;
    } else {
      m_seltools=algToolPtr;
    }
  }

  // check that the redundancy tool is there.
  if(m_redundancy!=""){
   ISusyObjectTool* algToolPtr;
    StatusCode sCode = myTools->retrieveTool(m_redundancy,algToolPtr,this);
    if ( sCode.isFailure() ){ //tool not found
      log << MSG::INFO << "Cannot find tool named <" <<   m_redundancy  << ">" << endreq;
    } else {
      m_redtools=algToolPtr;
      m_redtools->Set(m_inputPlotKey);
    }    
  }
  //done with tool service
  // 
  if(m_inputPlotKey.size() ==0){
  log << MSG::FATAL << " You must specify some input " << name() << endreq;
  return StatusCode::FAILURE;  
  }
  // if there are no selectors default to plotters.
  if(m_inputPlotKey.size() != m_inputSelKey.size()  ){
    log << MSG::INFO << "Selector keys no good, defaulting to plot keys" << name() << endreq;
    m_inputSelKey=m_inputPlotKey;
  }
  //
  // Initialize the tools by setting all the keys.

   //
  // initialize the redundancy checker when it runs it will fill m_outputRedKey
   SusyBag inputKey = m_inputPlotKey;
   if(m_redundancy != "")  inputKey = susy::createNewBag(m_inputPlotKey);   
  // This bag will be used for the output from the red checker
  // sel_initialize()  bist_int(name from posa and key from pos
  //initialise the plotters, they will all use m_outputRedKey unless the redundancy checker is not called
  for (std::vector<ISusyObjectTool*>::iterator posa=m_histtools.begin(); 
       posa != m_histtools.end(); ++posa){
    (*(*posa)).Set(inputKey);
  }
  // call the initialize method of the tools
  //
  // first pass the set of keys to the selector tool, there cannot be more than one of each type
   if(m_selector!=""){
     (*m_seltools).Set(inputKey);
   }


  
  return StatusCode::SUCCESS;
}

 StatusCode SusyPlot::execute() {
  // now call the redundancy checker
   if(m_redundancy!=""){
     StatusCode sc=(*m_redtools).takeAction();  
   }
   m_in++;
  // first call the selector tool if one is given 
   if(m_selector!=""){
     StatusCode sc=(*m_seltools).takeAction();
     if(sc==StatusCode::FAILURE) {
           setFilterPassed(false);
           return StatusCode::SUCCESS; // exit from event 
     }
   }

   m_out++;


  // now call as many plotters as we have
  std::vector<ISusyObjectTool*>::iterator posa;
  for (posa=m_histtools.begin(); posa != m_histtools.end(); ++posa){
   StatusCode sc=(*(*posa)).takeAction(); 
  }
  return StatusCode::SUCCESS;
}


StatusCode SusyPlot::finalize() {
//
// Note I use cout so this is printed out no matter what!
  std::cout << "SusyPlot Statistics. Instance name: " << this->name() << std::endl;
  std::cout << "Number of events processed: " << m_in << " Pass the Filter: " << m_out << std::endl;

  return StatusCode::SUCCESS;

}
//                
//
StatusCode SusyPlot::FillBag(const std::vector<std::string>& inList, SusyBag& theBag) 
{
  MsgStream log(msgSvc(), name());
  log << MSG::DEBUG << "Number of keys to Set " << inList.size() << endreq;
  for (std::vector<std::string>::const_iterator itList=inList.begin(); itList!=inList.end() ; itList++) {
    int tokenPos=itList->find(":");
    std::string objString = itList->substr(0,tokenPos);
    std::string objKey = itList->substr(tokenPos+1);
     susy::SusyTypes objType = giveSusyType(objString);
    if (objType !=  susy::notKnown) {
      if(theBag.count(objType) != 0) log << MSG::WARNING << "Replacing Key for Object " << objString <<endreq;
      theBag[objType]=objKey;
      log << MSG::INFO << "Defining Object " << objString << " to String " << objKey << endreq;
    } else {
      log << MSG::ERROR << "Type " << objString << "  Not Known " << endreq;
    }
  }
  return StatusCode::SUCCESS;
}
//
// This is ugly, I guess we can do with a macro:
 susy::SusyTypes giveSusyType(const std::string theType){
  if(theType == "electron") return susy::electron;
  if(theType == "muon") return  susy::muon;
  if(theType == "jet") return  susy::jet;
  if(theType == "photon") return  susy::photon;
  if(theType == "tau") return  susy::tau;
  if(theType == "global") return  susy::global;
  if(theType == "electronmc") return susy::electronmc;
  if(theType == "muonmc") return  susy::muonmc;
  if(theType == "jetmc") return  susy::jetmc;
  if(theType == "photonmc") return  susy::photonmc;
  if(theType == "taumc") return  susy::taumc;
  if(theType == "globalmc") return  susy::globalmc;
  return  susy::notKnown;
}
